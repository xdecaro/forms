<?php

defined('_JEXEC') or die;

use DeCaro\Component\Forms\Administrator\Helper\FormHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Editor\EditorsRegistry;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

$form = $this->form;
$id = (int) ($form['id'] ?? 0);
$val = static fn(string $key, string $default = '') => htmlspecialchars((string) ($form[$key] ?? $default), ENT_QUOTES, 'UTF-8');
$checked = static fn(string $key, bool $default = false) => array_key_exists($key, $form) ? ((int) $form[$key] === 1) : $default;
$decode = static function (mixed $value, array $default = []): array {
    $data = json_decode((string) $value, true);
    return is_array($data) ? $data : $default;
};

$initialFields = [];
foreach ($this->fields as $field) {
    $initialFields[] = [
        'key' => (string) $field['field_key'],
        'type' => (string) $field['field_type'],
        'category' => (string) $field['category'],
        'label' => FormHelper::localizedFieldLabel((string) $field['field_key'], (string) $field['label']),
        'placeholder' => (string) $field['placeholder'],
        'help' => (string) $field['help_text'],
        'default' => (string) $field['default_value'],
        'options' => $field['options'] ?? [],
        'required' => (int) $field['required'] === 1,
        'config' => $field['config'] ?? [],
    ];
}

$initialStatuses = FormHelper::statusesForForm($form);
$initialColumns = FormHelper::listColumnsForForm($form);
$builderConfig = $decode($form['builder_config_json'] ?? '', []);
$emailConfig = $decode($form['email_config_json'] ?? '', []);
$additionalEmails = $decode($form['additional_emails_json'] ?? '', []);
$integrations = $decode($form['integrations_json'] ?? '', []);

if (!isset($emailConfig['admin']) || !is_array($emailConfig['admin'])) {
    $emailConfig['admin'] = [];
}
if (!isset($emailConfig['user']) || !is_array($emailConfig['user'])) {
    $emailConfig['user'] = [];
}
$emailConfig['admin'] += [
    'to' => (string) ($form['admin_email'] ?? ''),
    'from_email' => '', 'from_name' => '', 'reply_to' => '{email}', 'reply_name' => '', 'cc' => '', 'bcc' => '',
    'subject' => (string) ($form['email_subject_admin'] ?? ''),
    'template' => (string) ($form['email_template_admin'] ?? 'standard'),
    'auto_message' => true, 'attach_uploads' => false, 'html' => '',
    'custom' => ['base' => 'standard', 'primary' => '#e60046', 'secondary' => '#26364a', 'background' => '#ffffff', 'text' => '#20262d', 'button' => '#e60046', 'border' => '#dfe3e7', 'radius' => 8],
];
$emailConfig['user'] += [
    'enabled' => (int) ($form['user_confirmation'] ?? 0) === 1,
    'to_field' => 'email', 'reply_to' => '', 'reply_name' => '',
    'subject' => (string) ($form['email_subject_user'] ?? ''),
    'template' => (string) ($form['email_template_user'] ?? 'standard'),
    'auto_message' => true, 'attach_uploads' => false, 'html' => '',
    'custom' => ['base' => 'standard', 'primary' => '#e60046', 'secondary' => '#26364a', 'background' => '#ffffff', 'text' => '#20262d', 'button' => '#e60046', 'border' => '#dfe3e7', 'radius' => 8],
];

$emailEditorMarkup = ['admin' => '', 'user' => ''];
try {
    /** @var EditorsRegistry $editorsRegistry */
    $editorsRegistry = Factory::getContainer()->get(EditorsRegistry::class);
    if ($editorsRegistry->has('decaroeditor')) {
        $emailEditorProvider = $editorsRegistry->get('decaroeditor');
        foreach (['admin', 'user'] as $audience) {
            $emailEditorMarkup[$audience] = $emailEditorProvider->display(
                'df_editor_' . $audience . '_html',
                (string) ($emailConfig[$audience]['html'] ?? ''),
                [
                    'id' => 'df-editor-' . $audience . '-html',
                    'width' => '100%',
                    'height' => '420px',
                    'col' => 60,
                    'row' => 20,
                ],
                ['buttons' => true]
            );
        }
    }
} catch (\Throwable $exception) {
    // Editor is optional. Any unavailable/incompatible provider keeps the
    // existing Forms textarea path without affecting Builder availability.
    $emailEditorMarkup = ['admin' => '', 'user' => ''];
}
?>
<style>
.df-builder{--df:#e60046;--df-dark:#b40038;--df-border:var(--bs-border-color,#dfe3e7);width:100%;max-width:none}.df-builder *{box-sizing:border-box}.df-bhead{display:flex;align-items:flex-end;justify-content:space-between;gap:14px;margin:4px 0 18px}.df-bhead h2{margin:0;font-size:27px}.df-bhead p{margin:5px 0 0;color:var(--bs-secondary-color,#667085)}.df-bactions{display:flex;gap:8px;flex-wrap:wrap}.df-btn{display:inline-flex;align-items:center;justify-content:center;min-height:39px;padding:0 14px;border:1px solid;border-radius:6px;text-decoration:none;font-weight:750;cursor:pointer}.df-small{min-height:34px;padding:0 10px;font-size:12px}.df-ui-icon{width:16px;height:16px;display:inline-block;flex:0 0 auto;vertical-align:-2px}.df-ui-icon path,.df-ui-icon line,.df-ui-icon polyline,.df-ui-icon rect,.df-ui-icon circle{vector-effect:non-scaling-stroke}.df-icon-only .df-ui-icon,.df-layout-actions button .df-ui-icon,.df-mini-actions button .df-ui-icon,.df-status-remove .df-ui-icon,.df-lib-delete .df-ui-icon,.df-saved-quick-delete .df-ui-icon{margin:0}.df-icon-only{display:inline-flex;align-items:center;justify-content:center}.df-section{margin-bottom:13px;border:1px solid var(--df-border);border-radius:9px;background:var(--bs-body-bg,#fff);overflow:hidden}.df-section-toggle{width:100%;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:15px 17px;border:0;background:var(--df);color:#fff;text-align:left;font:inherit;font-weight:850;cursor:pointer;transition:background .18s ease}.df-section-toggle:hover,.df-section-toggle:focus-visible{background:var(--df-dark);color:#fff}.df-section-toggle strong{font-size:18px;color:#fff}.df-section-chevron{color:#fff}.df-section-chevron{transition:transform .35s ease}.df-section.is-open .df-section-chevron{transform:rotate(180deg)}.df-section-body-wrap{display:grid;grid-template-rows:0fr;transition:grid-template-rows .42s cubic-bezier(.2,.7,.2,1)}.df-section.is-open .df-section-body-wrap{grid-template-rows:1fr}.df-section-body-inner{min-height:0;overflow:hidden}.df-section-body{padding:17px}.df-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.df-field{display:flex;flex-direction:column;gap:6px}.df-field-full{grid-column:1/-1}.df-field label,.df-label{font-weight:750}.df-field input:not([type=checkbox]):not([type=radio]),.df-field textarea,.df-field select,.df-input{width:100%;border:1px solid var(--bs-border-color,#d5dbe3);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;padding:10px 11px;min-height:42px}.df-field textarea{min-height:88px;resize:vertical}.df-check{display:flex;align-items:center;gap:9px;min-height:42px}.df-check input{width:18px;height:18px}.df-note{font-size:12px;color:var(--bs-secondary-color,#667085)}.df-subbox{border:1px solid var(--df-border);border-radius:8px;padding:14px;background:color-mix(in srgb,var(--bs-body-bg,#fff) 96%,var(--bs-tertiary-bg,#f7f8fa))}.df-subbox+.df-subbox{margin-top:12px}.df-subbox h4{margin:0 0 12px;font-size:16px}.df-inline{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.df-spread{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.df-template-row{display:flex;gap:8px;flex-wrap:wrap}.df-template-row button{min-height:36px;padding:0 12px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;font-weight:700;cursor:pointer}.df-template-row button:hover{border-color:var(--df);color:var(--df)}.df-template-row button.is-active{background:var(--df);border-color:var(--df);color:#fff}.df-template-row button.is-active:hover{background:var(--df-dark);border-color:var(--df-dark);color:#fff}.df-layout-feedback{font-size:12px;font-weight:800;color:#18794e}
.df-selected{display:flex;flex-direction:column;gap:9px}.df-selected-empty{padding:24px;border:1px dashed var(--bs-border-color,#d5dbe3);border-radius:6px;text-align:center;color:var(--bs-secondary-color,#667085)}.df-selected-item{border:1px solid var(--df-border);border-radius:7px;overflow:hidden}.df-selected-top{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;padding:11px 12px;background:var(--bs-tertiary-bg,#f7f8fa)}.df-mini-actions{display:flex;gap:5px}.df-mini-actions button{min-width:32px;height:30px;border:1px solid var(--df-border);border-radius:5px;background:var(--bs-body-bg,#fff);color:inherit;cursor:pointer}.df-selected-config{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:12px}.df-selected-config .full{grid-column:1/-1}.df-selected-config input:not([type=checkbox]):not([type=radio]),.df-selected-config select,.df-selected-config textarea{width:100%;border:1px solid var(--bs-border-color,#d5dbe3);border-radius:5px;background:var(--bs-body-bg,#fff);color:inherit;padding:8px 9px;min-height:38px}.df-selected-config textarea.df-options{min-height:96px;max-height:180px;resize:vertical}.df-config-panel{grid-column:1/-1;border-top:1px dashed var(--df-border);padding-top:10px}.df-config-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}.df-condition-list{display:flex;flex-direction:column;gap:7px;margin-top:8px}.df-condition-row{display:grid;grid-template-columns:1.2fr .8fr 1fr 34px;gap:7px}.df-condition-row button{border:1px solid var(--df-border);border-radius:5px;background:transparent;color:inherit}.df-required{display:flex;align-items:center;gap:7px}.df-required input{width:17px;height:17px}
.df-layout-widths{display:grid;grid-template-columns:repeat(4,minmax(90px,1fr));gap:9px}.df-layout-widths .df-field[hidden]{display:none}.df-presets{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px}.df-preset{border:1px solid var(--df-border);border-radius:999px;padding:6px 10px;background:var(--bs-body-bg,#fff);color:inherit;cursor:pointer;font-weight:700;font-size:12px}.df-layout-total{font-weight:800}.df-layout-total.is-error{color:#b42318}.df-layout-total.is-ok{color:#18794e}
.df-library-tools{display:grid;grid-template-columns:minmax(220px,1fr) 250px;gap:10px;margin-bottom:12px}.df-library-tools input,.df-library-tools select{min-height:42px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;padding:0 11px}.df-library{display:flex;flex-direction:column;gap:8px}.df-library-group{border:1px solid var(--df-border);border-radius:7px;overflow:hidden}.df-library-group summary{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 13px;background:var(--bs-tertiary-bg,#f7f8fa);font-weight:800;cursor:pointer;list-style:none}.df-library-group summary::-webkit-details-marker{display:none}.df-library-count{display:inline-flex;min-width:26px;height:24px;align-items:center;justify-content:center;border-radius:999px;background:color-mix(in srgb,var(--df) 12%,transparent);color:var(--df);font-size:12px}.df-library-items{display:flex;flex-direction:column;gap:7px;padding:9px}.df-lib-item{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;padding:10px 11px;border:1px solid var(--df-border);border-radius:6px}.df-lib-item strong{display:block}.df-lib-item small{color:var(--bs-secondary-color,#667085)}.df-add{min-height:34px;padding:0 12px;border:0;border-radius:5px;background:var(--df);color:#fff;font-weight:800;cursor:pointer}
.df-status-editor{display:flex;flex-direction:column;gap:8px}.df-status-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(120px,.65fr) 110px 34px;gap:7px;align-items:center}.df-status-row input{width:100%;border:1px solid var(--df-border);border-radius:5px;background:var(--bs-body-bg,#fff);color:inherit;padding:8px 9px}.df-status-color-wrap{display:flex;align-items:center;gap:6px}.df-status-color{width:44px!important;min-width:44px;height:39px;padding:3px!important}.df-status-color-value{font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace}.df-status-remove{border:1px solid var(--df-border);border-radius:5px;background:var(--bs-body-bg,#fff);color:inherit;height:36px}.df-column-tools{display:flex;gap:7px;flex-wrap:wrap;margin:8px 0}.df-column-list{display:flex;flex-wrap:wrap;gap:7px}.df-column-item{display:inline-flex;align-items:center;gap:7px;padding:8px 10px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff)}.df-column-item input{width:17px;height:17px}
.df-email-block{border:1px solid var(--df-border);border-radius:8px;overflow:hidden;margin-bottom:11px}.df-email-block>summary{padding:12px 14px;background:var(--bs-tertiary-bg,#f7f8fa);font-weight:850;cursor:pointer}.df-email-block-body{padding:14px}.df-email-templates{display:grid;grid-template-columns:repeat(4,minmax(130px,1fr));gap:9px;margin-top:8px}.df-email-choice{border:1px solid var(--df-border);border-radius:7px;padding:8px;background:var(--bs-body-bg,#fff)}.df-email-choice.is-active{border-color:var(--df);box-shadow:0 0 0 2px color-mix(in srgb,var(--df) 18%,transparent)}.df-email-thumb{display:block;width:100%;height:62px;border:1px solid #e1e4e8;border-radius:5px;background:#fff;cursor:pointer;overflow:hidden}.df-email-thumb span{display:block;height:13px;background:var(--preview,#e60046)}.df-email-thumb[data-template="minimal"] span{height:3px;background:#dfe3e7}.df-email-thumb[data-template="institutional"] span{background:#26364a}.df-email-thumb[data-template="card"]{margin:3px;box-shadow:0 2px 7px rgba(0,0,0,.13)}.df-email-thumb[data-template="compact"]{border-left:5px solid #e60046}.df-email-thumb[data-template="modern"]{background:linear-gradient(135deg,#fff 70%,#eef1f5 70%)}.df-email-thumb[data-template="elegant"]{border-color:#c9b98d}.df-email-thumb[data-template="receipt"]{background:repeating-linear-gradient(0deg,#fff 0 8px,#f4f5f7 8px 9px)}.df-email-choice-foot{display:flex;align-items:center;gap:7px;margin-top:7px;font-size:12px;font-weight:800}.df-email-special{margin-top:10px;padding:12px;border:1px dashed var(--df-border);border-radius:7px}.df-codearea{width:100%;min-height:190px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;padding:11px;font:13px/1.55 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;resize:vertical}.df-tokenbar{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin:10px 0}.df-tokenbar select{min-height:36px;border:1px solid var(--df-border);border-radius:5px;background:var(--bs-body-bg,#fff);color:inherit}.df-additional-list{display:flex;flex-direction:column;gap:9px}.df-additional-card{border:1px solid var(--df-border);border-radius:7px;padding:12px}.df-additional-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}.df-additional-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.df-additional-grid .full{grid-column:1/-1}
.df-preview-modal[hidden]{display:none!important}.df-preview-modal{position:fixed;inset:0;z-index:12000;display:grid;place-items:center;padding:20px}.df-preview-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.58)}.df-preview-dialog{position:relative;z-index:1;width:min(850px,100%);max-height:90vh;overflow:auto;border:1px solid var(--df-border);border-radius:10px;background:var(--bs-body-bg,#fff);box-shadow:0 24px 80px rgba(0,0,0,.28)}.df-preview-head,.df-preview-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 16px;border-bottom:1px solid var(--df-border)}.df-preview-foot{border-top:1px solid var(--df-border);border-bottom:0;justify-content:flex-end}.df-preview-body{padding:17px;background:#e9edf2}.df-preview-canvas{max-width:700px;margin:auto}.df-preview-x{width:36px;height:36px;border:1px solid var(--df-border);border-radius:6px;background:transparent;color:inherit;font-size:22px}
.df-security-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.df-custom-code-grid{display:grid;grid-template-columns:1fr;gap:12px}.df-custom-code-grid .df-field{width:100%;min-width:0}.df-custom-code-grid .df-codearea{width:100%;max-width:none;box-sizing:border-box}.df-warning{padding:10px 12px;border-left:4px solid #f59e0b;background:color-mix(in srgb,#f59e0b 10%,transparent);font-size:12px}.df-admin-footer{width:100%;box-sizing:border-box;clear:both;margin:28px 0 10px;padding-top:16px;border-top:1px solid var(--df-border);text-align:center;color:var(--bs-secondary-color,#667085);font-size:12px}
@media(max-width:980px){.df-email-templates{grid-template-columns:repeat(3,1fr)}.df-config-grid{grid-template-columns:1fr 1fr}.df-custom-code-grid{grid-template-columns:1fr}}
@media(max-width:800px){.df-bhead{align-items:flex-start;flex-direction:column}.df-grid,.df-selected-config,.df-library-tools,.df-additional-grid,.df-security-grid{grid-template-columns:1fr}.df-field-full,.df-selected-config .full,.df-additional-grid .full{grid-column:auto}.df-layout-widths{grid-template-columns:1fr 1fr}.df-email-templates{grid-template-columns:1fr 1fr}.df-condition-row{grid-template-columns:1fr 1fr}.df-condition-row button{grid-column:2}.df-config-grid{grid-template-columns:1fr 1fr}}
@media(max-width:560px){.df-section-body{padding:12px}.df-email-templates,.df-layout-widths,.df-config-grid{grid-template-columns:1fr}.df-status-row{grid-template-columns:1fr 1fr}.df-status-color-wrap{grid-column:1}.df-selected-top{grid-template-columns:1fr}.df-mini-actions{justify-content:flex-start}.df-column-item{width:100%}.df-condition-row{grid-template-columns:1fr}.df-condition-row button{grid-column:auto}.df-preview-modal{padding:8px}}

/* Forms 1.3.2 UX refinements */
.df-section-toggle{background:var(--bs-tertiary-bg,#f7f8fa)!important;color:inherit!important;border:0!important}
.df-section-toggle:hover,.df-section-toggle:focus-visible{background:color-mix(in srgb,var(--bs-tertiary-bg,#f7f8fa) 88%,var(--df) 12%)!important;color:inherit!important}
.df-section-toggle strong,.df-section-chevron{color:inherit!important}
.df-template-row button.is-active{background:var(--bs-body-bg,#fff)!important;color:var(--df)!important;border-color:var(--df)!important;box-shadow:0 0 0 2px color-mix(in srgb,var(--df) 16%,transparent)}
.df-closed-box{grid-column:1/-1;background:var(--df);border-radius:8px;padding:14px}.df-closed-box label{color:#fff}.df-closed-box .df-note{color:#fff;opacity:.9}.df-closed-box input,.df-closed-box select{background:#fff!important;color:#1f2937!important}
.df-switch{display:inline-flex;align-items:center;gap:10px;font-weight:750;cursor:pointer;min-height:42px}.df-switch input{position:absolute;opacity:0;pointer-events:none}.df-switch-ui{position:relative;width:42px;height:24px;border-radius:999px;background:#aeb6c2;transition:.2s}.df-switch-ui:after{content:"";position:absolute;width:18px;height:18px;left:3px;top:3px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.28);transition:.2s}.df-switch input:checked+.df-switch-ui{background:#0d6efd}.df-switch input:checked+.df-switch-ui:after{transform:translateX(18px)}.df-switch input:focus-visible+.df-switch-ui{outline:3px solid color-mix(in srgb,#0d6efd 28%,transparent);outline-offset:2px}
.df-selected-item .df-selected-config-wrap{display:grid;grid-template-rows:0fr;transition:grid-template-rows .32s ease}.df-selected-item.is-open .df-selected-config-wrap{grid-template-rows:1fr}.df-selected-config-inner{overflow:hidden;min-height:0}.df-field-toggle{border:0;background:transparent;color:inherit;padding:0;text-align:left;cursor:pointer;display:flex;align-items:center;gap:9px;min-width:0}.df-field-toggle-main{min-width:0}.df-field-chevron{transition:transform .25s}.df-selected-item.is-open .df-field-chevron{transform:rotate(180deg)}.df-field-summary{display:flex;gap:6px;flex-wrap:wrap;margin-top:3px}.df-summary-chip{font-size:10px;padding:2px 6px;border:1px solid var(--df-border);border-radius:999px;color:var(--bs-secondary-color,#667085)}
.df-condition-details{grid-column:1/-1;border-top:1px dashed var(--df-border);padding-top:8px}.df-condition-details>summary,.df-field-advanced>summary{cursor:pointer;font-weight:800;list-style:none;display:flex;align-items:center;justify-content:space-between}.df-condition-details>summary::-webkit-details-marker,.df-field-advanced>summary::-webkit-details-marker{display:none}.df-condition-details>summary:after,.df-field-advanced>summary:after{content:'⌄';font-size:12px}.df-condition-details[open]>summary:after,.df-field-advanced[open]>summary:after{transform:rotate(180deg)}.df-condition-body{padding-top:9px}.df-field-advanced{grid-column:1/-1;border-top:1px dashed var(--df-border);padding-top:8px}
.df-layout-visual-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:10px}.df-layout-canvas{display:flex;flex-direction:column;gap:10px}.df-layout-row{min-height:72px;border:1px dashed var(--df-border);border-radius:8px;padding:9px;display:flex;align-items:stretch;gap:8px;background:color-mix(in srgb,var(--bs-tertiary-bg,#f7f8fa) 45%,transparent)}.df-layout-card{position:relative;min-width:120px;max-width:100%;border:1px solid var(--df-border);border-radius:7px;background:var(--bs-body-bg,#fff);padding:10px;display:flex;align-items:center;gap:8px;cursor:grab;box-shadow:0 1px 2px rgba(0,0,0,.04)}.df-layout-card.dragging{opacity:.4}.df-layout-handle{font-weight:900;color:var(--bs-secondary-color,#667085);letter-spacing:-2px}.df-layout-card strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}.df-layout-card select{width:auto;min-width:78px;min-height:32px;border:1px solid var(--df-border);border-radius:5px;background:var(--bs-body-bg,#fff);color:inherit}.df-layout-newrow{min-height:48px;border:1px dashed var(--df-border);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--bs-secondary-color,#667085);font-size:12px}.df-layout-row.is-over,.df-layout-newrow.is-over{border-color:var(--df);background:color-mix(in srgb,var(--df) 7%,transparent)}.df-layout-advanced-box{margin-top:12px}.df-layout-empty{padding:22px;border:1px dashed var(--df-border);border-radius:8px;text-align:center;color:var(--bs-secondary-color,#667085)}
.df-library-tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}.df-library-tab{border:1px solid var(--df-border);border-radius:999px;min-height:32px;padding:0 10px;background:var(--bs-body-bg,#fff);color:inherit;font-weight:750;font-size:12px;cursor:pointer;display:inline-flex;align-items:center;gap:6px}.df-library-tab.is-active{border-color:var(--df);color:var(--df);box-shadow:0 0 0 2px color-mix(in srgb,var(--df) 12%,transparent)}.df-library-tab-count{font-size:10px;min-width:19px;height:19px;border-radius:999px;background:color-mix(in srgb,var(--df) 10%,transparent);display:inline-flex;align-items:center;justify-content:center}.df-library-tools-v2{display:block;margin-bottom:10px}.df-library-tools-v2 input{width:100%;min-height:42px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;padding:0 11px}.df-library-items-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.df-library-empty{padding:20px;text-align:center;color:var(--bs-secondary-color,#667085);border:1px dashed var(--df-border);border-radius:7px}
.df-info{border:0;background:transparent;color:#3971c7;font-weight:900;font-size:15px;padding:0 3px;cursor:pointer;vertical-align:middle}.df-info-wrap{position:relative;display:inline-flex;align-items:center}.df-info-bubble{position:absolute;z-index:50;left:50%;top:calc(100% + 7px);transform:translateX(-50%);width:min(320px,76vw);padding:9px 10px;border:1px solid var(--df-border);border-radius:7px;background:var(--bs-body-bg,#fff);color:var(--bs-body-color,#222);box-shadow:0 8px 28px rgba(0,0,0,.16);font-size:12px;font-weight:500;line-height:1.4;display:none}.df-info-wrap.is-open .df-info-bubble{display:block}.df-label-info{display:inline-flex;align-items:center;gap:4px}
.df-email-special-choice{border-style:dashed!important}.df-email-choice[data-special="1"]{background:color-mix(in srgb,var(--bs-tertiary-bg,#f7f8fa) 55%,transparent)}
@media(max-width:800px){.df-library-tabs{flex-wrap:nowrap;overflow-x:auto;padding-bottom:4px}.df-library-tab{flex:0 0 auto}.df-library-items-grid{grid-template-columns:1fr}.df-layout-row{flex-direction:column}.df-layout-card{width:100%!important}.df-selected-config{grid-template-columns:1fr}.df-config-grid{grid-template-columns:1fr}.df-closed-box .df-grid{grid-template-columns:1fr}}


/* Forms 1.3.3 interaction hotfix */
.df-section-toggle:hover,
.df-section-toggle:focus-visible{
  background:var(--bs-tertiary-bg,#f7f8fa)!important;
  color:inherit!important;
  box-shadow:none!important;
}
.df-closed-box{
  background:color-mix(in srgb,var(--df) 7%,var(--bs-body-bg,#fff))!important;
  border:1px solid color-mix(in srgb,var(--df) 34%,var(--df-border,#dfe3e7))!important;
}
.df-closed-box label{
  color:var(--bs-body-color,#1f2937)!important;
}
.df-closed-box .df-note{
  color:var(--bs-secondary-color,#667085)!important;
  opacity:1!important;
}
.df-closed-box input,
.df-closed-box select{
  background:var(--bs-body-bg,#fff)!important;
  color:var(--bs-body-color,#1f2937)!important;
}


/* Forms 1.3.4 accordion visual style */
.df-section-toggle{
  background:var(--bs-dark,#1f2937)!important;
  color:#fff!important;
}
.df-section-toggle strong,
.df-section-toggle .df-section-chevron{
  color:#fff!important;
}
.df-section-toggle:hover,
.df-section-toggle:focus-visible{
  background:color-mix(in srgb,var(--bs-dark,#1f2937) 90%,#fff 10%)!important;
  color:#fff!important;
  box-shadow:none!important;
}
.df-section-toggle:focus-visible{
  outline:2px solid var(--bs-primary,#0d6efd)!important;
  outline-offset:2px;
}


/* Forms 1.3.5 dark-mode surfaces + independent accordion polish */
.df-builder{
  --df-theme-surface:var(--bs-body-bg,#fff);
  --df-theme-surface-soft:var(--bs-tertiary-bg,#f7f8fa);
  --df-theme-input:var(--bs-body-bg,#fff);
  --df-theme-text:var(--bs-body-color,#1f2937);
  --df-theme-muted:var(--bs-secondary-color,#667085);
  --df-theme-border:var(--bs-border-color,#dfe3e7);
  --df-close-bg:color-mix(in srgb,var(--df) 7%,var(--bs-body-bg,#fff));
  --df-close-border:color-mix(in srgb,var(--df) 34%,var(--df-border,#dfe3e7));
  --df-close-label:var(--bs-body-color,#1f2937);
}
[data-bs-theme="dark"] .df-builder,
html[data-bs-theme="dark"] .df-builder,
body[data-bs-theme="dark"] .df-builder{
  --df-theme-surface:#1f2937;
  --df-theme-surface-soft:#263241;
  --df-theme-input:#111922;
  --df-theme-text:#f4f7fb;
  --df-theme-muted:#b6c0ce;
  --df-theme-border:#4a596b;
  --df-close-bg:rgba(230,0,70,.14);
  --df-close-border:#a94762;
  --df-close-label:#ffb1c3;
}
@media (prefers-color-scheme:dark){
  .df-builder{
    --df-theme-surface:#1f2937;
    --df-theme-surface-soft:#263241;
    --df-theme-input:#111922;
    --df-theme-text:#f4f7fb;
    --df-theme-muted:#b6c0ce;
    --df-theme-border:#4a596b;
    --df-close-bg:rgba(230,0,70,.14);
    --df-close-border:#a94762;
    --df-close-label:#ffb1c3;
  }
}

/* Internal cards: remove white islands in dark mode. */
.df-builder .df-subbox,
.df-builder .df-email-block,
.df-builder .df-email-block-body,
.df-builder .df-additional-card,
.df-builder .df-column-item,
.df-builder .df-email-choice,
.df-builder .df-email-special,
.df-builder .df-info-bubble{
  background:var(--df-theme-surface)!important;
  color:var(--df-theme-text)!important;
  border-color:var(--df-theme-border)!important;
}
.df-builder .df-email-block>summary{
  background:var(--df-theme-surface-soft)!important;
  color:var(--df-theme-text)!important;
  border-color:var(--df-theme-border)!important;
}
.df-builder .df-subbox h4,
.df-builder .df-email-block summary,
.df-builder .df-column-item span,
.df-builder .df-email-choice-foot,
.df-builder .df-additional-card,
.df-builder .df-security-grid,
.df-builder .df-status-color-value{
  color:var(--df-theme-text)!important;
}
.df-builder .df-note{
  color:var(--df-theme-muted)!important;
}

/* Form controls inside Builder use a real dark surface instead of white. */
.df-builder .df-field input:not([type=checkbox]):not([type=radio]):not([type=color]),
.df-builder .df-field textarea,
.df-builder .df-field select,
.df-builder .df-input,
.df-builder .df-status-row input:not([type=color]),
.df-builder .df-status-remove,
.df-builder .df-tokenbar select,
.df-builder .df-codearea{
  background:var(--df-theme-input)!important;
  color:var(--df-theme-text)!important;
  border-color:var(--df-theme-border)!important;
}
.df-builder .df-field input::placeholder,
.df-builder .df-field textarea::placeholder,
.df-builder .df-codearea::placeholder{
  color:var(--df-theme-muted)!important;
  opacity:.82;
}
.df-builder .df-status-remove{
  background:var(--df-theme-input)!important;
  color:var(--df-theme-text)!important;
  border-color:var(--df-theme-border)!important;
}

/* Closed-form warning: light red in light mode, dark red translucent in dark mode. */
.df-builder .df-closed-box{
  background:var(--df-close-bg)!important;
  border-color:var(--df-close-border)!important;
}
.df-builder .df-closed-box label{
  color:var(--df-close-label)!important;
}
.df-builder .df-closed-box input,
.df-builder .df-closed-box select{
  background:var(--df-theme-input)!important;
  color:var(--df-theme-text)!important;
  border-color:var(--df-theme-border)!important;
}

/* Custom CSS/JS helper line: align it with the editor content. */
.df-builder .df-custom-code-grid .df-note{
  display:block;
  padding-left:5px;
  margin-top:2px;
}


/* Forms 1.3.6 mobile library + status UX */
.df-builder .df-status-remove{
  border-color:#dc3545!important;
  color:#b42332!important;
  background:color-mix(in srgb,#dc3545 6%,var(--df-theme-input,var(--bs-body-bg,#fff)))!important;
  font-weight:850;
}
.df-builder .df-status-remove:hover,
.df-builder .df-status-remove:focus-visible{
  border-color:#dc3545!important;
  color:#fff!important;
  background:#b42332!important;
}
[data-bs-theme="dark"] .df-builder .df-library-tab,
html[data-bs-theme="dark"] .df-builder .df-library-tab,
body[data-bs-theme="dark"] .df-builder .df-library-tab{
  background:#1f2937!important;
  color:#f4f7fb!important;
  border-color:#4a596b!important;
  box-shadow:none!important;
}
[data-bs-theme="dark"] .df-builder .df-library-tab:hover,
html[data-bs-theme="dark"] .df-builder .df-library-tab:hover,
body[data-bs-theme="dark"] .df-builder .df-library-tab:hover{
  background:#2a3747!important;
  color:#fff!important;
  border-color:#64748b!important;
}
[data-bs-theme="dark"] .df-builder .df-library-tab.is-active,
html[data-bs-theme="dark"] .df-builder .df-library-tab.is-active,
body[data-bs-theme="dark"] .df-builder .df-library-tab.is-active{
  background:rgba(230,0,70,.14)!important;
  color:#ff9bb4!important;
  border-color:#e60046!important;
  box-shadow:0 0 0 2px rgba(230,0,70,.12)!important;
}
[data-bs-theme="dark"] .df-builder .df-library-tab-count,
html[data-bs-theme="dark"] .df-builder .df-library-tab-count,
body[data-bs-theme="dark"] .df-builder .df-library-tab-count{
  background:#334155!important;
  color:#e5edf7!important;
}
[data-bs-theme="dark"] .df-builder .df-library-tab.is-active .df-library-tab-count,
html[data-bs-theme="dark"] .df-builder .df-library-tab.is-active .df-library-tab-count,
body[data-bs-theme="dark"] .df-builder .df-library-tab.is-active .df-library-tab-count{
  background:rgba(230,0,70,.22)!important;
  color:#ffd3de!important;
}
@media (prefers-color-scheme:dark){
 .df-builder .df-library-tab{background:#1f2937!important;color:#f4f7fb!important;border-color:#4a596b!important;box-shadow:none!important}
 .df-builder .df-library-tab:hover{background:#2a3747!important;color:#fff!important;border-color:#64748b!important}
 .df-builder .df-library-tab.is-active{background:rgba(230,0,70,.14)!important;color:#ff9bb4!important;border-color:#e60046!important;box-shadow:0 0 0 2px rgba(230,0,70,.12)!important}
 .df-builder .df-library-tab-count{background:#334155!important;color:#e5edf7!important}
 .df-builder .df-library-tab.is-active .df-library-tab-count{background:rgba(230,0,70,.22)!important;color:#ffd3de!important}
 .df-builder .df-status-remove{color:#ff9aa8!important;background:rgba(220,53,69,.10)!important;border-color:#b94b59!important}
 .df-builder .df-status-remove:hover,.df-builder .df-status-remove:focus-visible{color:#fff!important;background:#9f2f3d!important;border-color:#d95d6c!important}
}
@media(max-width:560px){
 .df-builder .df-status-editor{gap:14px}
 .df-builder .df-status-row{
   grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;
   gap:10px!important;
   padding:11px!important;
   border:1px solid var(--df-theme-border,var(--df-border))!important;
   border-radius:8px!important;
   background:var(--df-theme-surface-soft,var(--bs-tertiary-bg,#f7f8fa))!important;
 }
 .df-builder .df-status-row>input{min-width:0}
 .df-builder .df-status-color-wrap{grid-column:1!important;min-width:0}
 .df-builder .df-status-remove{grid-column:2!important;width:100%!important;height:44px!important;min-width:0}
}


/* Forms 1.3.7 layout dark-mode and spacing fixes */
.df-builder .df-layout-newrow{
  margin-top:16px;
  margin-bottom:18px;
  padding:12px 14px;
  line-height:1.45;
}
.df-builder .df-layout-advanced-box{
  margin-top:18px;
}
[data-bs-theme="dark"] .df-builder .df-layout-row,
html[data-bs-theme="dark"] .df-builder .df-layout-row,
body[data-bs-theme="dark"] .df-builder .df-layout-row{
  background:rgba(255,255,255,.035)!important;
  border-color:#657386!important;
}
[data-bs-theme="dark"] .df-builder .df-layout-card,
html[data-bs-theme="dark"] .df-builder .df-layout-card,
body[data-bs-theme="dark"] .df-builder .df-layout-card{
  background:#151c24!important;
  color:#f4f7fb!important;
  border-color:#5b697a!important;
  box-shadow:0 1px 2px rgba(0,0,0,.28)!important;
}
[data-bs-theme="dark"] .df-builder .df-layout-card strong,
html[data-bs-theme="dark"] .df-builder .df-layout-card strong,
body[data-bs-theme="dark"] .df-builder .df-layout-card strong{
  color:#f4f7fb!important;
}
[data-bs-theme="dark"] .df-builder .df-layout-handle,
html[data-bs-theme="dark"] .df-builder .df-layout-handle,
body[data-bs-theme="dark"] .df-builder .df-layout-handle{
  color:#a9b6c6!important;
}
[data-bs-theme="dark"] .df-builder .df-layout-card select,
html[data-bs-theme="dark"] .df-builder .df-layout-card select,
body[data-bs-theme="dark"] .df-builder .df-layout-card select{
  background:#111820!important;
  color:#f8fafc!important;
  border-color:#5b697a!important;
}
[data-bs-theme="dark"] .df-builder .df-layout-newrow,
html[data-bs-theme="dark"] .df-builder .df-layout-newrow,
body[data-bs-theme="dark"] .df-builder .df-layout-newrow{
  background:rgba(255,255,255,.025)!important;
  color:#aeb9c7!important;
  border-color:#758294!important;
}
@media (prefers-color-scheme:dark){
 .df-builder .df-layout-row{background:rgba(255,255,255,.035)!important;border-color:#657386!important}
 .df-builder .df-layout-card{background:#151c24!important;color:#f4f7fb!important;border-color:#5b697a!important;box-shadow:0 1px 2px rgba(0,0,0,.28)!important}
 .df-builder .df-layout-card strong{color:#f4f7fb!important}
 .df-builder .df-layout-handle{color:#a9b6c6!important}
 .df-builder .df-layout-card select{background:#111820!important;color:#f8fafc!important;border-color:#5b697a!important}
 .df-builder .df-layout-newrow{background:rgba(255,255,255,.025)!important;color:#aeb9c7!important;border-color:#758294!important}
}


/* Forms 1.3.8 light accordion + saved-field controls */
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle{
  background:#f6f7f9!important;
  color:#1f2937!important;
  border-color:#d9dee5!important;
}
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle:hover{
  background:#eef1f4!important;
}
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section.is-open>.df-section-toggle{
  background:#f1f4f8!important;
}
.df-builder .df-save-preset svg{width:16px;height:16px;display:block}
.df-builder .df-save-preset.is-saved{
  border-color:#198754!important;
  color:#198754!important;
  box-shadow:0 0 0 2px color-mix(in srgb,#198754 14%,transparent)!important;
}
.df-builder .df-lib-actions{display:flex;align-items:center;gap:6px}
.df-builder .df-lib-delete{
  min-width:34px;height:34px;border:1px solid #dc3545;border-radius:5px;background:transparent;color:#b42332;font-weight:900;cursor:pointer;
}
.df-builder .df-lib-delete:hover,.df-builder .df-lib-delete:focus-visible{background:#dc3545;color:#fff}
@media(max-width:560px){
 .df-builder .df-mini-actions{flex-wrap:wrap}
 .df-builder .df-save-preset{order:-1}
}


/* Forms 1.3.9: accordion contrast fix in Joomla light mode. */
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle,
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle *,
html[data-bs-theme="light"] .df-builder .df-section-toggle,
html[data-bs-theme="light"] .df-builder .df-section-toggle *{
  color:#1f2937!important;
}
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle,
html[data-bs-theme="light"] .df-builder .df-section-toggle{
  background:#f6f7f9!important;
  border-color:#d9dee5!important;
  box-shadow:none!important;
}
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle:hover,
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle:focus-visible,
html[data-bs-theme="light"] .df-builder .df-section-toggle:hover,
html[data-bs-theme="light"] .df-builder .df-section-toggle:focus-visible{
  background:#eef1f4!important;
  color:#1f2937!important;
}
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section.is-open>.df-section-toggle,
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section.is-open>.df-section-toggle *,
html[data-bs-theme="light"] .df-builder .df-section.is-open>.df-section-toggle,
html[data-bs-theme="light"] .df-builder .df-section.is-open>.df-section-toggle *{
  background:#f1f4f8!important;
  color:#1f2937!important;
}
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle svg,
html[data-bs-theme="light"] .df-builder .df-section-toggle svg{
  color:#1f2937!important;
  fill:currentColor!important;
  stroke:currentColor!important;
}
html:not([data-bs-theme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-section-toggle .df-section-chevron,
html[data-bs-theme="light"] .df-builder .df-section-toggle .df-section-chevron{
  color:#1f2937!important;
}


/* Forms 1.3.10: template cards have an explicit facsimile-preview action. */
.df-builder .df-email-choice{position:relative;cursor:pointer;transition:border-color .16s ease,box-shadow .16s ease,transform .16s ease}
.df-builder .df-email-choice:hover{border-color:#9aa7b8;box-shadow:0 4px 14px rgba(15,23,42,.08)}
.df-builder .df-email-thumb{position:relative;overflow:hidden;cursor:pointer}
.df-builder .df-email-thumb-art{display:block;width:100%;height:100%}
.df-builder .df-email-preview-label{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:999px;background:rgba(31,41,55,.9);color:#fff;font-size:11px;font-weight:800;white-space:nowrap;opacity:0;transition:opacity .16s ease,transform .16s ease;pointer-events:none}
.df-builder .df-email-thumb:hover .df-email-preview-label,.df-builder .df-email-thumb:focus-visible .df-email-preview-label{opacity:1;transform:translate(-50%,-50%) scale(1.02)}
.df-builder .df-email-thumb:focus-visible{outline:2px solid var(--bs-primary,#0d6efd);outline-offset:2px}
.df-builder .df-preview-modal.is-open{display:grid!important}
@media(max-width:560px){.df-builder .df-email-preview-label{opacity:.88;font-size:10px;padding:4px 7px}}
@media(prefers-reduced-motion:reduce){.df-builder .df-email-choice,.df-builder .df-email-preview-label{transition:none}}


/* Forms 1.3.11: explicit, delegated email facsimile preview controls. */
.df-builder .df-email-choice-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:7px}
.df-builder .df-email-radio{display:flex;align-items:center;gap:7px;min-width:0;font-size:12px;font-weight:800}
.df-builder .df-email-preview-btn{border:0;background:transparent;color:var(--bs-link-color,#0d6efd);font-size:11px;font-weight:800;padding:3px 5px;border-radius:4px;cursor:pointer;white-space:nowrap}
.df-builder .df-email-preview-btn:hover,.df-builder .df-email-preview-btn:focus-visible{background:color-mix(in srgb,var(--bs-primary,#0d6efd) 10%,transparent);outline:none}
.df-builder .df-email-preview-label{opacity:.9;pointer-events:none}
.df-builder .df-email-thumb:hover .df-email-preview-label,.df-builder .df-email-thumb:focus-visible .df-email-preview-label{opacity:1}
.df-preview-modal.is-open{display:grid!important;z-index:2147483000!important}
@media(max-width:560px){.df-builder .df-email-choice-foot{align-items:flex-start;flex-direction:column}.df-builder .df-email-preview-btn{padding-left:0}}


/* Forms 1.3.12: self-contained live email preview modal. */
.df-live-preview-modal{position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:20px;pointer-events:auto}
.df-live-preview-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.68);backdrop-filter:blur(2px)}
.df-live-preview-dialog{position:relative;z-index:1;width:min(860px,calc(100vw - 32px));max-height:calc(100vh - 32px);display:flex;flex-direction:column;background:var(--bs-body-bg,#fff);color:var(--bs-body-color,#1f2937);border:1px solid var(--bs-border-color,#d9dee5);border-radius:14px;box-shadow:0 24px 70px rgba(0,0,0,.28);overflow:hidden}
.df-live-preview-head,.df-live-preview-foot{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;background:var(--bs-tertiary-bg,#f6f7f9);border-bottom:1px solid var(--bs-border-color,#d9dee5)}
.df-live-preview-foot{justify-content:flex-end;border-top:1px solid var(--bs-border-color,#d9dee5);border-bottom:0}
.df-live-preview-body{padding:18px;overflow:auto;background:var(--bs-body-bg,#fff)}
.df-live-preview-close{cursor:pointer}
button.df-live-preview-close{min-width:38px;min-height:38px;border:1px solid var(--bs-border-color,#d9dee5);border-radius:8px;background:var(--bs-body-bg,#fff);color:inherit;font-weight:800}
@media(max-width:560px){.df-live-preview-modal{padding:10px}.df-live-preview-dialog{width:calc(100vw - 20px);max-height:calc(100vh - 20px)}.df-live-preview-body{padding:12px}}


/* Forms 1.3.13: compact visual field builder. */
.df-builder-workspace{display:grid;grid-template-columns:minmax(0,1fr) minmax(300px,360px);gap:14px;align-items:start}
.df-form-canvas-panel,.df-properties-panel{min-width:0;border:1px solid var(--df-border);border-radius:8px;background:var(--bs-body-bg,#fff)}
.df-form-canvas-panel{padding:14px}.df-properties-panel{position:sticky;top:12px;max-height:calc(100vh - 32px);overflow:auto}
.df-properties-title{padding:13px 14px;border-bottom:1px solid var(--df-border);background:var(--bs-tertiary-bg,#f7f8fa)}
.df-properties-title strong,.df-properties-title span{display:block}.df-properties-title span{margin-top:2px;color:var(--bs-secondary-color,#667085);font-size:11px}
.df-builder-workspace .df-layout-canvas{gap:7px}.df-builder-workspace .df-layout-row{position:relative;min-height:54px;padding:5px;gap:6px;border-style:solid;background:color-mix(in srgb,var(--bs-tertiary-bg,#f7f8fa) 38%,transparent)}
.df-builder-workspace .df-layout-row.is-over{border-color:var(--df);box-shadow:inset 0 0 0 1px var(--df)}
.df-builder-workspace .df-layout-card{min-width:110px;min-height:42px;padding:5px 7px;gap:7px;border-radius:6px;box-shadow:none;transition:border-color .16s,box-shadow .16s,background .16s}
.df-builder-workspace .df-layout-card:hover,.df-builder-workspace .df-layout-card.is-active{border-color:var(--df);box-shadow:0 0 0 2px color-mix(in srgb,var(--df) 12%,transparent)}
.df-builder-workspace .df-layout-card strong{font-size:13px}.df-builder-workspace .df-layout-handle{cursor:grab;font-size:16px;line-height:1;letter-spacing:-3px;padding:7px 3px}
.df-layout-meta{display:flex;align-items:center;gap:4px;margin-left:auto}.df-layout-type{max-width:92px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:3px 6px;border-radius:999px;background:color-mix(in srgb,var(--df) 9%,transparent);color:var(--df);font-size:10px;font-weight:800}
.df-builder-workspace .df-layout-card select{min-width:62px;min-height:29px;height:29px;padding:2px 5px;font-size:11px}
.df-layout-actions{display:flex;align-items:center;gap:2px}.df-layout-actions button{width:29px;height:29px;padding:0;border:0;border-radius:5px;background:transparent;color:inherit;cursor:pointer;font-size:14px}.df-layout-actions button:hover{background:var(--bs-tertiary-bg,#eef1f5);color:var(--df)}.df-layout-actions .df-canvas-remove:hover{color:#b42318}
.df-builder-workspace .df-layout-newrow{display:none;min-height:34px;margin-top:7px;border-color:var(--df);color:var(--df);background:color-mix(in srgb,var(--df) 6%,transparent);font-weight:800}.df-builder-workspace.is-dragging .df-layout-newrow{display:flex}
.df-add-field-main{width:100%;min-height:38px;margin-top:9px;border:1px dashed color-mix(in srgb,var(--df) 70%,var(--df-border));border-radius:7px;background:color-mix(in srgb,var(--df) 4%,var(--bs-body-bg,#fff));color:var(--df);font-weight:850;cursor:pointer}.df-add-field-main:hover{background:color-mix(in srgb,var(--df) 9%,var(--bs-body-bg,#fff));border-style:solid}
.df-properties-panel .df-selected-empty{margin:12px;padding:20px 12px}.df-properties-panel .df-selected-item{display:none;border:0;border-radius:0}.df-properties-panel .df-selected-item.is-open{display:block}.df-properties-panel .df-selected-top{padding:9px 11px}.df-properties-panel .df-field-toggle{pointer-events:none}.df-properties-panel .df-field-chevron{display:none}.df-properties-panel .df-selected-config{grid-template-columns:1fr;gap:8px;padding:11px}.df-properties-panel .df-selected-config .full,.df-properties-panel .df-config-panel,.df-properties-panel .df-condition-details,.df-properties-panel .df-field-advanced{grid-column:auto}.df-properties-panel .df-selected-config input:not([type=checkbox]):not([type=radio]),.df-properties-panel .df-selected-config select{min-height:35px;padding:6px 8px}.df-properties-panel .df-mini-actions button[data-act="up"],.df-properties-panel .df-mini-actions button[data-act="down"]{display:none}
.df-field-width-pills{display:grid;grid-template-columns:repeat(3,1fr);gap:5px}.df-field-width-pills button{min-height:31px;border:1px solid var(--df-border);border-radius:5px;background:var(--bs-body-bg,#fff);color:inherit;font-size:11px;font-weight:800;cursor:pointer}.df-field-width-pills button.is-active{border-color:var(--df);background:color-mix(in srgb,var(--df) 10%,var(--bs-body-bg,#fff));color:var(--df)}
@media(max-width:1050px){.df-builder-workspace{grid-template-columns:1fr}.df-properties-panel{position:static;max-height:none}}
@media(max-width:800px){.df-builder-workspace .df-layout-row{flex-direction:row;flex-wrap:wrap}.df-builder-workspace .df-layout-card{width:100%!important}.df-layout-type{display:none}}
@media(max-width:560px){.df-form-canvas-panel{padding:10px}.df-builder-workspace .df-layout-card{min-height:46px}.df-layout-actions button{width:32px;height:32px}.df-builder-workspace .df-layout-card select{min-width:58px}.df-layout-visual-head .df-switch{width:100%}}


/* Forms 1.3.14: balanced rows, safer editing and clearer controls. */
.df-editor-toolbar{position:sticky;top:0;z-index:40;display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 12px;padding:8px;border:1px solid var(--df-border);border-radius:8px;background:color-mix(in srgb,var(--bs-body-bg,#fff) 94%,transparent);backdrop-filter:blur(7px)}
.df-editor-toolbar button{min-height:34px;padding:6px 11px;border:1px solid var(--df-border);background:var(--bs-body-bg,#fff);color:inherit;font-weight:750;cursor:pointer}.df-editor-toolbar button:first-child{border-radius:6px 0 0 6px}.df-editor-toolbar button:last-child{border-radius:0 6px 6px 0}.df-editor-toolbar button:disabled{opacity:.42;cursor:not-allowed}.df-history-actions,.df-edit-mode{display:flex}
.df-builder.is-locked #df-builder-form input:not([type=hidden]),.df-builder.is-locked #df-builder-form select,.df-builder.is-locked #df-builder-form textarea{opacity:.72}.df-builder.is-locked .df-layout-handle{cursor:not-allowed}.df-builder.is-locked .df-layout-card{box-shadow:none}
.df-required-badge{display:inline-flex;align-items:center;padding:3px 7px;border-radius:999px;background:#fee4e8;color:#c5003c;font-size:10px;font-weight:850;white-space:nowrap}.df-summary-chip.df-required-badge{border-color:#f5a3ba;background:#fee4e8;color:#b90038}
.df-canvas-remove{color:#b42318!important}.df-main-settings,.df-condition-details,.df-tax-links{border:1px solid var(--df-border);border-radius:6px;background:color-mix(in srgb,var(--bs-tertiary-bg,#f7f8fa) 45%,transparent)}.df-main-settings>summary,.df-condition-details>summary,.df-tax-links>summary{cursor:pointer;padding:10px 11px;color:#2869b2;font-weight:800}.df-main-settings-body,.df-condition-body,.df-tax-links-body{padding:0 11px 11px}.df-main-settings-grid{display:grid;gap:8px}.df-condition-controls{display:grid;grid-template-columns:1fr;gap:8px;margin-top:8px}.df-condition-details .df-condition-row{grid-template-columns:1fr}.df-condition-details [data-add-condition]{margin-top:9px}
.df-status-row{grid-template-columns:minmax(0,1fr) 110px 34px}.df-status-row.is-conflict input[data-status-label]{border-color:#dc3545;box-shadow:0 0 0 2px rgba(220,53,69,.12)}.df-status-warning{margin:8px 0;padding:8px 10px;border:1px solid #dc3545;border-radius:6px;background:#fff1f3;color:#a40024;font-weight:700}
.df-email-templates{grid-template-columns:repeat(6,minmax(0,1fr))!important}.df-email-thumb{width:100%;height:105px;padding:0!important;background:#eef1f5!important;border:0!important}.df-email-thumb-frame{display:block;width:500%;height:525px;border:0;transform:scale(.2);transform-origin:top left;pointer-events:none;background:#fff}.df-email-choice-foot{justify-content:flex-start}.df-email-preview-btn{display:none!important}.df-email-preview-label{opacity:0!important}.df-email-thumb:hover .df-email-preview-label,.df-email-thumb:focus-visible .df-email-preview-label{opacity:1!important}
@media(max-width:900px){.df-email-templates{grid-template-columns:repeat(3,minmax(0,1fr))!important}.df-email-thumb{height:120px}.df-email-thumb-frame{transform:scale(.2)}}
@media(max-width:560px){.df-editor-toolbar{align-items:stretch;flex-direction:column}.df-editor-toolbar>div{display:grid;grid-template-columns:1fr 1fr}.df-email-templates{grid-template-columns:1fr!important}.df-email-thumb{height:150px}.df-email-thumb-frame{transform:scale(.25)}}


/* Forms 1.3.15: explicit light-mode surfaces and compact field layout accordion. */
.df-layout-settings{grid-column:1/-1;border:1px solid var(--df-border);border-radius:6px;background:color-mix(in srgb,var(--bs-tertiary-bg,#f7f8fa) 45%,transparent);overflow:hidden}
.df-layout-settings>summary{cursor:pointer;list-style:none;display:flex;align-items:center;justify-content:space-between;padding:10px 11px;color:#2869b2;font-weight:800}
.df-layout-settings>summary::-webkit-details-marker{display:none}
.df-layout-settings>summary:after{content:'⌄';font-size:12px;transition:transform .2s ease}
.df-layout-settings[open]>summary:after{transform:rotate(180deg)}
.df-layout-settings-body{display:grid;gap:12px;padding:0 11px 11px}
.df-field-width-block>label{display:block;margin-bottom:7px;font-weight:750}

/* Joomla can be light while the operating system prefers dark. These final rules make the Builder follow Joomla, not the OS. */
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-layout-row{
  background:#f6f7f9!important;border-color:#d9dee5!important;color:#1f2937!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-layout-card{
  background:#fff!important;color:#1f2937!important;border-color:#d9dee5!important;box-shadow:0 1px 2px rgba(15,23,42,.05)!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-layout-card strong{color:#1f2937!important}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-layout-handle{color:#7b8796!important}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-layout-card select{
  background:#fff!important;color:#1f2937!important;border-color:#cfd6df!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-layout-newrow{
  background:#fff!important;color:#667085!important;border-color:#cfd6df!important;
}

html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-subbox,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-block,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-block-body,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-choice,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-special,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-additional-card{
  background:#fff!important;color:#1f2937!important;border-color:#d9dee5!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-block>summary{
  background:#f6f7f9!important;color:#1f2937!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-subbox h4,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-block summary,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-block label,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-subbox label,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-check,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-label-info,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-email-choice-foot,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-status-color-value{
  color:#1f2937!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-note{color:#667085!important}

html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-status-row input:not([type=color]),
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-status-remove,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-column-item,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-field input:not([type=checkbox]):not([type=radio]):not([type=color]),
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-field textarea,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-field select,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-codearea,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-tokenbar select{
  background:#fff!important;color:#1f2937!important;border-color:#cfd6df!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-codearea::placeholder,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder input::placeholder,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder textarea::placeholder{color:#8a94a3!important;opacity:1}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-column-item{color:#1f2937!important}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-status-remove{color:#b42318!important;background:#fff!important;border-color:#e3a3aa!important}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-status-remove:hover,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-status-remove:focus-visible{background:#fff1f3!important;color:#a10f25!important;border-color:#dc3545!important}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-warning{background:#fff8e8!important;color:#5f4600!important}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-layout-settings,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-main-settings,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-condition-details,
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-tax-links{
  background:#f8f9fb!important;color:#1f2937!important;border-color:#d9dee5!important;
}


/* Forms 1.3.16: toolbar contrast, neutral navigation and readable closed-state labels. */
.df-editor-toolbar{
  display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;
  margin:0 0 12px;padding:8px 10px;border:1px solid var(--df-border);border-radius:8px;
  background:var(--bs-body-bg,#fff);
}
.df-editor-toolbar .df-history-actions,.df-editor-toolbar .df-edit-mode{display:flex;align-items:center;flex-wrap:wrap}
.df-editor-toolbar button{transition:background .16s ease,border-color .16s ease,color .16s ease,opacity .16s ease}
.df-editor-toolbar .df-save-top{
  min-height:34px;margin-left:8px;padding:6px 13px;border:1px solid var(--df)!important;border-radius:6px!important;
  background:var(--df)!important;color:#fff!important;font-weight:800;cursor:pointer;
}
.df-editor-toolbar .df-save-top:hover,.df-editor-toolbar .df-save-top:focus-visible{background:var(--df-dark)!important;border-color:var(--df-dark)!important;color:#fff!important}
.df-editor-toolbar .df-save-top:disabled{opacity:.46!important;cursor:not-allowed!important}

/* Light mode: toolbar and navigation stay neutral, like Joomla's Menu button. */
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-editor-toolbar,
html[data-bs-theme="light"] .df-builder .df-editor-toolbar{
  background:#fff!important;border-color:#d9dee5!important;color:#1f2937!important;
}



html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-back-btn,
html[data-bs-theme="light"] .df-builder .df-back-btn{
  background:#fff!important;color:#1f2937!important;border-color:#d9dee5!important;box-shadow:none!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-back-btn:hover,
html[data-bs-theme="light"] .df-builder .df-back-btn:hover{
  background:#f6f7f9!important;color:#1f2937!important;border-color:#cfd6df!important;
}

/* The two closed-form labels must remain readable on the pale pink semantic panel. */
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-closed-box label,
html[data-bs-theme="light"] .df-builder .df-closed-box label{
  color:#7a1631!important;opacity:1!important;font-weight:750!important;
}

/* Dark mode: no white action strip and no washed-out controls. */
html[data-bs-theme="dark"] .df-builder .df-editor-toolbar,
body[data-bs-theme="dark"] .df-builder .df-editor-toolbar,
html[data-color-scheme="dark"] .df-builder .df-editor-toolbar{
  background:#1f2937!important;border-color:#475569!important;color:#f8fafc!important;
}



html[data-bs-theme="dark"] .df-builder .df-back-btn,
body[data-bs-theme="dark"] .df-builder .df-back-btn,
html[data-color-scheme="dark"] .df-builder .df-back-btn{
  background:#1f2937!important;color:#f8fafc!important;border-color:#475569!important;box-shadow:none!important;
}
html[data-bs-theme="dark"] .df-builder .df-back-btn:hover,
body[data-bs-theme="dark"] .df-builder .df-back-btn:hover,
html[data-color-scheme="dark"] .df-builder .df-back-btn:hover{
  background:#273548!important;color:#fff!important;border-color:#64748b!important;
}
@media(max-width:800px){
  .df-editor-toolbar{align-items:stretch}
  .df-editor-toolbar .df-edit-mode{margin-left:auto}
  .df-editor-toolbar .df-save-top{margin-left:6px}
}


/* Forms 1.3.17: quick-model save action and light/dark contrast fixes. */
.df-layout-head-actions{display:flex;align-items:center;justify-content:flex-end;gap:12px;flex-wrap:wrap}
.df-save-structure{white-space:nowrap}
.df-saved-quick-heading{margin:13px 0 7px;font-size:12px;font-weight:850;color:var(--bs-secondary-color,#667085);text-transform:uppercase;letter-spacing:.04em}
.df-saved-quick-row{margin-bottom:8px}
.df-saved-quick-item{display:inline-flex;align-items:stretch;border:1px solid var(--df-border);border-radius:6px;overflow:hidden;background:var(--bs-body-bg,#fff)}
.df-saved-quick-item button{border:0!important;border-radius:0!important;box-shadow:none!important}
.df-saved-quick-use{background:var(--bs-body-bg,#fff)!important;color:inherit!important}
.df-saved-quick-use.is-active{color:var(--df)!important;background:color-mix(in srgb,var(--df) 7%,var(--bs-body-bg,#fff))!important}
.df-saved-quick-delete{min-width:34px!important;padding:0 8px!important;background:transparent!important;color:#b42318!important;border-left:1px solid var(--df-border)!important}
.df-saved-quick-delete:hover{background:#fff1f3!important;color:#a40024!important}

/* Library category pills: neutral by default, red only as a selection accent. */
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-library-tab,
html[data-bs-theme="light"] .df-builder .df-library-tab{
 background:#f6f7f9!important;color:#1f2937!important;border-color:#d9dee5!important;box-shadow:none!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-library-tab:hover,
html[data-bs-theme="light"] .df-builder .df-library-tab:hover{
 background:#eef1f4!important;color:#1f2937!important;border-color:#cfd6df!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-library-tab.is-active,
html[data-bs-theme="light"] .df-builder .df-library-tab.is-active{
 background:#fff!important;color:var(--df)!important;border-color:var(--df)!important;box-shadow:0 0 0 2px color-mix(in srgb,var(--df) 10%,transparent)!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-library-tab-count,
html[data-bs-theme="light"] .df-builder .df-library-tab-count{
 background:#e7ebf0!important;color:#344054!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-library-tab.is-active .df-library-tab-count,
html[data-bs-theme="light"] .df-builder .df-library-tab.is-active .df-library-tab-count{
 background:#ffe5ec!important;color:var(--df)!important;
}

/* Columns list: never inherit white text while Joomla is in light mode. */
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-column-item,
html[data-bs-theme="light"] .df-builder .df-column-item{
 background:#fff!important;color:#1f2937!important;border-color:#d9dee5!important;
}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-column-item *,
html[data-bs-theme="light"] .df-builder .df-column-item *{color:#1f2937!important;opacity:1!important}
html:not([data-bs-theme="dark"]):not([data-color-scheme="dark"]) body:not([data-bs-theme="dark"]) .df-builder .df-column-item:has(input:checked),
html[data-bs-theme="light"] .df-builder .df-column-item:has(input:checked){background:#f8fafc!important}

/* Status delete is destructive: filled red removes ambiguity. */
.df-builder .df-status-remove{background:#dc3545!important;border-color:#dc3545!important;color:#fff!important;font-weight:850;cursor:pointer}
.df-builder .df-status-remove:hover,.df-builder .df-status-remove:focus-visible{background:#b4232f!important;border-color:#b4232f!important;color:#fff!important}

html[data-bs-theme="dark"] .df-builder .df-library-tab,
body[data-bs-theme="dark"] .df-builder .df-library-tab,
html[data-color-scheme="dark"] .df-builder .df-library-tab{background:#1f2937!important;color:#f8fafc!important;border-color:#475569!important}
html[data-bs-theme="dark"] .df-builder .df-library-tab.is-active,
body[data-bs-theme="dark"] .df-builder .df-library-tab.is-active,
html[data-color-scheme="dark"] .df-builder .df-library-tab.is-active{background:#111827!important;color:#ff91ad!important;border-color:#e60046!important;box-shadow:0 0 0 2px rgba(230,0,70,.16)!important}
html[data-bs-theme="dark"] .df-builder .df-library-tab-count,
body[data-bs-theme="dark"] .df-builder .df-library-tab-count,
html[data-color-scheme="dark"] .df-builder .df-library-tab-count{background:#334155!important;color:#f8fafc!important}
html[data-bs-theme="dark"] .df-builder .df-column-item,
body[data-bs-theme="dark"] .df-builder .df-column-item,
html[data-color-scheme="dark"] .df-builder .df-column-item{background:#111827!important;color:#f8fafc!important;border-color:#475569!important}
html[data-bs-theme="dark"] .df-builder .df-column-item *,
body[data-bs-theme="dark"] .df-builder .df-column-item *,
html[data-color-scheme="dark"] .df-builder .df-column-item *{color:#f8fafc!important;opacity:1!important}
@media(max-width:800px){.df-layout-head-actions{width:100%;justify-content:flex-start}.df-save-structure{order:2}}


/* Forms 1.3.18: save recovery, compact properties and confirmation controls. */
.df-save-structure{font-weight:800!important}
.df-closed-box[hidden]{display:none!important}
.df-success-editor{min-height:58px!important;resize:vertical}
.df-success-options{display:flex;align-items:end;gap:18px;flex-wrap:wrap;margin-top:8px}
.df-success-options>label:not(.df-switch){display:grid;gap:5px;min-width:190px;font-weight:750}
.df-success-options select{min-height:38px}
.df-success-modal-switch{margin:0 0 3px!important}
.df-save-notice,.df-draft-banner{margin:0 0 12px;padding:10px 12px;border:1px solid #d9dee5;border-radius:8px;background:#f6f7f9;color:#1f2937}
.df-save-notice{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
.df-save-notice.is-success{border-color:#9bd7b2;background:#edf9f1;color:#14532d}.df-save-notice.is-error{border-color:#f2a7b8;background:#fff1f4;color:#7a1631}.df-save-notice[hidden],.df-draft-banner[hidden]{display:none!important}
.df-draft-banner{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;border-color:#f0c36c;background:#fff9e8}.df-draft-banner>div:first-child{display:flex;gap:4px;flex-wrap:wrap}.df-draft-actions{display:flex;gap:8px}
.df-selected-config{gap:8px!important}.df-selected-config details.full{margin:0!important}.df-selected-config details.full>summary{min-height:44px!important;padding:10px 12px!important;font-size:16px!important}.df-main-settings-body,.df-layout-settings-body{padding:10px 12px!important}.df-main-settings-grid{gap:8px 10px!important}.df-selected-config-wrap{padding-top:8px!important}.df-properties-panel .df-selected-item{margin-bottom:0!important}
html[data-bs-theme="dark"] .df-save-notice,body[data-bs-theme="dark"] .df-save-notice,html[data-color-scheme="dark"] .df-save-notice{background:#1f2937;color:#f8fafc;border-color:#475569}.df-save-notice.is-error{color:#7a1631}.df-save-notice.is-success{color:#14532d}
html[data-bs-theme="dark"] .df-draft-banner,body[data-bs-theme="dark"] .df-draft-banner,html[data-color-scheme="dark"] .df-draft-banner{background:#332b18;color:#fff7d6;border-color:#8a6a25}
@media(max-width:800px){.df-success-options{align-items:stretch}.df-success-options>label{width:100%}.df-draft-actions{width:100%}.df-draft-actions button{flex:1}}


/* Forms 1.3.24: single button system. Do not derive light buttons from Bootstrap/OS colour variables. */
.df-builder,.df-action-modal,.df-live-preview-modal,.df-preview-modal{
  --df-btn-bg:#fff;
  --df-btn-text:#1f2937;
  --df-btn-border:#d9dee5;
  --df-btn-hover-bg:#f6f7f9;
  --df-btn-hover-border:#cfd6df;
}
html[data-bs-theme="dark"] .df-builder,body[data-bs-theme="dark"] .df-builder,html[data-color-scheme="dark"] .df-builder,
html[data-bs-theme="dark"] .df-action-modal,body[data-bs-theme="dark"] .df-action-modal,html[data-color-scheme="dark"] .df-action-modal,
html[data-bs-theme="dark"] .df-live-preview-modal,body[data-bs-theme="dark"] .df-live-preview-modal,html[data-color-scheme="dark"] .df-live-preview-modal,
html[data-bs-theme="dark"] .df-preview-modal,body[data-bs-theme="dark"] .df-preview-modal,html[data-color-scheme="dark"] .df-preview-modal{
  --df-btn-bg:#111827;
  --df-btn-text:#f8fafc;
  --df-btn-border:#475569;
  --df-btn-hover-bg:#273548;
  --df-btn-hover-border:#64748b;
}
.df-builder .df-btn,.df-action-modal .df-btn,.df-live-preview-modal .df-btn,.df-preview-modal .df-btn{
  background:var(--df-btn-bg)!important;
  color:var(--df-btn-text)!important;
  border-color:var(--df-btn-border)!important;
  box-shadow:none!important;
}
.df-builder .df-btn:hover,.df-builder .df-btn:focus-visible,
.df-action-modal .df-btn:hover,.df-action-modal .df-btn:focus-visible,
.df-live-preview-modal .df-btn:hover,.df-live-preview-modal .df-btn:focus-visible,
.df-preview-modal .df-btn:hover,.df-preview-modal .df-btn:focus-visible{
  background:var(--df-btn-hover-bg)!important;
  color:var(--df-btn-text)!important;
  border-color:var(--df-btn-hover-border)!important;
}
.df-builder .df-btn.df-primary,.df-builder .df-btn.df-btn-primary,.df-builder .df-save-structure,.df-builder .df-add,
.df-action-modal .df-btn.df-primary,.df-action-modal .df-btn.df-btn-primary{
  background:var(--df)!important;
  border-color:var(--df)!important;
  color:#fff!important;
}
.df-builder .df-btn.df-primary:hover,.df-builder .df-btn.df-primary:focus-visible,
.df-builder .df-btn.df-btn-primary:hover,.df-builder .df-btn.df-btn-primary:focus-visible,
.df-builder .df-save-structure:hover,.df-builder .df-save-structure:focus-visible,.df-builder .df-add:hover,
.df-action-modal .df-btn.df-primary:hover,.df-action-modal .df-btn.df-primary:focus-visible,
.df-action-modal .df-btn.df-btn-primary:hover,.df-action-modal .df-btn.df-btn-primary:focus-visible{
  background:var(--df-dark)!important;
  border-color:var(--df-dark)!important;
  color:#fff!important;
}
.df-builder .df-btn.df-danger,.df-builder .df-btn.df-btn-danger{
  background:#fff1f3!important;
  border-color:#e69aa7!important;
  color:#a4132d!important;
}
.df-builder .df-btn.df-danger:hover,.df-builder .df-btn.df-btn-danger:hover,
.df-builder .df-btn.df-danger:focus-visible,.df-builder .df-btn.df-btn-danger:focus-visible{
  background:#dc3545!important;
  border-color:#dc3545!important;
  color:#fff!important;
}
html[data-bs-theme="dark"] .df-builder .df-btn.df-danger,body[data-bs-theme="dark"] .df-builder .df-btn.df-danger,html[data-color-scheme="dark"] .df-builder .df-btn.df-danger,
html[data-bs-theme="dark"] .df-builder .df-btn.df-btn-danger,body[data-bs-theme="dark"] .df-builder .df-btn.df-btn-danger,html[data-color-scheme="dark"] .df-builder .df-btn.df-btn-danger{
  background:#4a1e2b!important;
  border-color:#a94e68!important;
  color:#ffc0d0!important;
}
.df-summary-chip{background:#eef1f4!important;border-color:#d5dbe3!important;color:#4b5563!important;font-weight:750}.df-summary-chip.df-required-badge,.df-required-badge{background:#fff0f4!important;border-color:#f1a7b9!important;color:#a4133c!important}
.df-selected-config details.full>summary,.df-main-settings>summary,.df-layout-settings>summary,.df-condition-details>summary,.df-tax-links>summary{min-height:40px!important;padding:8px 10px!important;font-size:14px!important;line-height:1.25!important}.df-main-settings-body,.df-layout-settings-body,.df-condition-body,.df-tax-links-body{padding:8px 10px 10px!important}.df-selected-config{gap:6px!important;padding:9px!important}.df-main-settings-grid,.df-condition-controls{gap:6px 8px!important}.df-selected-config-wrap{padding-top:5px!important}
.df-builder-workspace .df-layout-row{display:grid!important;align-items:stretch!important}.df-layout-card{overflow:visible}.df-layout-drop-guide{position:absolute;inset:3px;z-index:15;display:none;grid-template-columns:1fr 1fr 1fr;gap:4px;pointer-events:none}.df-builder-workspace.is-dragging .df-layout-card:not(.dragging) .df-layout-drop-guide{display:grid;pointer-events:auto}.df-layout-drop-guide span{display:flex;align-items:center;justify-content:center;text-align:center;padding:4px;border:1px dashed #4b8fe2;border-radius:5px;background:rgba(239,246,255,.94);color:#1d4f91;font-size:10px;font-weight:850;cursor:copy}.df-layout-drop-guide span.is-over{background:#dbeafe;border-style:solid;box-shadow:inset 0 0 0 1px #2563eb}.df-layout-drop-guide [data-drop-newrow]{background:rgba(238,242,255,.96);color:#4338ca;border-color:#818cf8}
.df-email-choice-foot{justify-content:space-between!important}.df-email-preview-btn{display:inline-flex!important;align-items:center!important;justify-content:center!important;border:0!important;background:transparent!important;color:#2869b2!important;font-size:11px!important;font-weight:800!important;padding:4px 6px!important;cursor:pointer!important}.df-email-preview-btn:hover{text-decoration:underline}.df-email-preview-label{opacity:.88!important}
.df-action-modal{position:fixed;inset:0;z-index:30000;display:grid;place-items:center;padding:16px}.df-action-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.66);backdrop-filter:blur(2px)}.df-action-dialog{position:relative;z-index:1;width:min(520px,calc(100vw - 28px));background:var(--bs-body-bg,#fff);color:var(--bs-body-color,#1f2937);border:1px solid var(--bs-border-color,#d9dee5);border-radius:12px;box-shadow:0 24px 70px rgba(0,0,0,.3);overflow:hidden}.df-action-head,.df-action-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 15px;border-bottom:1px solid var(--bs-border-color,#d9dee5)}.df-action-head strong{font-size:17px}.df-action-body{padding:16px}.df-action-body p{margin:0 0 12px;line-height:1.5}.df-action-foot{justify-content:flex-end;border-top:1px solid var(--bs-border-color,#d9dee5);border-bottom:0}.df-action-x{width:34px;height:34px;border:1px solid var(--bs-border-color,#d9dee5);border-radius:7px;background:transparent;color:inherit;font-size:21px;cursor:pointer}.df-action-input-label{display:grid;gap:6px;font-weight:750}.df-action-input{width:100%;min-height:42px;border:1px solid var(--bs-border-color,#d5dbe3);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;padding:9px 10px}.df-builder .df-action-danger,.df-action-modal .df-action-danger{background:#dc3545!important;border-color:#dc3545!important;color:#fff!important}.df-action-modal .df-action-danger:hover{background:#b4232f!important;border-color:#b4232f!important;color:#fff!important}
html[data-bs-theme="dark"] .df-summary-chip,body[data-bs-theme="dark"] .df-summary-chip,html[data-color-scheme="dark"] .df-summary-chip{background:#253140!important;border-color:#536174!important;color:#e5eaf0!important}html[data-bs-theme="dark"] .df-summary-chip.df-required-badge,body[data-bs-theme="dark"] .df-summary-chip.df-required-badge,html[data-color-scheme="dark"] .df-summary-chip.df-required-badge{background:#4a1e2b!important;border-color:#a94e68!important;color:#ffc0d0!important}html[data-bs-theme="dark"] .df-layout-drop-guide span,body[data-bs-theme="dark"] .df-layout-drop-guide span{background:rgba(25,43,66,.96);color:#c8ddff;border-color:#6ba3e8}html[data-bs-theme="dark"] .df-layout-drop-guide [data-drop-newrow],body[data-bs-theme="dark"] .df-layout-drop-guide [data-drop-newrow]{background:rgba(43,39,82,.97);color:#d9d5ff;border-color:#8b86e8}
@media(max-width:800px){.df-builder-workspace .df-layout-row{grid-template-columns:1fr!important}.df-layout-drop-guide{grid-template-columns:1fr 1fr 1fr}.df-layout-drop-guide span{font-size:9px}}


/* Forms 1.3.25: stable full-width custom-code editor and runtime diagnostics. */
.df-custom-code-grid{display:grid!important;grid-template-columns:minmax(0,1fr)!important;gap:14px!important;width:100%!important;max-width:none!important}
.df-custom-code-grid>.df-field{width:100%!important;max-width:none!important;min-width:0!important}
.df-custom-code-grid .df-codearea{display:block;width:100%!important;max-width:none!important}


/* Forms 1.3.67: importazione campi con AI, senza API obbligatoria. */
.df-field-entry-actions{display:flex;gap:9px;align-items:stretch;margin-top:10px}.df-field-entry-actions>.df-add-field-main,.df-field-entry-actions>.df-ai-import-main{flex:1;min-width:0}.df-ai-import-main{display:flex;align-items:center;justify-content:center;gap:7px;min-height:43px;border:1px solid color-mix(in srgb,#7c3aed 72%,var(--df-border));border-radius:7px;background:color-mix(in srgb,#7c3aed 7%,var(--bs-body-bg,#fff));color:color-mix(in srgb,#7c3aed 84%,var(--bs-body-color,#1f2937));font-weight:850;cursor:pointer;transition:background .16s ease,border-color .16s ease,transform .16s ease}.df-ai-import-main:hover,.df-ai-import-main:focus-visible{background:color-mix(in srgb,#7c3aed 13%,var(--bs-body-bg,#fff));border-color:#7c3aed;outline:none}.df-ai-modal[hidden]{display:none!important}.df-ai-modal{position:fixed;inset:0;z-index:2147483600;display:grid;place-items:center;padding:18px}.df-ai-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.70);backdrop-filter:blur(2px)}.df-ai-dialog{position:relative;z-index:1;width:min(1060px,calc(100vw - 30px));max-height:calc(100vh - 30px);display:flex;flex-direction:column;background:var(--bs-body-bg,#fff);color:var(--bs-body-color,#1f2937);border:1px solid var(--bs-border-color,#d9dee5);border-radius:14px;box-shadow:0 26px 80px rgba(0,0,0,.30);overflow:hidden}.df-ai-head,.df-ai-foot{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 17px;background:var(--bs-tertiary-bg,#f6f7f9);border-bottom:1px solid var(--bs-border-color,#d9dee5)}.df-ai-foot{justify-content:flex-end;border-top:1px solid var(--bs-border-color,#d9dee5);border-bottom:0}.df-ai-head-title{display:flex;flex-direction:column;gap:2px}.df-ai-head-title strong{font-size:18px}.df-ai-close{width:38px;height:38px;border:1px solid var(--bs-border-color,#d9dee5);border-radius:8px;background:var(--bs-body-bg,#fff);color:inherit;font-size:22px;line-height:1;cursor:pointer}.df-ai-body{padding:17px;overflow:auto}.df-ai-intro{margin:0 0 14px;color:var(--bs-secondary-color,#667085)}.df-ai-modes{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-bottom:14px}.df-ai-mode{border:1px solid var(--df-border);border-radius:10px;padding:13px;background:var(--bs-body-bg,#fff)}.df-ai-mode.is-active{border-color:#7c3aed;box-shadow:0 0 0 2px color-mix(in srgb,#7c3aed 12%,transparent)}.df-ai-mode.is-disabled{opacity:.72;background:var(--bs-tertiary-bg,#f7f8fa)}.df-ai-mode-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:5px}.df-ai-badge{display:inline-flex;align-items:center;min-height:22px;padding:0 8px;border-radius:999px;background:var(--bs-tertiary-bg,#f1f3f5);font-size:11px;font-weight:850}.df-ai-badge-free{background:color-mix(in srgb,#198754 12%,transparent);color:#198754}.df-ai-badge-soon{background:color-mix(in srgb,#6c757d 12%,transparent);color:var(--bs-secondary-color,#667085)}.df-ai-workflow{display:grid;grid-template-columns:1fr;gap:14px}.df-ai-box{border:1px solid var(--df-border);border-radius:10px;padding:14px;background:var(--bs-body-bg,#fff)}.df-ai-box h4{margin:0 0 8px;font-size:15px}.df-ai-steps{margin:0 0 12px;padding-left:20px;color:var(--bs-secondary-color,#667085)}.df-ai-steps li+li{margin-top:4px}.df-ai-actions{display:flex;gap:8px;flex-wrap:wrap}.df-ai-actions .df-btn{min-height:38px}.df-ai-description{width:100%;min-height:150px;border:1px solid var(--df-border);border-radius:7px;background:var(--bs-body-bg,#fff);color:inherit;padding:10px 11px;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;resize:vertical}.df-ai-description{min-height:84px;font:inherit}.df-ai-file-row{display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin:9px 0}.df-ai-file-row input[type=file]{max-width:100%}.df-ai-error{margin-top:9px;padding:9px 10px;border:1px solid color-mix(in srgb,#dc3545 45%,var(--df-border));border-radius:7px;background:color-mix(in srgb,#dc3545 7%,var(--bs-body-bg,#fff));color:#b42332;font-weight:750}.df-ai-preview{margin-top:15px;border-top:1px solid var(--df-border);padding-top:14px}.df-ai-preview-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:10px}.df-ai-preview-summary{font-weight:850}.df-ai-preview-tools{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.df-ai-preview-tools select{min-height:36px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;padding:0 8px}.df-ai-preview-list{display:flex;flex-direction:column;gap:8px}.df-ai-row{display:grid;grid-template-columns:32px minmax(160px,1.4fr) minmax(120px,.9fr) 96px 92px 96px 76px;gap:8px;align-items:center;border:1px solid var(--df-border);border-radius:9px;padding:10px;background:var(--bs-body-bg,#fff)}.df-ai-row.is-duplicate{border-color:color-mix(in srgb,#f59e0b 65%,var(--df-border));background:color-mix(in srgb,#f59e0b 4%,var(--bs-body-bg,#fff))}.df-ai-row.is-low{border-style:dashed}.df-ai-row input[type=text],.df-ai-row select,.df-ai-row textarea{width:100%;min-height:36px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;padding:7px 8px}.df-ai-row-check{display:grid;place-items:center}.df-ai-row-check input{width:18px;height:18px}.df-ai-required{display:flex;align-items:center;justify-content:center;gap:5px;font-size:12px}.df-ai-required input{width:17px;height:17px}.df-ai-confidence{display:inline-flex;justify-content:center;align-items:center;min-height:25px;padding:0 7px;border-radius:999px;font-size:11px;font-weight:850}.df-ai-confidence.high{background:color-mix(in srgb,#198754 12%,transparent);color:#198754}.df-ai-confidence.medium{background:color-mix(in srgb,#f59e0b 14%,transparent);color:#9a6700}.df-ai-confidence.low{background:color-mix(in srgb,#dc3545 11%,transparent);color:#b42332}.df-ai-order{display:flex;gap:4px;justify-content:flex-end}.df-ai-order button{width:32px;height:32px;border:1px solid var(--df-border);border-radius:6px;background:var(--bs-body-bg,#fff);color:inherit;cursor:pointer}.df-ai-row-extra{grid-column:2/-1;display:grid;grid-template-columns:1fr 1fr;gap:8px}.df-ai-row-extra .df-ai-options-wrap.is-hidden{display:none}.df-ai-row-extra label{display:flex;flex-direction:column;gap:4px;font-size:11px;font-weight:800}.df-ai-row-extra textarea{min-height:58px;resize:vertical}.df-ai-warning{grid-column:2/-1;font-size:11px;color:#9a6700;font-weight:750}.df-ai-quick{margin-top:12px;border:1px dashed var(--df-border);border-radius:8px;padding:10px}.df-ai-quick summary{cursor:pointer;font-weight:850}.df-ai-quick-body{margin-top:10px}.df-ai-import-count{font-weight:850}.df-ai-direct-note{font-size:12px;color:var(--bs-secondary-color,#667085)}
[data-bs-theme="dark"] .df-ai-confidence.medium,html[data-bs-theme="dark"] .df-ai-confidence.medium{color:#ffd166}.df-builder.is-locked .df-ai-import-main{opacity:.55;cursor:not-allowed}
@media(max-width:820px){.df-ai-workflow,.df-ai-modes{grid-template-columns:1fr}.df-ai-row{grid-template-columns:30px minmax(0,1fr) minmax(110px,.7fr) 86px}.df-ai-row>.df-ai-required,.df-ai-row>.df-ai-confidence,.df-ai-row>.df-ai-order{grid-row:auto}.df-ai-row-extra,.df-ai-warning{grid-column:2/-1}.df-ai-row-extra{grid-template-columns:1fr}.df-field-entry-actions{flex-direction:column}}
@media(max-width:560px){.df-ai-modal{padding:8px}.df-ai-dialog{width:calc(100vw - 16px);max-height:calc(100vh - 16px)}.df-ai-head,.df-ai-foot,.df-ai-body{padding:12px}.df-ai-row{grid-template-columns:30px 1fr}.df-ai-row>*{grid-column:2}.df-ai-row-check{grid-column:1;grid-row:1/5}.df-ai-row-extra,.df-ai-warning{grid-column:2}.df-ai-order{justify-content:flex-start}.df-ai-foot{flex-wrap:wrap}.df-ai-foot .df-btn{flex:1}}


/* Forms 1.3.67: AI import UX cleanup. */
.df-ai-clear-file[hidden]{display:none!important}.df-ai-clear-file{flex:0 0 auto;width:36px;height:36px;display:inline-grid;place-items:center}.df-ai-clear-file svg{width:17px;height:17px;display:block}


/* Forms 1.3.67: three-mode AI selector, active 50% + 25% + 25%. */
.df-ai-modes.is-chatgpt{grid-template-columns:minmax(0,2fr) minmax(0,1fr) minmax(0,1fr)}
.df-ai-modes.is-page{grid-template-columns:minmax(0,1fr) minmax(0,2fr) minmax(0,1fr)}
.df-ai-modes.is-direct{grid-template-columns:minmax(0,1fr) minmax(0,1fr) minmax(0,2fr)}
.df-ai-mode[data-ai-mode-select]{cursor:pointer;min-width:0;transition:grid-column .18s ease,border-color .18s ease,box-shadow .18s ease,background .18s ease,opacity .18s ease}
.df-ai-mode[data-ai-mode-select]:not(.is-active){opacity:.78}
.df-ai-mode[data-ai-mode-select]:hover,.df-ai-mode[data-ai-mode-select]:focus-visible{opacity:1;border-color:#7c3aed;outline:none}
.df-ai-mode[data-ai-mode-select].is-active{opacity:1;border-color:#7c3aed;box-shadow:0 0 0 2px color-mix(in srgb,#7c3aed 12%,transparent)}
.df-ai-mode-panels{margin-top:14px}.df-ai-mode-panel[hidden]{display:none!important}.df-ai-mode-panel{display:block}
.df-ai-mode-panel>.df-ai-workflow{margin:0}.df-ai-page-panel,.df-ai-direct-panel{border:1px solid var(--df-border);border-radius:10px;padding:14px;background:var(--bs-body-bg,#fff)}
.df-ai-page-panel h4,.df-ai-direct-panel h4{margin:0 0 7px;font-size:15px}.df-ai-page-panel .df-ai-file-row{margin:12px 0 0}
@media(max-width:820px){.df-ai-modes.is-chatgpt,.df-ai-modes.is-page,.df-ai-modes.is-direct{grid-template-columns:1fr}}


/* Forms 1.3.67: section + row accordions in Struttura del modulo. */
.df-layout-accordion-toolbar{display:flex;justify-content:flex-end;gap:8px;margin:0 0 10px;flex-wrap:wrap}
.df-layout-accordion-toolbar .df-btn{min-height:34px;padding:6px 11px;font-size:12px}
.df-layout-section-group{border:1px solid var(--df-border);border-radius:12px;background:var(--bs-body-bg,#fff);overflow:hidden;margin:0 0 10px}
.df-layout-section-head{display:flex;align-items:center;gap:10px;min-height:48px;padding:8px 10px;background:color-mix(in srgb,var(--bs-secondary-bg,#f4f6f8) 82%,transparent);border:0;width:100%;text-align:left;color:inherit}
.df-layout-section-head:hover{background:color-mix(in srgb,var(--bs-secondary-bg,#eef1f4) 94%,transparent)}
.df-layout-section-chevron{width:20px;flex:0 0 20px;font-weight:900;transition:transform .16s ease}.df-layout-section-group.is-open>.df-layout-section-head .df-layout-section-chevron{transform:rotate(90deg)}
.df-layout-section-title{min-width:0;flex:1;display:flex;align-items:center;gap:9px;flex-wrap:wrap}.df-layout-section-title strong{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:min(480px,55vw)}
.df-layout-section-summary{font-size:11px;color:var(--bs-secondary-color,#667085);font-weight:650}.df-layout-section-actions{display:flex;align-items:center;gap:4px;flex:0 0 auto}
.df-layout-section-body{display:none;padding:9px}.df-layout-section-group.is-open>.df-layout-section-body{display:block}
.df-layout-row-group{border:1px solid color-mix(in srgb,var(--df-border) 82%,transparent);border-radius:9px;overflow:hidden;margin:0 0 8px}.df-layout-row-group:last-child{margin-bottom:0}
.df-layout-row-head{display:flex;align-items:center;gap:8px;width:100%;border:0;background:color-mix(in srgb,var(--bs-body-bg,#fff) 94%,var(--bs-secondary-bg,#f3f4f6));padding:7px 9px;min-height:38px;color:inherit;text-align:left}
.df-layout-row-head:hover{background:var(--bs-secondary-bg,#f4f5f7)}.df-layout-row-chevron{width:18px;flex:0 0 18px;font-weight:900;transition:transform .16s ease}.df-layout-row-group.is-open>.df-layout-row-head .df-layout-row-chevron{transform:rotate(90deg)}
.df-layout-row-label{font-size:12px;font-weight:800}.df-layout-row-summary{font-size:11px;color:var(--bs-secondary-color,#667085);margin-left:auto}.df-layout-row-body{display:none;padding:7px}.df-layout-row-group.is-open>.df-layout-row-body{display:block}
.df-layout-row-body>.df-layout-row{margin:0}.df-layout-section-empty{padding:9px 10px;font-size:12px;color:var(--bs-secondary-color,#667085)}
.df-layout-section-head.is-over,.df-layout-row-head.is-over{box-shadow:inset 0 0 0 2px #0d6efd}
@media(max-width:720px){.df-layout-section-summary,.df-layout-row-summary{display:none}.df-layout-section-head{padding:8px}.df-layout-section-title strong{max-width:48vw}}

/* Forms 1.3.67: polished AI uploads + structure settings. */
.df-field-entry-actions{display:grid!important;grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;gap:10px!important}.df-field-entry-actions>.df-add-field-main,.df-field-entry-actions>.df-ai-import-main{width:100%!important;min-height:46px!important;height:46px!important;margin:0!important;box-sizing:border-box}.df-ai-import-main>span,.df-add-field-main>span{font-size:18px;line-height:1}
.df-ai-main-label{display:flex;flex-direction:column;gap:4px;min-width:0}.df-ai-main-label>span{font-size:11px;font-weight:800;color:var(--bs-secondary-color,#667085)}.df-ai-main-label>input{width:100%}
.df-ai-premium-file-row{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:8px!important}.df-ai-native-file{position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important}.df-ai-upload-shell{display:flex;align-items:center;gap:12px;width:100%;min-height:66px;padding:10px 12px;border:1px dashed color-mix(in srgb,#7c3aed 42%,var(--df-border));border-radius:10px;background:color-mix(in srgb,#7c3aed 3%,var(--bs-body-bg,#fff));cursor:pointer;transition:border-color .16s ease,background .16s ease,box-shadow .16s ease}.df-ai-upload-shell:hover,.df-ai-upload-shell:focus-visible,.df-ai-upload-shell.is-dragover{outline:none;border-color:#7c3aed;background:color-mix(in srgb,#7c3aed 7%,var(--bs-body-bg,#fff));box-shadow:0 0 0 2px color-mix(in srgb,#7c3aed 10%,transparent)}.df-ai-upload-copy{display:flex;flex:1;min-width:0;flex-direction:column;gap:2px}.df-ai-upload-copy strong{font-size:13px}.df-ai-upload-copy [data-ai-upload-name]{font-size:12px;color:var(--bs-secondary-color,#667085);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.df-ai-upload-shell.has-file{border-style:solid}.df-ai-ui-delete{margin-left:auto!important;flex:0 0 34px!important;width:34px!important;height:34px!important;border:0!important;background:transparent!important;box-shadow:none!important;color:var(--bs-secondary-color,#667085)!important}.df-ai-ui-delete:hover,.df-ai-ui-delete:focus-visible{background:transparent!important;color:#dc3545!important;outline:none}.df-ai-ui-delete svg{width:18px!important;height:18px!important}.df-ai-page-actions{margin-top:2px}.df-ai-page-actions .df-primary{min-height:40px}
.df-layout-row-group.is-selected>.df-layout-row-head{box-shadow:inset 3px 0 0 #7c3aed;background:color-mix(in srgb,#7c3aed 6%,var(--bs-body-bg,#fff))}.df-layout-structure-description{font-size:11px;color:var(--bs-secondary-color,#667085);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:260px}.df-structure-settings textarea{min-height:90px}.df-structure-settings .df-selected-top{min-height:54px}
@media(max-width:720px){.df-field-entry-actions{grid-template-columns:1fr!important}.df-layout-structure-description{display:none}}

/* Forms 1.3.67: smart drag visual language. */
.df-layout-drop-guide{display:none!important}
.df-layout-card{position:relative;cursor:grab;user-select:none;transition:border-color .16s ease,box-shadow .16s ease,background .16s ease}.df-layout-card:active{cursor:grabbing}.df-layout-card .df-layout-meta,.df-layout-card button,.df-layout-card select{cursor:auto}.df-layout-handle{display:inline-flex;align-items:center;justify-content:center;min-width:24px;min-height:30px;font-size:18px;line-height:1;color:var(--bs-secondary-color,#667085);cursor:grab}.df-layout-card:hover .df-layout-handle{color:var(--df)}
.df-smart-source-hidden{display:none!important}.df-smart-source-row-empty{display:block!important}.df-smart-source-line-empty{display:grid!important;grid-template-columns:1fr!important;min-height:52px!important;border:2px dashed color-mix(in srgb,var(--df) 48%,var(--df-border));border-radius:8px;background:color-mix(in srgb,var(--df) 5%,var(--bs-body-bg,#fff));align-items:center;position:relative}.df-smart-source-line-empty::after{content:'POSIZIONE ORIGINALE';display:flex;align-items:center;justify-content:center;min-height:46px;padding:8px;color:var(--df);font-size:10px;font-weight:900;letter-spacing:.04em;pointer-events:none}
.df-builder-workspace.is-smart-dragging .df-layout-card:not(.df-smart-source-hidden){transition:border-color .14s ease,box-shadow .14s ease,background .14s ease}.df-builder-workspace.is-smart-dragging .df-layout-card:not(.df-smart-source-hidden):hover{border-color:color-mix(in srgb,var(--df) 45%,var(--df-border))}
.df-smart-drag-ghost{position:fixed;z-index:2147483646;pointer-events:none;display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:9px;min-height:48px;padding:9px 11px;border:2px solid var(--df);border-radius:9px;background:var(--bs-body-bg,#fff);color:var(--bs-body-color,#1f2937);box-shadow:0 16px 42px rgba(0,0,0,.24);opacity:.96;transform:rotate(.5deg)}.df-smart-drag-ghost strong{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.df-smart-ghost-handle{font-size:18px;color:var(--df)}.df-smart-ghost-meta{font-size:11px;font-weight:800;color:var(--bs-secondary-color,#667085)}
.df-smart-placeholder{min-height:48px;border:2px dashed var(--df);border-radius:8px;background:color-mix(in srgb,var(--df) 7%,var(--bs-body-bg,#fff));display:flex;align-items:center;justify-content:center;color:var(--df);font-size:10px;font-weight:900;letter-spacing:.04em;pointer-events:none;animation:dfSmartPulse .7s ease-in-out infinite alternate}.df-smart-target-left{box-shadow:inset 3px 0 0 var(--df)}.df-smart-target-right{box-shadow:inset -3px 0 0 var(--df)}
.df-smart-newrow-preview{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:52px;margin:7px 0;padding:9px 11px;border:2px dashed var(--df);border-radius:9px;background:color-mix(in srgb,var(--df) 6%,var(--bs-body-bg,#fff));color:var(--df);pointer-events:none}.df-smart-newrow-label{font-size:10px;font-weight:950;letter-spacing:.05em}.df-smart-newrow-field{min-width:0;max-width:70%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;font-weight:800;color:var(--bs-body-color,#1f2937)}.df-smart-row-target-before>.df-layout-row-head{box-shadow:inset 0 3px 0 var(--df)}.df-smart-row-target-after>.df-layout-row-head{box-shadow:inset 0 -3px 0 var(--df)}
body.df-smart-drag-active,body.df-smart-drag-active *{cursor:grabbing!important}body.df-smart-drag-active{user-select:none}
@keyframes dfSmartPulse{from{box-shadow:0 0 0 0 color-mix(in srgb,var(--df) 8%,transparent)}to{box-shadow:0 0 0 4px color-mix(in srgb,var(--df) 10%,transparent)}}
@media(max-width:820px){.df-layout-card{touch-action:pan-y}.df-layout-handle{min-width:32px;min-height:36px}.df-smart-drag-ghost{max-width:calc(100vw - 24px)}}

/* Forms 1.3.67: draggable section/row structure. */
.df-layout-structure-handle{display:inline-grid;place-items:center;flex:0 0 24px;width:24px;height:28px;border:0;background:transparent;color:var(--bs-secondary-color,#667085);font-size:15px;line-height:1;cursor:grab;user-select:none;touch-action:none;border-radius:5px}.df-layout-structure-handle:hover,.df-layout-structure-handle:focus-visible{color:#7c3aed;background:color-mix(in srgb,#7c3aed 8%,transparent);outline:none}.df-layout-structure-handle:active{cursor:grabbing}
body.df-structure-drag-active{user-select:none;cursor:grabbing!important}body.df-structure-drag-active *{cursor:grabbing!important}.df-layout-section-group.is-structure-source,.df-layout-row-group.is-structure-source{opacity:.38}
.df-layout-section-head,.df-layout-row-head{position:relative}.df-layout-section-head.is-structure-before::before,.df-layout-row-head.is-structure-before::before,.df-layout-section-head.is-structure-after::after,.df-layout-row-head.is-structure-after::after{content:"";position:absolute;left:8px;right:8px;height:3px;border-radius:999px;background:#7c3aed;z-index:8}.df-layout-section-head.is-structure-before::before,.df-layout-row-head.is-structure-before::before{top:-2px}.df-layout-section-head.is-structure-after::after,.df-layout-row-head.is-structure-after::after{bottom:-2px}.df-layout-section-head.is-structure-inside{box-shadow:inset 0 0 0 2px #7c3aed!important;background:color-mix(in srgb,#7c3aed 8%,var(--bs-body-bg,#fff))!important}
.df-structure-drag-ghost{position:fixed;z-index:2147483646;pointer-events:none;display:flex;align-items:center;gap:9px;max-width:360px;min-width:190px;padding:9px 12px;border:1px solid color-mix(in srgb,#7c3aed 55%,var(--df-border));border-radius:9px;background:var(--bs-body-bg,#fff);color:var(--bs-body-color,#1f2937);box-shadow:0 14px 35px rgba(15,23,42,.22);font-size:12px}.df-structure-drag-ghost strong{min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.df-structure-drag-ghost>span:last-child{font-size:10px;font-weight:800;color:#7c3aed;text-transform:uppercase;letter-spacing:.04em}

/* Forms 1.3.67: modern, borderless Builder icon actions. */
.df-icon-only{width:34px;height:34px;min-width:34px;display:inline-grid;place-items:center;padding:0!important;border:0!important;background:transparent!important;box-shadow:none!important;border-radius:8px;color:var(--bs-secondary-color,#59636f);cursor:pointer;transition:background .15s ease,color .15s ease,transform .15s ease}
.df-icon-only:hover,.df-icon-only:focus-visible{background:color-mix(in srgb,#7c3aed 9%,transparent)!important;color:#6d28d9;outline:none}
.df-icon-only:active{transform:scale(.94)}
.df-modern-ui-icon{width:18px;height:18px;display:block;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;pointer-events:none}
.df-layout-structure-handle .df-modern-ui-icon,.df-layout-handle .df-modern-ui-icon{width:17px;height:17px;stroke-width:1.7}
.df-canvas-remove:hover,.df-canvas-remove:focus-visible,[data-section-remove]:hover,[data-section-remove]:focus-visible,[data-structure-remove]:hover,[data-structure-remove]:focus-visible,.df-ai-ui-delete:hover,.df-ai-ui-delete:focus-visible,.df-lib-delete:hover,.df-lib-delete:focus-visible,.df-saved-quick-delete:hover,.df-saved-quick-delete:focus-visible{color:#dc3545!important;background:color-mix(in srgb,#dc3545 9%,transparent)!important}
.df-layout-actions,.df-layout-section-actions,.df-mini-actions{align-items:center;gap:2px}

/* Forms 1.3.67: AI preview filter states. */
.df-ai-filter-btn{white-space:nowrap}.df-ai-filter-btn.is-active{border-color:#7c3aed!important;background:color-mix(in srgb,#7c3aed 10%,var(--bs-body-bg,#fff))!important;color:#6d28d9}.df-ai-filter-btn:disabled{opacity:.42;cursor:not-allowed}.df-ai-filter-empty{padding:18px;border:1px dashed var(--df-border);border-radius:9px;text-align:center}

/* Forms 1.3.67: clearer row/section actions and drag targets. */
.df-layout-row-actions{display:inline-flex;align-items:center;gap:2px;margin-left:2px}.df-layout-row-actions .df-icon-only{width:30px;height:30px;min-width:30px}.df-row-remove:hover,.df-row-remove:focus-visible,[data-row-remove]:hover,[data-row-remove]:focus-visible{color:#dc3545!important;background:color-mix(in srgb,#dc3545 9%,transparent)!important}
.df-smart-row-join-target>.df-layout-row-head{box-shadow:inset 0 0 0 2px color-mix(in srgb,#7c3aed 80%,transparent)!important;background:color-mix(in srgb,#7c3aed 7%,var(--bs-body-bg,#fff))!important}.df-smart-row-join-preview{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:38px;margin:6px 8px;padding:7px 10px;border:1.5px dashed #7c3aed;border-radius:8px;background:color-mix(in srgb,#7c3aed 6%,var(--bs-body-bg,#fff));color:#6d28d9;pointer-events:none}.df-smart-row-join-label{font-size:10px;font-weight:950;letter-spacing:.045em}.df-smart-row-join-field{min-width:0;max-width:55%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;font-weight:800;color:var(--bs-body-color,#1f2937)}
.df-layout-section-group,.df-layout-row-group{position:relative}.df-layout-section-group.is-section-drop-before::before,.df-layout-section-group.is-section-drop-after::after,.df-layout-row-group.is-row-drop-before::before,.df-layout-row-group.is-row-drop-after::after{content:attr(data-structure-drop-label);position:absolute;left:9px;right:9px;z-index:30;height:20px;display:flex;align-items:center;justify-content:center;border-top:2px solid #7c3aed;color:#6d28d9;font-size:9px;font-weight:950;letter-spacing:.055em;line-height:1;pointer-events:none;text-shadow:0 0 5px var(--bs-body-bg,#fff),0 0 5px var(--bs-body-bg,#fff)}.df-layout-section-group.is-section-drop-before::before{top:-17px}.df-layout-section-group.is-section-drop-after::after{bottom:-19px}.df-layout-row-group.is-row-drop-before::before{top:-11px;height:15px}.df-layout-row-group.is-row-drop-after::after{bottom:-13px;height:15px}
[data-bs-theme="dark"] .df-layout-section-group.is-section-drop-before::before,[data-bs-theme="dark"] .df-layout-section-group.is-section-drop-after::after,[data-bs-theme="dark"] .df-layout-row-group.is-row-drop-before::before,[data-bs-theme="dark"] .df-layout-row-group.is-row-drop-after::after{color:#c4b5fd;text-shadow:0 0 5px var(--bs-body-bg,#111827),0 0 5px var(--bs-body-bg,#111827)}
@media(max-width:820px){.df-layout-row-actions{gap:0}.df-layout-row-actions .df-icon-only{width:32px;height:32px;min-width:32px}.df-smart-row-join-preview{margin:6px 4px}}

/* Forms 1.3.67: logical rows can contain multiple visual lines. */
.df-builder-workspace .df-layout-row-body{display:flex;flex-direction:column;gap:6px;padding-top:1px;padding-bottom:1px}.df-builder-workspace .df-layout-row-body>.df-layout-row{width:100%;flex:0 0 auto}.df-builder-workspace .df-layout-row-body>.df-layout-row+.df-layout-row{margin-top:1px}.df-layout-row-summary{max-width:48%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.df-smart-row-join-preview{margin:6px 5px!important;min-height:42px!important}.df-smart-row-join-target>.df-layout-row-head{box-shadow:inset 3px 0 0 #7c3aed!important}
@media(max-width:800px){.df-builder-workspace .df-layout-row-body{gap:7px}.df-builder-workspace .df-layout-row{grid-template-columns:1fr!important}.df-layout-row-summary{max-width:42%}}




/* Forms 1.3.67: smart empty slots + consistent action colors. */
.df-layout-empty-slot{min-width:0;min-height:44px;display:flex;align-items:center;justify-content:center;border:1.5px dashed color-mix(in srgb,#7c3aed 42%,var(--df-border));border-radius:8px;background:color-mix(in srgb,#7c3aed 3%,transparent);color:var(--bs-secondary-color,#667085);font-size:10px;font-weight:850;letter-spacing:.035em;pointer-events:none}
.df-smart-slot-preview{min-width:0;min-height:44px;display:flex;align-items:center;justify-content:center;border:1.5px dashed #7c3aed;border-radius:8px;background:color-mix(in srgb,#7c3aed 7%,var(--bs-body-bg,#fff));font-size:10px;font-weight:900;color:#6d28d9;pointer-events:none}
.df-smart-slot-preview.is-field{border-style:solid}
.df-layout-section-actions [data-section-edit],.df-layout-section-actions [data-section-copy],.df-layout-row-actions [data-row-edit],.df-layout-row-actions [data-row-copy],.df-mini-actions [data-row-copy]{color:var(--bs-secondary-color,#59636f)!important}
.df-layout-section-actions [data-section-remove],.df-layout-row-actions [data-row-remove],.df-mini-actions [data-row-remove],.df-mini-actions [data-structure-remove]{color:#dc3545!important}
[data-bs-theme="dark"] .df-layout-empty-slot{background:color-mix(in srgb,#7c3aed 7%,transparent);color:#aeb7c4}

/* Forms 1.3.67: real accordions + uniform destructive actions. */
.df-layout-general-grip-spacer{width:30px;height:30px;min-width:30px;flex:0 0 30px;display:block}
.df-layout-section-group.is-general>.df-layout-section-head{cursor:pointer}
.df-layout-section-group:not(.is-open)>.df-layout-section-body{display:none!important}
.df-layout-section-group.is-open>.df-layout-section-body{display:block!important}
.df-builder-workspace .df-layout-row-group:not(.is-open)>.df-layout-row-body{display:none!important}
.df-builder-workspace .df-layout-row-group.is-open>.df-layout-row-body{display:flex!important;flex-direction:column}
[data-section-remove],[data-row-remove],[data-structure-remove]{color:#dc3545!important;background:transparent!important}
[data-section-remove]:hover,[data-section-remove]:focus-visible,[data-row-remove]:hover,[data-row-remove]:focus-visible,[data-structure-remove]:hover,[data-structure-remove]:focus-visible{color:#b42318!important;background:color-mix(in srgb,#dc3545 10%,transparent)!important;outline:none}
@media(max-width:800px){.df-layout-general-grip-spacer{width:34px;height:34px;min-width:34px;flex-basis:34px}}

/* Forms 1.3.67: permanent General rows + aligned drag affordances. */
.df-layout-section-head,.df-layout-row-head{gap:6px}
.df-layout-structure-handle,.df-layout-section-chevron,.df-layout-row-chevron{width:30px;height:30px;min-width:30px;flex:0 0 30px;display:inline-flex;align-items:center;justify-content:center;margin:0;padding:0}
.df-layout-structure-handle{border-radius:7px;cursor:grab;touch-action:none;color:var(--bs-secondary-color,#667085)}
.df-layout-structure-handle:hover,.df-layout-structure-handle:focus-visible{background:color-mix(in srgb,var(--df) 9%,transparent);color:var(--df);outline:none}
.df-layout-section-chevron,.df-layout-row-chevron{font-size:18px;line-height:1}
.df-layout-leading-spacer{width:66px;min-width:66px;flex:0 0 66px;height:30px;display:block}
.df-layout-section-group.is-section>.df-layout-section-head,.df-layout-row-head{cursor:grab}
.df-layout-section-group.is-section>.df-layout-section-head:active,.df-layout-row-head:active{cursor:grabbing}
.df-layout-section-group.is-general>.df-layout-section-head{cursor:default}
.df-layout-section-group.is-general>.df-layout-section-body{display:block!important}
.df-layout-section-group.is-general .df-layout-row-body{display:flex!important}
.df-layout-section-group.is-general .df-layout-row-group{overflow:visible}
.df-layout-section-group.is-general .df-layout-row-head{border-radius:8px}
.df-layout-section-group.is-general .df-layout-row-label{margin-left:0}
.df-layout-section-head button,.df-layout-row-head button{cursor:pointer}
@media(max-width:800px){.df-layout-structure-handle,.df-layout-section-chevron,.df-layout-row-chevron{width:34px;height:34px;min-width:34px;flex-basis:34px}.df-layout-leading-spacer{width:74px;min-width:74px;flex-basis:74px}}

/* Forms 1.3.67: General base container + internal visual-line drop zones. */
.df-layout-section-group.is-general{border-style:dashed;background:color-mix(in srgb,var(--bs-secondary-bg,#f4f6f8) 35%,var(--bs-body-bg,#fff))}
.df-layout-section-group.is-general>.df-layout-section-head{background:transparent}.df-layout-section-group.is-general>.df-layout-section-head:hover{background:color-mix(in srgb,var(--bs-secondary-bg,#eef1f4) 60%,transparent)}
.df-layout-section-group.is-general .df-layout-section-title strong{font-weight:800}.df-layout-section-group.is-general .df-layout-section-empty{color:var(--bs-secondary-color,#667085)}
.df-smart-line-preview{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:42px;margin:5px 4px;padding:8px 10px;border:2px dashed var(--df);border-radius:8px;background:color-mix(in srgb,var(--df) 6%,var(--bs-body-bg,#fff));color:var(--df);pointer-events:none}
.df-smart-line-label{font-size:10px;font-weight:950;letter-spacing:.045em}.df-smart-line-field{min-width:0;max-width:58%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;font-weight:800;color:var(--bs-body-color,#1f2937)}
.df-smart-line-target-before{box-shadow:inset 0 3px 0 var(--df)}.df-smart-line-target-after{box-shadow:inset 0 -3px 0 var(--df)}
@media(max-width:800px){.df-smart-line-preview{margin:5px 2px}.df-smart-line-field{max-width:48%}}

/* Forms 1.3.67: intent-aware field drag with grab-offset compensation. */
body.df-smart-drag-active .df-layout-card:not(.df-smart-source-hidden){position:relative;isolation:isolate}
body.df-smart-drag-active .df-layout-card.df-smart-line-target-before{box-shadow:inset 0 0 0 2px color-mix(in srgb,var(--df) 72%,transparent),inset 0 14px 0 color-mix(in srgb,var(--df) 10%,transparent)}
body.df-smart-drag-active .df-layout-card.df-smart-line-target-after{box-shadow:inset 0 0 0 2px color-mix(in srgb,var(--df) 72%,transparent),inset 0 -14px 0 color-mix(in srgb,var(--df) 10%,transparent)}
body.df-smart-drag-active .df-layout-card.df-smart-target-left{box-shadow:inset 3px 0 0 var(--df),inset 14px 0 0 color-mix(in srgb,var(--df) 8%,transparent)}
body.df-smart-drag-active .df-layout-card.df-smart-target-right{box-shadow:inset -3px 0 0 var(--df),inset -14px 0 0 color-mix(in srgb,var(--df) 8%,transparent)}
body.df-smart-drag-active .df-layout-empty-slot{transition:border-color .12s ease,background .12s ease,box-shadow .12s ease;box-shadow:0 0 0 4px color-mix(in srgb,var(--df) 3%,transparent)}
body.df-smart-drag-active .df-layout-empty-slot:hover{border-color:var(--df);background:color-mix(in srgb,var(--df) 8%,var(--bs-body-bg,#fff));box-shadow:0 0 0 6px color-mix(in srgb,var(--df) 7%,transparent)}


/* Forms 1.3.67: forgiving 50/50 Row drag target. */
body.df-structure-drag-active .df-layout-row-group.is-row-drop-before,body.df-structure-drag-active .df-layout-row-group.is-row-drop-after{isolation:isolate}
body.df-structure-drag-active .df-layout-row-group.is-row-drop-before::before,body.df-structure-drag-active .df-layout-row-group.is-row-drop-after::after{left:0!important;right:0!important;height:50%!important;display:flex!important;align-items:center!important;justify-content:center!important;border:2px dashed #7c3aed!important;background:color-mix(in srgb,#7c3aed 8%,transparent)!important;border-radius:8px!important;color:#6d28d9!important;font-size:10px!important;font-weight:950!important;letter-spacing:.055em!important;line-height:1!important;pointer-events:none!important;text-shadow:0 0 5px var(--bs-body-bg,#fff),0 0 5px var(--bs-body-bg,#fff)!important;z-index:40!important}
body.df-structure-drag-active .df-layout-row-group.is-row-drop-before::before{top:0!important;bottom:auto!important;border-bottom-left-radius:0!important;border-bottom-right-radius:0!important}
body.df-structure-drag-active .df-layout-row-group.is-row-drop-after::after{bottom:0!important;top:auto!important;border-top-left-radius:0!important;border-top-right-radius:0!important}
[data-bs-theme="dark"] .df-layout-row-group.is-row-drop-before::before,[data-bs-theme="dark"] .df-layout-row-group.is-row-drop-after::after{color:#c4b5fd!important;background:color-mix(in srgb,#8b5cf6 13%,transparent)!important;text-shadow:0 0 5px var(--bs-body-bg,#111827),0 0 5px var(--bs-body-bg,#111827)!important}


/* Forms 1.3.67: fluid magnetic field drag. Keep the canvas geometrically stable while dragging. */
body.df-smart-drag-active .df-layout-card.df-smart-source-hidden{display:flex!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important}
.df-smart-drag-ghost{will-change:transform;transition:none!important;pointer-events:none!important}
.df-smart-drop-overlay{position:fixed;z-index:10770;box-sizing:border-box;pointer-events:none;display:flex;align-items:center;justify-content:center;border:2px solid var(--df);border-radius:8px;background:color-mix(in srgb,var(--df) 12%,transparent);box-shadow:0 3px 14px color-mix(in srgb,var(--df) 18%,transparent);color:var(--df);font-size:11px;font-weight:950;letter-spacing:.02em;text-transform:uppercase;animation:dfSmartOverlayIn .07s ease-out both;backdrop-filter:blur(1px)}
.df-smart-drop-overlay.is-line,.df-smart-drop-overlay.is-newrow{background:color-mix(in srgb,var(--df) 9%,var(--bs-body-bg,#fff));border-style:dashed}
.df-smart-drop-overlay.is-empty-slot{border-style:dashed;background:color-mix(in srgb,var(--df) 14%,var(--bs-body-bg,#fff))}
.df-smart-drop-overlay.is-slot-empty{border-style:dashed;background:color-mix(in srgb,var(--df) 5%,var(--bs-body-bg,#fff));opacity:.88}
.df-smart-drop-overlay.is-slot-field,.df-smart-drop-overlay.is-beside{background:color-mix(in srgb,var(--df) 11%,var(--bs-body-bg,#fff))}
@keyframes dfSmartOverlayIn{from{opacity:.35}to{opacity:1}}
@media (prefers-reduced-motion:reduce){.df-smart-drop-overlay{animation:none}}


/* Forms 1.3.67: drag color feedback + visible source placeholder. */
:root,
[data-bs-theme="light"]{
 --df-drag-accent:#6f42c1;
 --df-drag-accent-rgb:111,66,193;
 --df-drag-on-accent:#fff;
}
[data-bs-theme="dark"]{
 --df-drag-accent:#a78bfa;
 --df-drag-accent-rgb:167,139,250;
 --df-drag-on-accent:#17111f;
}
body.df-smart-drag-active .df-layout-card.df-smart-source-hidden{
 display:flex!important;
 visibility:visible!important;
 opacity:.48!important;
 pointer-events:none!important;
 background:rgba(var(--df-drag-accent-rgb),.09)!important;
 border-color:rgba(var(--df-drag-accent-rgb),.50)!important;
 border-style:dashed!important;
 box-shadow:inset 0 0 0 1px rgba(var(--df-drag-accent-rgb),.12)!important;
 filter:saturate(.75)!important;
}
body.df-smart-drag-active .df-layout-card.df-smart-source-hidden>*{
 opacity:.58!important;
}
body.df-smart-drag-active .df-layout-card.df-smart-source-hidden::after{
 content:'IN SPOSTAMENTO';
 position:absolute;
 left:50%;top:50%;
 transform:translate(-50%,-50%);
 z-index:3;
 padding:4px 9px;
 border-radius:999px;
 background:var(--df-drag-accent);
 color:var(--df-drag-on-accent);
 font-size:10px;
 font-weight:900;
 letter-spacing:.035em;
 white-space:nowrap;
 box-shadow:0 2px 8px rgba(var(--df-drag-accent-rgb),.24);
}
.df-smart-drop-overlay{
 border-color:var(--df-drag-accent)!important;
 color:var(--df-drag-accent)!important;
 background:rgba(var(--df-drag-accent-rgb),.16)!important;
 box-shadow:0 4px 16px rgba(var(--df-drag-accent-rgb),.22)!important;
}
.df-smart-drop-overlay>span{
 display:inline-flex;
 align-items:center;
 justify-content:center;
 min-height:24px;
 padding:4px 10px;
 border-radius:999px;
 background:var(--df-drag-accent)!important;
 color:var(--df-drag-on-accent)!important;
 font-weight:950;
 line-height:1;
 box-shadow:0 2px 8px rgba(var(--df-drag-accent-rgb),.22);
}
.df-smart-drop-overlay.is-beside,
.df-smart-drop-overlay.is-slot-field,
.df-smart-drop-overlay.is-empty-slot{
 background:rgba(var(--df-drag-accent-rgb),.22)!important;
 border:2px solid var(--df-drag-accent)!important;
}
.df-smart-drop-overlay.is-line,
.df-smart-drop-overlay.is-newrow,
.df-smart-drop-overlay.is-append{
 background:rgba(var(--df-drag-accent-rgb),.17)!important;
 border:2px dashed var(--df-drag-accent)!important;
}
.df-smart-drop-overlay.is-joinrow{
 background:rgba(var(--df-drag-accent-rgb),.14)!important;
 border:2px solid var(--df-drag-accent)!important;
}
.df-smart-drop-overlay.is-slot-empty{
 background:rgba(var(--df-drag-accent-rgb),.08)!important;
 border:2px dashed rgba(var(--df-drag-accent-rgb),.72)!important;
 color:var(--df-drag-accent)!important;
 opacity:1!important;
}
/* The fixed overlay is the only drop indicator in 1.3.67: remove old black/red shadows. */
body.df-smart-drag-active .df-layout-row.df-smart-line-target-before,
body.df-smart-drag-active .df-layout-row.df-smart-line-target-after,
body.df-smart-drag-active .df-layout-card.df-smart-target-left,
body.df-smart-drag-active .df-layout-card.df-smart-target-right,
body.df-smart-drag-active .df-layout-row-group.df-smart-row-target-before,
body.df-smart-drag-active .df-layout-row-group.df-smart-row-target-after,
body.df-smart-drag-active .df-layout-row-group.df-smart-row-join-target{
 box-shadow:none!important;
 outline:none!important;
}
@media (prefers-reduced-motion:reduce){
 body.df-smart-drag-active .df-layout-card.df-smart-source-hidden::after{transition:none!important}
}


/* Forms 1.3.67: slightly taller field rows for clearer drag zones and badges. */
.df-layout-card{
 min-height:68px;
 padding-top:10px;
 padding-bottom:10px;
 align-items:center;
}
/* Keep the magnetic drag target comfortable without making the Builder bulky. */
.df-smart-drop-overlay>span{
 min-height:22px;
 padding:3px 10px;
}
@media (max-width:900px){
 .df-layout-card{
  min-height:64px;
  padding-top:9px;
  padding-bottom:9px;
 }
}
@media (max-width:640px){
 .df-layout-card{
  min-height:62px;
 }
}


/* Forms 1.3.67: Row + Section drag unified with the approved Field drag. Vertical only. */
body.df-structure-drag-active{user-select:none;cursor:grabbing!important}
body.df-structure-drag-active *{cursor:grabbing!important}
body.df-structure-drag-active .df-layout-section-group,
body.df-structure-drag-active .df-layout-row-group{transition:none!important}
body.df-structure-drag-active .df-layout-section-group.is-structure-source,
body.df-structure-drag-active .df-layout-row-group.is-structure-source{opacity:.62!important}
body.df-structure-drag-active .df-layout-section-group.is-structure-source>.df-layout-section-head,
body.df-structure-drag-active .df-layout-row-group.is-structure-source>.df-layout-row-head{
 position:relative;
 background:rgba(var(--df-drag-accent-rgb),.09)!important;
 box-shadow:inset 0 0 0 1.5px rgba(var(--df-drag-accent-rgb),.48)!important;
 outline:1px dashed rgba(var(--df-drag-accent-rgb),.72)!important;
 outline-offset:-3px;
}
body.df-structure-drag-active .df-layout-section-group.is-structure-source>.df-layout-section-head::after,
body.df-structure-drag-active .df-layout-row-group.is-structure-source>.df-layout-row-head::after{
 content:'IN SPOSTAMENTO';
 position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:40;
 padding:4px 10px;border-radius:999px;background:var(--df-drag-accent);color:var(--df-drag-on-accent);
 font-size:10px;font-weight:950;line-height:1;letter-spacing:.035em;white-space:nowrap;
 box-shadow:0 2px 8px rgba(var(--df-drag-accent-rgb),.24);pointer-events:none;
}
.df-structure-drag-ghost{
 will-change:transform;transition:none!important;left:0!important;top:0!important;
 border-color:rgba(var(--df-drag-accent-rgb),.50)!important;
 box-shadow:0 14px 35px rgba(15,23,42,.22),0 0 0 1px rgba(var(--df-drag-accent-rgb),.08)!important;
}
.df-structure-drag-ghost>span:last-child{color:var(--df-drag-accent)!important}
.df-structure-drop-overlay{
 position:fixed;z-index:10780;box-sizing:border-box;pointer-events:none;
 display:flex;align-items:center;justify-content:center;
 border:2px dashed var(--df-drag-accent);border-radius:10px;
 background:rgba(var(--df-drag-accent-rgb),.17);
 box-shadow:0 4px 16px rgba(var(--df-drag-accent-rgb),.20);
 color:var(--df-drag-accent);backdrop-filter:blur(1px);
 animation:dfSmartOverlayIn .07s ease-out both;
}
.df-structure-drop-overlay>span{
 display:inline-flex;align-items:center;justify-content:center;min-height:24px;
 padding:4px 11px;border-radius:999px;background:var(--df-drag-accent);color:var(--df-drag-on-accent);
 font-size:10px;font-weight:950;line-height:1;letter-spacing:.03em;text-transform:uppercase;
 box-shadow:0 2px 8px rgba(var(--df-drag-accent-rgb),.22);
}
.df-structure-drop-overlay.is-row{background:rgba(var(--df-drag-accent-rgb),.18)}
.df-structure-drop-overlay.is-section{background:rgba(var(--df-drag-accent-rgb),.15)}
.df-structure-drop-overlay.is-inside{border-style:solid;background:rgba(var(--df-drag-accent-rgb),.13)}
/* Disable legacy pseudo indicators: 1.3.67 uses the same fixed overlay language as Field drag. */
body.df-structure-drag-active .is-section-drop-before::before,
body.df-structure-drag-active .is-section-drop-after::after,
body.df-structure-drag-active .is-row-drop-before::before,
body.df-structure-drag-active .is-row-drop-after::after{content:none!important;display:none!important}
@media(max-width:800px){
 .df-structure-drop-overlay>span{min-height:22px;padding:4px 9px;font-size:9px}
 body.df-structure-drag-active .df-layout-section-group.is-structure-source>.df-layout-section-head::after,
 body.df-structure-drag-active .df-layout-row-group.is-structure-source>.df-layout-row-head::after{font-size:9px;padding:4px 8px}
}
@media(prefers-reduced-motion:reduce){.df-structure-drop-overlay{animation:none}}


/* Forms 1.3.67: Bloccato/Modifica now governs Campo, Riga and Sezione uniformly. */
.df-builder.is-locked .df-layout-handle,
.df-builder.is-locked .df-layout-structure-handle{
 cursor:not-allowed!important;
 opacity:.42;
}
.df-builder.is-locked .df-layout-handle:hover,
.df-builder.is-locked .df-layout-structure-handle:hover{
 color:inherit!important;
 background:transparent!important;
}


/* Forms 1.3.67: uniform active selection, explicit lock mode, roomier structure rows. */
.df-layout-section-group.is-selected > .df-layout-section-head,
.df-layout-row-group.is-selected > .df-layout-row-head,
.df-layout-card.is-active{
 background:color-mix(in srgb,#7c3aed 8%,var(--bs-body-bg,#fff))!important;
 box-shadow:inset 4px 0 0 #7c3aed!important;
 border-color:color-mix(in srgb,#7c3aed 24%,var(--df-border,#d8dee8))!important;
}
.df-layout-section-group.is-selected > .df-layout-section-head strong,
.df-layout-row-group.is-selected > .df-layout-row-head .df-layout-row-label,
.df-layout-card.is-active > strong{color:var(--bs-body-color,#202733)!important}

/* The active edit mode must be immediately visible. Red remains reserved for destructive actions. */





/* Final approved vertical rhythm: more room for labels, badges, actions and magnetic halves. */
.df-layout-section-head{min-height:72px!important;box-sizing:border-box;align-items:center!important}
.df-layout-row-head{min-height:68px!important;box-sizing:border-box;align-items:center!important}
.df-layout-card{min-height:72px!important;box-sizing:border-box;padding-top:11px!important;padding-bottom:11px!important;align-items:center!important}

[data-bs-theme="dark"] .df-layout-section-group.is-selected > .df-layout-section-head,
[data-bs-theme="dark"] .df-layout-row-group.is-selected > .df-layout-row-head,
[data-bs-theme="dark"] .df-layout-card.is-active,
.dark .df-layout-section-group.is-selected > .df-layout-section-head,
.dark .df-layout-row-group.is-selected > .df-layout-row-head,
.dark .df-layout-card.is-active{
 background:color-mix(in srgb,#8b5cf6 15%,var(--bs-body-bg,#111827))!important;
 border-color:color-mix(in srgb,#8b5cf6 38%,var(--df-border,#374151))!important;
 box-shadow:inset 4px 0 0 #8b5cf6!important;
}




@media(max-width:900px){
 .df-layout-section-head,.df-layout-row-head,.df-layout-card{min-height:68px!important}
 .df-layout-card{padding-top:10px!important;padding-bottom:10px!important}
}
@media(max-width:640px){
 .df-layout-section-head,.df-layout-row-head,.df-layout-card{min-height:64px!important}
 .df-layout-card{padding-top:9px!important;padding-bottom:9px!important}
}


/* Forms 1.3.67: compact Builder spacing + unmistakable active edit mode. */
.df-builder .df-layout-section-head{min-height:64px!important;padding-top:10px!important;padding-bottom:10px!important}
.df-builder .df-layout-row-head{min-height:62px!important;padding-top:9px!important;padding-bottom:9px!important}
.df-builder .df-layout-card{min-height:64px!important;padding-top:8px!important;padding-bottom:8px!important}

/* The active mode must be obvious, not just outlined. */





/* Keep inactive choice neutral in both themes. */



/* Compact responsive rhythm without reducing touch clarity too much. */
@media(max-width:900px){
  .df-builder .df-layout-section-head,.df-builder .df-layout-row-head,.df-builder .df-layout-card{min-height:60px!important}
  .df-builder .df-layout-section-head{padding-top:9px!important;padding-bottom:9px!important}
  .df-builder .df-layout-row-head,.df-builder .df-layout-card{padding-top:8px!important;padding-bottom:8px!important}
}
@media(max-width:560px){
  .df-builder .df-layout-section-head,.df-builder .df-layout-row-head,.df-builder .df-layout-card{min-height:58px!important}
  .df-builder .df-layout-section-head,.df-builder .df-layout-row-head,.df-builder .df-layout-card{padding-top:7px!important;padding-bottom:7px!important}
}


/* Forms 1.3.67: one 59px rhythm + root-state active edit mode. */
.df-builder .df-layout-section-head,
.df-builder .df-layout-row-head,
.df-builder .df-layout-card{
  min-height:59px!important;
}
.df-builder .df-layout-section-head{padding-top:8px!important;padding-bottom:8px!important}
.df-builder .df-layout-row-head{padding-top:8px!important;padding-bottom:8px!important}
.df-builder .df-layout-card{padding-top:7px!important;padding-bottom:7px!important}

/* Mode state is driven by the authoritative Builder root, not by focus styling. */







/* Keep the two buttons readable in dark mode while preserving the same state colors. */


/* 59px is intentional on desktop, tablet and smartphone for visual consistency with accordions 1-8. */
@media(max-width:900px){
  .df-builder .df-layout-section-head,.df-builder .df-layout-row-head,.df-builder .df-layout-card{min-height:59px!important}
  .df-builder .df-layout-section-head,.df-builder .df-layout-row-head{padding-top:8px!important;padding-bottom:8px!important}
  .df-builder .df-layout-card{padding-top:7px!important;padding-bottom:7px!important}
}
@media(max-width:560px){
  .df-builder .df-layout-section-head,.df-builder .df-layout-row-head,.df-builder .df-layout-card{min-height:59px!important}
  .df-builder .df-layout-section-head,.df-builder .df-layout-row-head{padding-top:7px!important;padding-bottom:7px!important}
  .df-builder .df-layout-card{padding-top:6px!important;padding-bottom:6px!important}
}

/* Forms 1.3.67: canonical Builder toolbar/edit-mode CSS after conflict cleanup. */
.df-builder .df-editor-toolbar .df-lock-toggle{
  min-height:34px;
  padding:6px 14px;
  border:1px solid var(--df-border,#d9dee5);
  background:var(--bs-body-bg,#fff);
  color:var(--bs-body-color,#1f2937);
  font-weight:800;
  cursor:pointer;
  transition:background-color .14s ease,border-color .14s ease,color .14s ease,box-shadow .14s ease;
}
.df-builder .df-editor-toolbar .df-lock-toggle .df-ui-icon{margin-right:6px;color:currentColor}
.df-builder .df-editor-toolbar .df-lock-toggle:not(.is-active):hover,
.df-builder .df-editor-toolbar .df-lock-toggle:not(.is-active):focus-visible{
  background:var(--bs-secondary-bg,#f3f4f6);
  border-color:color-mix(in srgb,var(--df-border,#d9dee5) 65%,var(--bs-body-color,#1f2937));
}
.df-builder[data-editor-mode="edit"] .df-editor-toolbar .df-lock-toggle[data-lock="0"]{
  background:#7c3aed!important;
  border-color:#7c3aed!important;
  color:#fff!important;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.16)!important;
}
.df-builder[data-editor-mode="locked"] .df-editor-toolbar .df-lock-toggle[data-lock="1"]{
  background:#475569!important;
  border-color:#475569!important;
  color:#fff!important;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.10)!important;
}
.df-builder[data-editor-mode="edit"] .df-editor-toolbar .df-lock-toggle[data-lock="1"],
.df-builder[data-editor-mode="locked"] .df-editor-toolbar .df-lock-toggle[data-lock="0"]{
  background:var(--bs-body-bg,#fff)!important;
  border-color:var(--df-border,#d9dee5)!important;
  color:var(--bs-body-color,#1f2937)!important;
  box-shadow:none!important;
}
:where(html[data-bs-theme="dark"],body[data-bs-theme="dark"],html[data-color-scheme="dark"]) .df-builder .df-editor-toolbar .df-lock-toggle{
  background:#111827;
  border-color:#475569;
  color:#f8fafc;
}
:where(html[data-bs-theme="dark"],body[data-bs-theme="dark"],html[data-color-scheme="dark"]) .df-builder[data-editor-mode="edit"] .df-editor-toolbar .df-lock-toggle[data-lock="1"],
:where(html[data-bs-theme="dark"],body[data-bs-theme="dark"],html[data-color-scheme="dark"]) .df-builder[data-editor-mode="locked"] .df-editor-toolbar .df-lock-toggle[data-lock="0"]{
  background:#111827!important;
  border-color:#475569!important;
  color:#f8fafc!important;
}
:where(html[data-bs-theme="dark"],body[data-bs-theme="dark"],html[data-color-scheme="dark"]) .df-builder[data-editor-mode="edit"] .df-editor-toolbar .df-lock-toggle[data-lock="0"]{
  background:#8b5cf6!important;
  border-color:#8b5cf6!important;
  color:#fff!important;
}

/* One definitive rhythm for Sezione, Riga and Campo. */
.df-builder .df-layout-section-head,
.df-builder .df-layout-row-head,
.df-builder .df-layout-card{min-height:59px!important}



/* Forms 1.3.67: hierarchical active path in the Builder.
   One real selection remains authoritative; parents receive context only. */
.df-builder-workspace .df-layout-section-head,
.df-builder-workspace .df-layout-row-head,
.df-builder-workspace .df-layout-card{
  transition:background-color .14s ease,border-color .14s ease,box-shadow .14s ease;
}

/* Direct active Section: strongest state for this level. */
.df-builder-workspace .df-layout-section-group.is-section.is-selected>.df-layout-section-head{
  background:color-mix(in srgb,#7c3aed 13%,var(--bs-body-bg,#fff))!important;
  box-shadow:inset 4px 0 0 #7c3aed!important;
}

/* Active Row: strong Row + light contextual Section parent. */
.df-builder-workspace .df-layout-row-group.is-selected>.df-layout-row-head{
  background:color-mix(in srgb,#7c3aed 13%,var(--bs-body-bg,#fff))!important;
  box-shadow:inset 4px 0 0 #7c3aed!important;
}
.df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-row-group.is-selected)>.df-layout-section-head{
  background:color-mix(in srgb,#7c3aed 5%,var(--bs-body-bg,#fff))!important;
  box-shadow:inset 3px 0 0 color-mix(in srgb,#7c3aed 55%,transparent)!important;
}

/* Active Field: strongest Field, medium Row context, light Section context. */
.df-builder-workspace .df-layout-card.is-active{
  background:color-mix(in srgb,#7c3aed 14%,var(--bs-body-bg,#fff))!important;
  border-color:color-mix(in srgb,#7c3aed 62%,var(--df-border,#d9dee5))!important;
  box-shadow:inset 4px 0 0 #7c3aed,0 0 0 1px color-mix(in srgb,#7c3aed 24%,transparent)!important;
}
.df-builder-workspace .df-layout-row-group:not(.is-selected):has(> .df-layout-row-body .df-layout-card.is-active)>.df-layout-row-head{
  background:color-mix(in srgb,#7c3aed 8%,var(--bs-body-bg,#fff))!important;
  box-shadow:inset 3px 0 0 color-mix(in srgb,#7c3aed 72%,transparent)!important;
}
.df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-card.is-active)>.df-layout-section-head{
  background:color-mix(in srgb,#7c3aed 5%,var(--bs-body-bg,#fff))!important;
  box-shadow:inset 3px 0 0 color-mix(in srgb,#7c3aed 55%,transparent)!important;
}

/* Dark mode: keep the hierarchy readable without turning the canvas into solid purple. */
html[data-bs-theme="dark"] .df-builder-workspace .df-layout-section-group.is-section.is-selected>.df-layout-section-head,
body[data-bs-theme="dark"] .df-builder-workspace .df-layout-section-group.is-section.is-selected>.df-layout-section-head,
html[data-color-scheme="dark"] .df-builder-workspace .df-layout-section-group.is-section.is-selected>.df-layout-section-head,
html[data-bs-theme="dark"] .df-builder-workspace .df-layout-row-group.is-selected>.df-layout-row-head,
body[data-bs-theme="dark"] .df-builder-workspace .df-layout-row-group.is-selected>.df-layout-row-head,
html[data-color-scheme="dark"] .df-builder-workspace .df-layout-row-group.is-selected>.df-layout-row-head{
  background:color-mix(in srgb,#8b5cf6 20%,var(--bs-body-bg,#111827))!important;
}
html[data-bs-theme="dark"] .df-builder-workspace .df-layout-card.is-active,
body[data-bs-theme="dark"] .df-builder-workspace .df-layout-card.is-active,
html[data-color-scheme="dark"] .df-builder-workspace .df-layout-card.is-active{
  background:color-mix(in srgb,#8b5cf6 22%,var(--bs-body-bg,#111827))!important;
  border-color:#8b5cf6!important;
}
html[data-bs-theme="dark"] .df-builder-workspace .df-layout-row-group:not(.is-selected):has(> .df-layout-row-body .df-layout-card.is-active)>.df-layout-row-head,
body[data-bs-theme="dark"] .df-builder-workspace .df-layout-row-group:not(.is-selected):has(> .df-layout-row-body .df-layout-card.is-active)>.df-layout-row-head,
html[data-color-scheme="dark"] .df-builder-workspace .df-layout-row-group:not(.is-selected):has(> .df-layout-row-body .df-layout-card.is-active)>.df-layout-row-head{
  background:color-mix(in srgb,#8b5cf6 14%,var(--bs-body-bg,#111827))!important;
}
html[data-bs-theme="dark"] .df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-card.is-active)>.df-layout-section-head,
body[data-bs-theme="dark"] .df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-card.is-active)>.df-layout-section-head,
html[data-color-scheme="dark"] .df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-card.is-active)>.df-layout-section-head,
html[data-bs-theme="dark"] .df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-row-group.is-selected)>.df-layout-section-head,
body[data-bs-theme="dark"] .df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-row-group.is-selected)>.df-layout-section-head,
html[data-color-scheme="dark"] .df-builder-workspace .df-layout-section-group.is-section:not(.is-selected):has(> .df-layout-section-body .df-layout-row-group.is-selected)>.df-layout-section-head{
  background:color-mix(in srgb,#8b5cf6 9%,var(--bs-body-bg,#111827))!important;
}

/* Forms 1.3.69: stronger hierarchical selection and 2x2 creation actions. */
.df-builder .df-field-entry-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px!important;align-items:stretch!important}
.df-builder .df-field-entry-actions>button{width:100%;min-width:0;min-height:46px}
.df-builder .df-builder-add-structure{display:flex;align-items:center;justify-content:center;gap:7px;border:1px solid color-mix(in srgb,#7c3aed 58%,var(--df-border));border-radius:7px;background:color-mix(in srgb,#7c3aed 7%,var(--bs-body-bg,#fff));color:color-mix(in srgb,#7c3aed 88%,var(--bs-body-color,#1f2937));font-weight:850;cursor:pointer;transition:background .16s ease,border-color .16s ease,transform .16s ease}
.df-builder .df-add-section-main{background:color-mix(in srgb,#7c3aed 12%,var(--bs-body-bg,#fff));border-color:color-mix(in srgb,#7c3aed 72%,var(--df-border))}
.df-builder .df-add-row-main{background:color-mix(in srgb,#7c3aed 8%,var(--bs-body-bg,#fff))}
.df-builder .df-builder-add-structure:hover,.df-builder .df-builder-add-structure:focus-visible{background:color-mix(in srgb,#7c3aed 17%,var(--bs-body-bg,#fff));border-color:#7c3aed;outline:none}
.df-builder.is-locked .df-builder-add-structure{opacity:.46;cursor:not-allowed}

/* Parent hierarchy is intentionally stronger than the child background. */
.df-builder .df-layout-section-group.is-section:has(.df-layout-row-group.is-selected)>.df-layout-section-head,
.df-builder .df-layout-section-group.is-section:has(.df-layout-card.is-active)>.df-layout-section-head,
.df-builder .df-layout-section-group.is-section.is-selected>.df-layout-section-head{background:color-mix(in srgb,#7c3aed 16%,var(--bs-body-bg,#fff))!important}
.df-builder .df-layout-section-group.is-section.is-selected>.df-layout-section-head{box-shadow:inset 4px 0 0 #7c3aed!important}
.df-builder .df-layout-section-group.is-section:not(.is-selected):has(.df-layout-row-group.is-selected)>.df-layout-section-head,
.df-builder .df-layout-section-group.is-section:not(.is-selected):has(.df-layout-card.is-active)>.df-layout-section-head{box-shadow:inset 2px 0 0 color-mix(in srgb,#7c3aed 72%,transparent)!important}

.df-builder .df-layout-row-group:has(.df-layout-card.is-active)>.df-layout-row-head,
.df-builder .df-layout-row-group.is-selected>.df-layout-row-head{background:color-mix(in srgb,#7c3aed 11%,var(--bs-body-bg,#fff))!important}
.df-builder .df-layout-row-group.is-selected>.df-layout-row-head{box-shadow:inset 4px 0 0 #7c3aed!important}
.df-builder .df-layout-row-group:not(.is-selected):has(.df-layout-card.is-active)>.df-layout-row-head{box-shadow:inset 2px 0 0 color-mix(in srgb,#7c3aed 68%,transparent)!important}

.df-layout-card.is-active{background:color-mix(in srgb,#7c3aed 8%,var(--bs-body-bg,#fff))!important;border-color:color-mix(in srgb,#7c3aed 62%,var(--df-border))!important;box-shadow:inset 4px 0 0 #7c3aed,0 0 0 1px color-mix(in srgb,#7c3aed 18%,transparent)!important}
.df-builder .df-layout-card.is-active [data-field-edit],.df-builder .df-layout-card.is-active .df-icon-only[data-act="edit"]{color:#7c3aed!important}

html[data-bs-theme="dark"] .df-builder .df-layout-section-group.is-section:has(.df-layout-row-group.is-selected)>.df-layout-section-head,
body[data-bs-theme="dark"] .df-builder .df-layout-section-group.is-section:has(.df-layout-row-group.is-selected)>.df-layout-section-head,
html[data-bs-theme="dark"] .df-builder .df-layout-section-group.is-section:has(.df-layout-card.is-active)>.df-layout-section-head,
body[data-bs-theme="dark"] .df-builder .df-layout-section-group.is-section:has(.df-layout-card.is-active)>.df-layout-section-head,
html[data-bs-theme="dark"] .df-builder .df-layout-section-group.is-section.is-selected>.df-layout-section-head,
body[data-bs-theme="dark"] .df-builder .df-layout-section-group.is-section.is-selected>.df-layout-section-head{background:color-mix(in srgb,#a78bfa 22%,var(--bs-body-bg,#111827))!important}
html[data-bs-theme="dark"] .df-builder .df-layout-row-group:has(.df-layout-card.is-active)>.df-layout-row-head,
body[data-bs-theme="dark"] .df-builder .df-layout-row-group:has(.df-layout-card.is-active)>.df-layout-row-head,
html[data-bs-theme="dark"] .df-builder .df-layout-row-group.is-selected>.df-layout-row-head,
body[data-bs-theme="dark"] .df-builder .df-layout-row-group.is-selected>.df-layout-row-head{background:color-mix(in srgb,#a78bfa 16%,var(--bs-body-bg,#111827))!important}
html[data-bs-theme="dark"] .df-builder .df-layout-card.is-active,
body[data-bs-theme="dark"] .df-layout-card.is-active{background:color-mix(in srgb,#a78bfa 12%,var(--bs-body-bg,#111827))!important;border-color:#8b5cf6!important}
html[data-bs-theme="dark"] .df-builder .df-builder-add-structure,
body[data-bs-theme="dark"] .df-builder .df-builder-add-structure{background:color-mix(in srgb,#a78bfa 12%,var(--bs-body-bg,#111827));border-color:#6d5ca8;color:#ede9fe}
@media(max-width:640px){.df-builder .df-field-entry-actions{grid-template-columns:1fr!important}}


/* Forms 1.3.69: authoritative hierarchical selection state. */
.df-builder .df-layout-section-group.is-section.is-selected > .df-layout-section-head,
.df-builder .df-layout-section-group.is-section:has(.df-layout-row-group.is-selected) > .df-layout-section-head,
.df-builder .df-layout-section-group.is-section:has(.df-layout-card.is-active) > .df-layout-section-head{
 background:color-mix(in srgb,#7c3aed 16%,var(--bs-body-bg,#fff))!important;
 box-shadow:inset 4px 0 0 #7c3aed!important;
}
.df-builder .df-layout-row-group.is-selected > .df-layout-row-head,
.df-builder .df-layout-row-group:has(.df-layout-card.is-active) > .df-layout-row-head{
 background:color-mix(in srgb,#7c3aed 11%,var(--bs-body-bg,#fff))!important;
 box-shadow:inset 3px 0 0 color-mix(in srgb,#7c3aed 88%,transparent)!important;
}
.df-layout-card.is-active{
 background:color-mix(in srgb,#7c3aed 9%,var(--bs-body-bg,#fff))!important;
 border-color:color-mix(in srgb,#7c3aed 48%,var(--bs-border-color,#d9dee5))!important;
 box-shadow:inset 4px 0 0 #7c3aed,0 0 0 1px color-mix(in srgb,#7c3aed 14%,transparent),0 1px 2px rgba(15,23,42,.05)!important;
}
.df-layout-card.is-active [data-canvas-edit]{
 color:#7c3aed!important;
 background:color-mix(in srgb,#7c3aed 11%,transparent)!important;
}
</style>

<div class="df-builder">
  <div class="df-bhead">
    <div><h2><?php echo $id ? Text::_('COM_DECAROFORMS_BUILDER_EDIT_TITLE') : Text::_('COM_DECAROFORMS_BUILDER_CREATE_TITLE'); ?></h2><p><?php echo Text::_('COM_DECAROFORMS_BUILDER_DESC'); ?></p></div>
    <div class="df-bactions"><a class="df-btn df-back-btn" href="<?php echo $this->formsUrl; ?>"><?php echo Text::_('COM_DECAROFORMS_BACK_FORMS'); ?></a><?php if ($id): ?><a class="df-btn df-danger" href="<?php echo $this->deleteUrl; ?>" data-confirm-delete-link data-delete-label="modulo"><?php echo Text::_('COM_DECAROFORMS_DELETE'); ?></a><?php endif; ?></div>
  </div>


  <div class="df-editor-toolbar" role="toolbar" aria-label="Modifica modulo">
    <div class="df-history-actions"><button type="button" id="df-undo" title="Annulla ultima modifica" disabled>↶ Annulla</button><button type="button" id="df-redo" title="Ripristina modifica" disabled>↷ Ripristina</button></div>
    <div class="df-edit-mode" aria-label="Modalità modifica"><button type="button" class="df-lock-toggle" data-lock="1"><svg class="df-ui-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="5" y="10" width="14" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg><span>Bloccato</span></button><button type="button" class="df-lock-toggle" data-lock="0"><svg class="df-ui-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 20l4.2-1 10.5-10.5a2.1 2.1 0 0 0-3-3L5.2 16 4 20z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M14.5 6.7l2.8 2.8" fill="none" stroke="currentColor" stroke-width="1.8"/></svg><span>Modifica</span></button><button class="df-save-top" type="submit" form="df-builder-form"><?php echo Text::_('COM_DECAROFORMS_SAVE_FORM'); ?></button></div>
  </div>
  <div class="df-save-notice" id="df-save-notice" hidden role="status" aria-live="polite"></div>
  <div class="df-draft-banner" id="df-draft-banner" hidden>
    <div><strong>Bozza non salvata disponibile</strong><span id="df-draft-time"></span></div>
    <div class="df-draft-actions"><button type="button" class="df-btn df-small df-primary" id="df-draft-restore">Ripristina bozza</button><button type="button" class="df-btn df-small" id="df-draft-discard">Ignora</button></div>
  </div>

  <?php
  $dfSession = \Joomla\CMS\Factory::getApplication()->getSession();
  $dfBuilderCsrf = (string) $dfSession->get('com_decaroforms.builder.csrf', '');
  if ($dfBuilderCsrf === '') {
      $dfBuilderCsrf = bin2hex(random_bytes(32));
      $dfSession->set('com_decaroforms.builder.csrf', $dfBuilderCsrf);
  }
  ?>
  <script>
  (()=>{
    const tokenUrl='index.php?option=com_decaroforms&task=builder.token&format=json';
    const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    function notice(message,type='info',reload=false){
      if(typeof window.dfSetSaveNotice==='function'){window.dfSetSaveNotice(message,type,reload);return;}
      let box=document.getElementById('df-save-notice');
      if(!box){box=document.createElement('div');box.id='df-save-notice';document.querySelector('.df-builder')?.prepend(box);}
      if(!box)return;
      box.className='df-save-notice is-'+type;box.hidden=false;
      box.innerHTML=`<span>${esc(message)}</span>${reload?'<button type="button" class="df-btn df-small" data-save-reload>Ricarica pagina</button>':''}`;
      box.querySelector('[data-save-reload]')?.addEventListener('click',()=>location.reload());
    }
    function applyToken(form,token){
      if(!token)return false;
      const wrap=document.getElementById('df-csrf-token-wrap');
      if(!wrap)return false;
      wrap.replaceChildren();
      const input=document.createElement('input');input.type='hidden';input.name=token;input.value='1';wrap.appendChild(input);
      return true;
    }
    function applyBuilderToken(form,token){
      if(!token)return false;
      let input=form.querySelector('input[name="df_builder_token"]');
      if(!input){input=document.createElement('input');input.type='hidden';input.name='df_builder_token';form.appendChild(input);}
      input.value=token;return true;
    }
    async function currentToken(form){
      const response=await fetch(tokenUrl+'&_df='+Date.now(),{method:'GET',credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}});
      let result=null;try{result=await response.json();}catch{}
      if(!response.ok||!result||result.success!==true||!result.data?.token||!result.data?.builder_token)throw new Error(result?.message||'Impossibile aggiornare il token di sicurezza.');
      applyToken(form,result.data.token);applyBuilderToken(form,result.data.builder_token);return result.data;
    }
    async function send(form){
      const response=await fetch(form.action,{method:'POST',body:new FormData(form),credentials:'same-origin',cache:'no-store',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}});
      let result=null;try{result=await response.json();}catch{}
      return {response,result};
    }
    window.DeCaroFormsBuilderSubmit=async function(event,form){
      event?.preventDefault();event?.stopPropagation();
      if(!form||form.dataset.dfSaving==='1')return false;
      form.dataset.dfSaving='1';
      try{
        if(typeof window.dfFormsFlushEmailEditors==='function')window.dfFormsFlushEmailEditors();
        if(typeof window.dfBuilderSync==='function')window.dfBuilderSync();
        const fieldsInput=form.querySelector('#df-fields-json'),fieldsCountInput=form.querySelector('#df-fields-count');
        const liveCount=typeof window.dfBuilderFieldCount==='function'?Number(window.dfBuilderFieldCount()):Number(fieldsCountInput?.value||0);
        let payloadFields=null;try{payloadFields=JSON.parse(fieldsInput?.value||'');}catch{}
        if(!Array.isArray(payloadFields)||payloadFields.length!==liveCount){
          notice('I campi del modulo non sono sincronizzati. Il salvataggio è stato bloccato per evitare la perdita dei campi.','error',false);
          if(typeof window.dfBuilderSaveDraft==='function')window.dfBuilderSaveDraft();
          return false;
        }
        if(fieldsCountInput)fieldsCountInput.value=String(liveCount);
        if(typeof window.dfBuilderSaveDraft==='function')window.dfBuilderSaveDraft();
        const buttons=[...document.querySelectorAll('.df-save-top'),...form.querySelectorAll('button[type="submit"]')];buttons.forEach(b=>b.disabled=true);
        notice('Verifica della sessione e salvataggio del modulo…','info');
        try{await currentToken(form);}catch(err){notice((err?.message||'Sessione non disponibile.')+' La bozza è stata conservata.','error',true);return false;}
        let {response,result}=await send(form);
        if(result?.data?.code==='invalid_token'){
          if(result.data.token)applyToken(form,result.data.token);
          if(result.data.builder_token)applyBuilderToken(form,result.data.builder_token);
          if(!result.data.token||!result.data.builder_token)await currentToken(form);
          ({response,result}=await send(form));
        }
        if(!response.ok||!result||result.success!==true){
          const message=result?.message||(response.status===403?'La sessione non è più valida. La bozza è stata conservata.':'Il modulo non è stato salvato. Riprova.');
          notice(message,'error',response.status===403||/sessione|token/i.test(message));return false;
        }
        const expectedFields=typeof window.dfBuilderFieldCount==='function'?Number(window.dfBuilderFieldCount()):Number(form.querySelector('#df-fields-count')?.value||0);
        if(Number(result.data?.fields_saved)!==expectedFields){notice('Il modulo è stato ricevuto, ma il controllo dei campi non coincide. La bozza è stata conservata.','error',false);return false;}
        if(typeof window.dfBuilderClearDraft==='function')window.dfBuilderClearDraft();
        const saveNotice=document.getElementById('df-save-notice');if(saveNotice)saveNotice.hidden=true;
        window.dfAllowDraftReload=true;
        const redirect=result.data?.redirect||'index.php?option=com_decaroforms&view=forms';
        location.assign(redirect);
      }catch(err){console.error('Forms robust save error',err);notice('Impossibile completare il salvataggio. La bozza è stata conservata.','error',false);}
      finally{
        form.dataset.dfSaving='0';
        const locked=document.querySelector('.df-builder')?.classList.contains('is-locked');
        [...document.querySelectorAll('.df-save-top'),...form.querySelectorAll('button[type="submit"]')].forEach(b=>b.disabled=!!locked);
      }
      return false;
    };
  })();
  </script>
  <form method="post" action="<?php echo $this->saveUrl; ?>" id="df-builder-form" onsubmit="window.DeCaroFormsBuilderSubmit(event,this); return false;">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <input type="hidden" name="fields_json" id="df-fields-json"><input type="hidden" name="fields_count" id="df-fields-count" value="0"><input type="hidden" name="fields_payload" value="1">
    <input type="hidden" name="statuses_json" id="df-statuses-json">
    <input type="hidden" name="list_columns_json" id="df-columns-json">
    <input type="hidden" name="builder_config_json" id="df-builder-config-json">
    <input type="hidden" name="email_config_json" id="df-email-config-json">
    <input type="hidden" name="additional_emails_json" id="df-additional-emails-json">
    <input type="hidden" name="integrations_json" id="df-integrations-json">
    <input type="hidden" name="email_template_admin" id="df-legacy-admin-template" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['template'] ?? 'standard'), ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="email_template_user" id="df-legacy-user-template" value="<?php echo htmlspecialchars((string) ($emailConfig['user']['template'] ?? 'standard'), ENT_QUOTES, 'UTF-8'); ?>">

    <section class="df-section is-open" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="true"><strong>1. <?php echo Text::_('COM_DECAROFORMS_SECTION_SETTINGS'); ?></strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body"><div class="df-grid">
        <div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_TITLE'); ?> *</label><input name="title" required value="<?php echo $val('title'); ?>" placeholder="<?php echo htmlspecialchars(Text::_('COM_DECAROFORMS_TITLE_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>"></div>
        <div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_SLUG'); ?></label><input name="slug" value="<?php echo $val('slug'); ?>" placeholder="<?php echo htmlspecialchars(Text::_('COM_DECAROFORMS_SLUG_PLACEHOLDER'), ENT_QUOTES, 'UTF-8'); ?>"><span class="df-note"><?php echo Text::_('COM_DECAROFORMS_SLUG_HELP'); ?></span></div>
        <div class="df-field df-field-full"><label><?php echo Text::_('COM_DECAROFORMS_DESCRIPTION'); ?></label><textarea name="description"><?php echo $val('description'); ?></textarea></div>
        <div class="df-field"><label class="df-switch"><input type="checkbox" name="enabled" value="1" <?php echo $checked('enabled', true) ? 'checked' : ''; ?>><span class="df-switch-ui" aria-hidden="true"></span><span><?php echo Text::_('COM_DECAROFORMS_ENABLED'); ?></span></label></div>
        <div class="df-field"><label class="df-switch"><input type="checkbox" name="show_heading" value="1" <?php echo $checked('show_heading', true) ? 'checked' : ''; ?>><span class="df-switch-ui" aria-hidden="true"></span><span><?php echo Text::_('COM_DECAROFORMS_SHOW_HEADING'); ?></span></label></div>
        <div class="df-field df-field-full df-success-message-block"><label><?php echo Text::_('COM_DECAROFORMS_SUCCESS_MESSAGE'); ?></label><textarea class="df-success-editor" name="success_message" rows="2"><?php echo $val('success_message', Text::_('COM_DECAROFORMS_SUCCESS_DEFAULT')); ?></textarea><div class="df-success-options"><label><span>Formato messaggio</span><select id="df-success-format"><option value="text">Testo semplice</option><option value="html">HTML</option></select></label><label class="df-switch df-success-modal-switch"><input type="checkbox" id="df-success-modal"><span class="df-switch-ui" aria-hidden="true"></span><span>Mostra in finestra modal</span></label></div><span class="df-note">La posizione completa del messaggio può essere regolata anche in “Validazione e conferma”.</span></div>
        <div class="df-closed-box"><div class="df-grid"><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_WHEN_DISABLED'); ?></label><select name="closed_reason"><option value="closed" <?php echo $val('closed_reason', 'closed') === 'closed' ? 'selected' : ''; ?>><?php echo Text::_('COM_DECAROFORMS_CLOSED_REGISTRATIONS'); ?></option><option value="limit" <?php echo $val('closed_reason') === 'limit' ? 'selected' : ''; ?>><?php echo Text::_('COM_DECAROFORMS_LIMIT_REACHED'); ?></option><option value="deadline" <?php echo $val('closed_reason') === 'deadline' ? 'selected' : ''; ?>><?php echo Text::_('COM_DECAROFORMS_DEADLINE_EXPIRED'); ?></option><option value="temporary" <?php echo $val('closed_reason') === 'temporary' ? 'selected' : ''; ?>><?php echo Text::_('COM_DECAROFORMS_TEMPORARILY_CLOSED'); ?></option><option value="custom" <?php echo $val('closed_reason') === 'custom' ? 'selected' : ''; ?>><?php echo Text::_('COM_DECAROFORMS_CUSTOM_MESSAGE'); ?></option></select></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_CLOSED_MESSAGE'); ?></label><input name="closed_message" value="<?php echo $val('closed_message'); ?>" placeholder="<?php echo htmlspecialchars(Text::_('COM_DECAROFORMS_OPTIONAL_CUSTOM_TEXT'), ENT_QUOTES, 'UTF-8'); ?>"></div></div></div>
      </div></div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>2. <?php echo Text::_('COM_DECAROFORMS_SECTION_TEMPLATES'); ?></strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body"><div class="df-template-row"><button type="button" data-form-template="contact"><?php echo Text::_('COM_DECAROFORMS_TEMPLATE_CONTACT'); ?></button><button type="button" data-form-template="registration"><?php echo Text::_('COM_DECAROFORMS_TEMPLATE_REGISTRATION'); ?></button><button type="button" data-form-template="event"><?php echo Text::_('COM_DECAROFORMS_TEMPLATE_EVENT'); ?></button><button type="button" data-form-template="membership"><?php echo Text::_('COM_DECAROFORMS_TEMPLATE_MEMBERSHIP'); ?></button><button type="button" data-form-template="reservation"><?php echo Text::_('COM_DECAROFORMS_TEMPLATE_RESERVATION'); ?></button><button type="button" data-form-template="blank"><?php echo Text::_('COM_DECAROFORMS_TEMPLATE_BLANK'); ?></button></div><div class="df-saved-quick-heading" id="df-saved-quick-heading" hidden>Modelli salvati</div><div class="df-template-row df-saved-quick-row" id="df-saved-quick-templates"></div><p class="df-note"><?php echo Text::_('COM_DECAROFORMS_TEMPLATE_NOTE'); ?></p></div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>3. Campi del modulo</strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body">
        <div class="df-builder-workspace">
          <div class="df-form-canvas-panel">
            <div class="df-layout-visual-head"><div><strong>Struttura del modulo</strong><div class="df-note">Trascina sopra, sotto, a sinistra o a destra: il Builder mostra subito dove finirà il campo.</div></div><div class="df-layout-head-actions"><button class="df-btn df-small df-btn-primary df-save-structure" type="button" id="df-save-structure" title="Salva questa struttura nei Modelli rapidi"><svg class="df-ui-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 3h11l3 3v15H5V3zM7 3v6h9V4M8 21v-7h8v7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg><span>Salva struttura</span></button><label class="df-switch"><input type="checkbox" id="df-layout-mobile-stack"><span class="df-switch-ui" aria-hidden="true"></span><span><?php echo Text::_('COM_DECAROFORMS_LAYOUT_MOBILE_STACK'); ?></span></label></div></div>
            <div class="df-layout-canvas" id="df-layout-canvas"></div>
            <div class="df-layout-newrow" id="df-layout-newrow">Rilascia qui per creare una nuova riga</div>
            <div class="df-field-entry-actions" aria-label="Aggiungi elementi al modulo">
              <button class="df-builder-add-structure df-add-section-main" type="button" id="df-add-section"><span aria-hidden="true">＋</span> Aggiungi sezione</button>
              <button class="df-builder-add-structure df-add-row-main" type="button" id="df-add-row"><span aria-hidden="true">＋</span> Aggiungi riga</button>
              <button class="df-add-field-main" type="button" id="df-open-library"><span aria-hidden="true">＋</span> Aggiungi campo</button>
              <button class="df-ai-import-main" type="button" id="df-open-ai-import"><span aria-hidden="true">＋</span> Importa con AI</button>
            </div>
            <div hidden aria-hidden="true"><select id="df-layout-columns"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select><span id="df-layout-total"></span><div id="df-layout-widths"></div><button type="button" id="df-layout-apply">Applica</button></div>
          </div>
          <aside class="df-properties-panel" aria-live="polite">
            <div class="df-properties-title"><div><strong>Impostazioni campo</strong><span>Seleziona un campo per modificarlo</span></div></div>
            <div class="df-selected" id="df-selected"></div>
          </aside>
        </div>
      </div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>4. <?php echo Text::_('COM_DECAROFORMS_SECTION_LIBRARY'); ?></strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body"><div class="df-library-tabs" id="df-library-tabs"></div><div class="df-library-tools-v2"><input type="search" id="df-library-search" placeholder="<?php echo htmlspecialchars(Text::_('COM_DECAROFORMS_SEARCH_FIELD'), ENT_QUOTES, 'UTF-8'); ?>"><select id="df-library-filter" hidden></select></div><div class="df-library" id="df-library"></div></div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>5. Stati e visualizzazione</strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body">
        <div class="df-subbox"><h4>Stati degli invii</h4><p class="df-note"><?php echo Text::_('COM_DECAROFORMS_FORM_STATUSES_NOTE'); ?></p><div class="df-status-editor" id="df-status-editor"></div><button type="button" class="df-btn df-small" id="df-add-status" style="margin-top:9px">+ <?php echo Text::_('COM_DECAROFORMS_ADD_STATUS'); ?></button></div>
        <div class="df-subbox"><div class="df-spread"><div><h4>Colonne dell’elenco</h4><p class="df-note"><?php echo Text::_('COM_DECAROFORMS_TABLE_COLUMNS_NOTE'); ?></p></div><div class="df-column-tools"><button class="df-btn df-small" type="button" id="df-columns-all"><?php echo Text::_('COM_DECAROFORMS_SELECT_ALL'); ?></button><button class="df-btn df-small" type="button" id="df-columns-reset"><?php echo Text::_('COM_DECAROFORMS_RESET_DEFAULT'); ?></button></div></div><div class="df-column-list" id="df-column-list"></div></div>
      </div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>6. <?php echo Text::_('COM_DECAROFORMS_SECTION_EMAIL'); ?></strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body">
        <div class="df-tokenbar"><strong><?php echo Text::_('COM_DECAROFORMS_INSERT_VARIABLE'); ?></strong><select id="df-token-picker"></select><button class="df-btn df-small" type="button" id="df-token-insert"><?php echo Text::_('COM_DECAROFORMS_INSERT'); ?></button><span class="df-note"><?php echo Text::_('COM_DECAROFORMS_VARIABLE_NOTE'); ?></span></div>
        <?php if ($emailEditorMarkup['admin'] !== '' || $emailEditorMarkup['user'] !== ''): ?>
        <div data-email-editor-pool hidden>
          <?php foreach (['admin', 'user'] as $emailEditorAudience): ?>
            <?php if ($emailEditorMarkup[$emailEditorAudience] !== ''): ?>
              <div data-email-editor-host="<?php echo $emailEditorAudience; ?>" hidden><?php echo $emailEditorMarkup[$emailEditorAudience]; ?></div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <details class="df-email-block" open><summary><?php echo Text::_('COM_DECAROFORMS_EMAIL_ADMIN_SECTION'); ?></summary><div class="df-email-block-body">
          <div class="df-grid"><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_ADMIN_EMAIL'); ?></label><input name="admin_email" data-email="admin.to" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['to'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" placeholder="<?php echo htmlspecialchars($this->defaultAdminEmail ?: $this->globalMailFrom ?: 'admin@example.com', ENT_QUOTES, 'UTF-8'); ?>"><span class="df-note"><?php echo Text::_('COM_DECAROFORMS_ADMIN_EMAIL_INHERIT'); ?></span></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_EMAIL_ADMIN_SUBJECT'); ?></label><input name="email_subject_admin" data-email="admin.subject" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['subject'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" placeholder="Nuovo invio – {form_title}"></div></div>
          <div class="df-grid"><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_FROM_EMAIL'); ?></label><input data-email="admin.from_email" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['from_email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" placeholder="<?php echo htmlspecialchars($this->globalMailFrom, ENT_QUOTES, 'UTF-8'); ?>"></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_FROM_NAME'); ?></label><input data-email="admin.from_name" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['from_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" placeholder="<?php echo htmlspecialchars($this->globalFromName, ENT_QUOTES, 'UTF-8'); ?>"></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_REPLY_TO_EMAIL'); ?></label><input data-email="admin.reply_to" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['reply_to'] ?? '{email}'), ENT_QUOTES, 'UTF-8'); ?>"></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_REPLY_TO_NAME'); ?></label><input data-email="admin.reply_name" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['reply_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div></div>
          <details style="margin:8px 0 12px"><summary><strong><?php echo Text::_('COM_DECAROFORMS_ADVANCED_OPTIONS'); ?></strong></summary><div class="df-grid" style="margin-top:9px"><div class="df-field"><label>CC</label><input data-email="admin.cc" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['cc'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div><div class="df-field"><label>BCC</label><input data-email="admin.bcc" value="<?php echo htmlspecialchars((string) ($emailConfig['admin']['bcc'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div><div class="df-field"><label class="df-check"><input type="checkbox" data-email-check="admin.auto_message" <?php echo !empty($emailConfig['admin']['auto_message']) ? 'checked' : ''; ?>> <?php echo Text::_('COM_DECAROFORMS_AUTO_EMAIL_MESSAGE'); ?></label></div><div class="df-field"><label class="df-check"><input type="checkbox" data-email-check="admin.attach_uploads" <?php echo !empty($emailConfig['admin']['attach_uploads']) ? 'checked' : ''; ?>> <?php echo Text::_('COM_DECAROFORMS_ATTACH_UPLOADS'); ?></label></div></div></details>
          <h4><?php echo Text::_('COM_DECAROFORMS_EMAIL_TEMPLATE'); ?></h4><div class="df-email-templates" data-email-picker="admin"></div><div class="df-email-special" data-email-special="admin" hidden></div>
        </div></details>

        <details class="df-email-block"><summary><?php echo Text::_('COM_DECAROFORMS_EMAIL_USER_SECTION'); ?></summary><div class="df-email-block-body">
          <label class="df-check"><input type="checkbox" name="user_confirmation" value="1" id="df-user-confirmation" <?php echo !empty($emailConfig['user']['enabled']) ? 'checked' : ''; ?>> <strong><?php echo Text::_('COM_DECAROFORMS_USER_CONFIRMATION_CLEAR'); ?></strong></label><p class="df-note"><?php echo Text::_('COM_DECAROFORMS_USER_CONFIRMATION_NOTE'); ?></p>
          <div id="df-user-email-settings"><div class="df-grid"><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_USER_EMAIL_FIELD'); ?></label><select data-email="user.to_field" id="df-user-email-field"></select></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_EMAIL_USER_SUBJECT'); ?></label><input name="email_subject_user" data-email="user.subject" value="<?php echo htmlspecialchars((string) ($emailConfig['user']['subject'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" placeholder="Abbiamo ricevuto il tuo invio – {form_title}"></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_REPLY_TO_EMAIL'); ?></label><input data-email="user.reply_to" value="<?php echo htmlspecialchars((string) ($emailConfig['user']['reply_to'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_REPLY_TO_NAME'); ?></label><input data-email="user.reply_name" value="<?php echo htmlspecialchars((string) ($emailConfig['user']['reply_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div></div>
          <div class="df-inline" style="margin:8px 0"><label class="df-check"><input type="checkbox" data-email-check="user.auto_message" <?php echo !empty($emailConfig['user']['auto_message']) ? 'checked' : ''; ?>> <?php echo Text::_('COM_DECAROFORMS_AUTO_EMAIL_MESSAGE'); ?></label><label class="df-check"><input type="checkbox" data-email-check="user.attach_uploads" <?php echo !empty($emailConfig['user']['attach_uploads']) ? 'checked' : ''; ?>> <?php echo Text::_('COM_DECAROFORMS_ATTACH_UPLOADS'); ?></label></div>
          <h4><?php echo Text::_('COM_DECAROFORMS_EMAIL_TEMPLATE'); ?></h4><div class="df-email-templates" data-email-picker="user"></div><div class="df-email-special" data-email-special="user" hidden></div></div>
        </div></details>

        <details class="df-email-block"><summary><?php echo Text::_('COM_DECAROFORMS_ADDITIONAL_EMAILS'); ?></summary><div class="df-email-block-body"><div class="df-spread"><p class="df-note" style="margin:0"><?php echo Text::_('COM_DECAROFORMS_ADDITIONAL_EMAILS_NOTE'); ?></p><button class="df-btn df-small" type="button" id="df-additional-add">+ <?php echo Text::_('COM_DECAROFORMS_NEW_EMAIL'); ?></button></div><div class="df-additional-list" id="df-additional-list" style="margin-top:10px"></div></div></details>
      </div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>7. <?php echo Text::_('COM_DECAROFORMS_SECTION_VALIDATION'); ?></strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body">
        <div class="df-subbox"><h4>Controllo dei campi</h4><div class="df-security-grid"><div class="df-field"><label class="df-check"><input type="checkbox" id="df-validation-ajax"><span>Controlla i campi prima dell’invio</span><span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">Verifica subito che i campi obbligatori e i valori inseriti siano corretti prima dell’invio.</span></span></label></div><div class="df-field"><label class="df-check"><input type="checkbox" id="df-validation-scroll"><span>Vai al primo campo con errore</span><span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">Se c’è un errore, porta automaticamente l’utente al primo campo da correggere.</span></span></label></div><div class="df-field"><label class="df-label-info">Simbolo per i campi obbligatori <span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">È il simbolo mostrato accanto ai campi obbligatori. Il valore predefinito è *.</span></span></label><input id="df-required-marker" maxlength="8"></div><div class="df-field"><label class="df-label-info">Messaggio generale in caso di errore <span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">Messaggio mostrato quando uno o più campi non sono compilati correttamente.</span></span></label><input id="df-error-message"></div></div></div>
        <div class="df-subbox"><h4>Conferma dopo l’invio</h4><div class="df-security-grid"><div class="df-field"><label class="df-check"><input type="checkbox" id="df-confirm-enabled"><span>Mostra messaggio di conferma</span></label></div><div class="df-field"><label class="df-label-info">Dove mostrare il messaggio <span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">Scegli se mostrarlo sotto Invia, al posto del modulo oppure in una finestra.</span></span></label><select id="df-confirm-position"><option value="below"><?php echo Text::_('COM_DECAROFORMS_CONFIRM_BELOW'); ?></option><option value="replace"><?php echo Text::_('COM_DECAROFORMS_CONFIRM_REPLACE'); ?></option><option value="modal"><?php echo Text::_('COM_DECAROFORMS_CONFIRM_MODAL'); ?></option></select></div><div class="df-field"><label class="df-check"><input type="checkbox" id="df-confirm-scroll"><span>Vai automaticamente al messaggio</span></label></div><div class="df-field"><label class="df-check"><input type="checkbox" id="df-confirm-continue"><span>Mostra pulsante Continua</span></label></div><div class="df-field"><label>Testo del pulsante Continua</label><input id="df-confirm-continue-label"></div><div class="df-field"><label>Pagina da aprire dopo Continua</label><input id="df-confirm-continue-url" placeholder="https://..."></div></div></div>
        <div class="df-subbox"><h4>Protezione dagli invii automatici</h4><div class="df-security-grid"><div class="df-field"><label class="df-label-info">Tempo minimo per compilare il modulo <span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">Blocca gli invii completati in modo anormalmente veloce, tipici dei bot.</span></span></label><input type="number" id="df-min-seconds" min="0" max="60"></div><div class="df-field"><label class="df-label-info">Attesa minima tra due invii <span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">Impedisce invii ripetuti a distanza di pochi secondi.</span></span></label><input type="number" id="df-rate-seconds" min="0" max="3600"></div></div><p class="df-note">Le protezioni di sicurezza principali sono sempre attive. <span class="df-info-wrap"><button class="df-info" type="button" aria-label="Informazioni">ⓘ</button><span class="df-info-bubble">Comprendono controllo della richiesta, campo anti-bot invisibile e verifica lato server.</span></span></p></div>
      </div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>8. <?php echo Text::_('COM_DECAROFORMS_SECTION_CUSTOM_CODE'); ?></strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body">
        <?php if ($this->canCustomCode): ?><div class="df-custom-code-grid"><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_CUSTOM_CSS'); ?></label><textarea class="df-codearea" id="df-custom-css" name="custom_css" placeholder=".mia-classe { ... }"><?php echo htmlspecialchars((string) ($form['custom_css'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></textarea><span class="df-note"><?php echo Text::_('COM_DECAROFORMS_CUSTOM_CSS_NOTE'); ?></span></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_CUSTOM_JS'); ?></label><textarea class="df-codearea" id="df-custom-js" name="custom_js" placeholder="// JavaScript"><?php echo htmlspecialchars((string) ($form['custom_js'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></textarea><span class="df-note"><?php echo Text::_('COM_DECAROFORMS_CUSTOM_JS_NOTE'); ?></span></div></div><div class="df-warning" style="margin-top:10px"><?php echo Text::_('COM_DECAROFORMS_CUSTOM_CODE_WARNING'); ?></div><?php else: ?><div class="df-warning"><?php echo Text::_('COM_DECAROFORMS_CUSTOM_CODE_SUPERUSER'); ?></div><?php endif; ?>
      </div></div></div>
    </section>

    <section class="df-section" data-accordion>
      <button class="df-section-toggle" type="button" aria-expanded="false"><strong>9. <?php echo Text::_('COM_DECAROFORMS_SECTION_INTEGRATIONS'); ?></strong><span class="df-section-chevron">⌄</span></button>
      <div class="df-section-body-wrap"><div class="df-section-body-inner"><div class="df-section-body">
        <div class="df-subbox"><h4><?php echo Text::_('COM_DECAROFORMS_CALCULATIONS'); ?></h4><p class="df-note"><?php echo Text::_('COM_DECAROFORMS_CALCULATIONS_NOTE'); ?></p><button class="df-btn df-small" type="button" id="df-add-calculation"><?php echo Text::_('COM_DECAROFORMS_ADD_CALCULATED_FIELD'); ?></button></div>
        <div class="df-subbox"><h4>Google Sheets</h4><div class="df-grid"><div class="df-field"><label class="df-check"><input type="checkbox" id="df-sheets-enabled"> <?php echo Text::_('COM_DECAROFORMS_SHEETS_ENABLE'); ?></label></div><div></div><div class="df-field df-field-full"><label><?php echo Text::_('COM_DECAROFORMS_SHEETS_WEBHOOK'); ?></label><input id="df-sheets-webhook" placeholder="https://script.google.com/macros/s/.../exec"><span class="df-note"><?php echo Text::_('COM_DECAROFORMS_SHEETS_WEBHOOK_NOTE'); ?></span></div><div class="df-field"><label><?php echo Text::_('COM_DECAROFORMS_SHEETS_SECRET'); ?></label><input id="df-sheets-secret" autocomplete="off"></div><div class="df-field"><label class="df-check"><input type="checkbox" id="df-sheets-files"> <?php echo Text::_('COM_DECAROFORMS_SHEETS_INCLUDE_FILES'); ?></label></div></div><p class="df-note"><?php echo Text::_('COM_DECAROFORMS_SHEETS_PRIMARY_DB'); ?></p></div>
      </div></div></div>
    </section>

    <div class="df-bactions" style="justify-content:flex-end"><a class="df-btn" href="<?php echo $this->formsUrl; ?>"><?php echo Text::_('COM_DECAROFORMS_CANCEL'); ?></a><button class="df-btn df-primary" type="submit"><?php echo Text::_('COM_DECAROFORMS_SAVE_FORM'); ?></button></div>
    <input type="hidden" name="df_builder_token" value="<?php echo htmlspecialchars($dfBuilderCsrf, ENT_QUOTES, 'UTF-8'); ?>">
    <span id="df-csrf-token-wrap"><?php echo HTMLHelper::_('form.token'); ?></span>
  </form>

  <div class="df-preview-modal" id="df-email-preview-modal" hidden><div class="df-preview-backdrop" data-preview-close></div><div class="df-preview-dialog" role="dialog" aria-modal="true"><div class="df-preview-head"><div><strong id="df-preview-title"></strong><div class="df-note" id="df-preview-subject"></div></div><button class="df-preview-x" type="button" data-preview-close>×</button></div><div class="df-preview-body"><div class="df-preview-canvas" id="df-preview-canvas"></div></div><div class="df-preview-foot"><button class="df-btn" type="button" data-preview-close><?php echo Text::_('COM_DECAROFORMS_CLOSE'); ?></button></div></div></div>

  <div class="df-ai-modal" id="df-ai-import-modal" hidden aria-hidden="true">
    <div class="df-ai-backdrop" data-ai-close></div>
    <div class="df-ai-dialog" role="dialog" aria-modal="true" aria-labelledby="df-ai-title">
      <div class="df-ai-head"><div class="df-ai-head-title"><strong id="df-ai-title">✨ Importa campi con AI</strong><span class="df-note">L’AI prepara una bozza: i campi entrano nel modulo solo dopo la tua conferma.</span></div><button class="df-ai-close" type="button" data-ai-close aria-label="Chiudi">×</button></div>
      <div class="df-ai-body">
        <p class="df-ai-intro">Ricrea solo i campi del modulo. Template, CSS, colori, immagini, pulsanti decorativi e contenuti del sito originale non vengono importati.</p>
        <div class="df-ai-modes">
          
          <div class="df-ai-mode df-ai-html-mode"><div class="df-ai-mode-head"><strong>📄 Da pagina salvata</strong><span class="df-ai-badge df-ai-badge-free">Senza API</span></div><div class="df-ai-direct-note">Carica una pagina salvata dal sito in formato HTML oppure ZIP. Forms legge i campi e usa anche le risorse locali disponibili per ricostruire meglio layout e struttura.</div><div class="df-ai-file-row"><input type="file" id="df-ai-html-file" accept="text/html,.html,.htm,.zip,application/zip,application/x-zip-compressed"><button class="df-ai-clear-file df-icon-only" type="button" id="df-ai-html-clear" title="Rimuovi pagina" aria-label="Rimuovi pagina" hidden><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 3h6l1 2h4v2h-1l-1 14H6L5 7H4V5h4l1-2zm-1.9 4 .86 12h8.08l.86-12H7.1zM10 9h2v8h-2V9zm4 0h2v8h-2V9z" fill="currentColor"/></svg></button><button class="df-btn df-small" type="button" id="df-ai-html-analyze">Analizza pagina</button><span class="df-note" id="df-ai-html-status">HTML/ZIP massimo 25 MB</span></div></div><div class="df-ai-mode is-disabled" aria-disabled="true"><div class="df-ai-mode-head"><strong>⚡ Analizza direttamente</strong><span class="df-ai-badge df-ai-badge-soon">API opzionale · prossimamente</span></div><div class="df-ai-direct-note">In futuro potrà analizzare lo screenshot senza uscire dal Builder. Richiederà un provider API configurato.</div></div>
        </div>
        <div class="df-ai-workflow">
          <div class="df-ai-box"><h4>1. Usa ChatGPT</h4><p class="df-ai-direct-note">Scarica il file istruzioni di Forms e caricalo in ChatGPT insieme allo screenshot. ChatGPT genera il JSON pronto per Forms.</p><ol class="df-ai-steps"><li>Scarica il file istruzioni di Forms.</li><li>Apri ChatGPT e allega screenshot + file istruzioni.</li><li>ChatGPT genera <strong>forms-ai-import.json</strong>.</li><li>Scarica il JSON e caricalo qui sotto.</li></ol><div class="df-ai-actions"><button class="df-btn df-primary" type="button" id="df-ai-download-instructions">⬇ Scarica file per ChatGPT</button><a class="df-btn" href="https://chatgpt.com/" target="_blank" rel="noopener noreferrer">Apri ChatGPT</a></div><details class="df-ai-quick"><summary>Descrizione rapida senza AI</summary><div class="df-ai-quick-body"><p class="df-note">Per moduli semplici puoi evitare anche ChatGPT. Esempio: “nome, cognome, email, telefono, data di nascita, corso, privacy e note”.</p><textarea class="df-ai-description" id="df-ai-description" placeholder="Descrivi i campi del modulo..."></textarea><div class="df-ai-actions" style="margin-top:8px"><button class="df-btn" type="button" id="df-ai-description-build">Prepara campi</button></div></div></details></div>
          <div class="df-ai-box"><h4>2. Carica il file generato</h4><div class="df-ai-file-row"><input type="file" id="df-ai-file" accept="application/json,.json"><button class="df-ai-clear-file df-icon-only" type="button" id="df-ai-file-clear" title="Rimuovi file JSON" aria-label="Rimuovi file JSON" hidden><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 3h6l1 2h4v2h-1l-1 14H6L5 7H4V5h4l1-2zm-1.9 4 .86 12h8.08l.86-12H7.1zM10 9h2v8h-2V9zm4 0h2v8h-2V9z" fill="currentColor"/></svg></button><span class="df-note" id="df-ai-file-status">Nessun file selezionato · JSON massimo 1 MB</span></div><div class="df-ai-actions"><button class="df-btn df-primary" type="button" id="df-ai-check">Controlla e mostra anteprima</button></div><div class="df-ai-error" id="df-ai-error" hidden></div></div>
        </div>
        <div class="df-ai-preview" id="df-ai-preview" hidden>
          <div class="df-ai-preview-head"><div><div class="df-ai-preview-summary" id="df-ai-preview-summary"></div><div class="df-note">Correggi i campi prima dell’importazione. I duplicati e i riconoscimenti poco sicuri sono evidenziati.</div></div><div class="df-ai-preview-tools"><button class="df-btn df-small" type="button" id="df-ai-select-all">Seleziona tutti</button><button class="df-btn df-small" type="button" id="df-ai-select-safe">Solo sicuri</button><button class="df-btn df-small df-ai-filter-btn" type="button" id="df-ai-filter-review">Da controllare (0)</button><button class="df-btn df-small df-ai-filter-btn" type="button" id="df-ai-filter-duplicates">Duplicati (0)</button><label><span class="df-note">Posizione</span> <select id="df-ai-position"><option value="append">In fondo al modulo</option><option value="current">Dopo la riga del campo corrente</option></select></label></div></div>
          <div class="df-ai-preview-list" id="df-ai-preview-list"></div>
        </div>
      </div>
      <div class="df-ai-foot"><button class="df-btn" type="button" data-ai-close>Annulla</button><button class="df-btn df-primary" type="button" id="df-ai-import" disabled>Importa nel modulo <span class="df-ai-import-count" id="df-ai-import-count">· 0 campi</span></button></div>
    </div>
  </div>

</div>

<?php echo FormHelper::footer(); ?>

<script>
(()=>{
const esc=s=>String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
const clone=o=>JSON.parse(JSON.stringify(o??{}));
const uiIcon=name=>{const icons={
 save:'<svg class="df-ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 3h11l3 3v15H5V3zM7 3v6h9V4M8 21v-7h8v7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
 edit:'<svg class="df-ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20l4.2-1 10.5-10.5a2.1 2.1 0 0 0-3-3L5.2 16 4 20z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M14.5 6.7l2.8 2.8" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
 copy:'<svg class="df-ui-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
 trash:'<svg class="df-ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 10v7M14 10v7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};return icons[name]||'';};
const setDeep=(obj,path,val)=>{const p=path.split('.');let x=obj;for(let i=0;i<p.length-1;i++){if(!x[p[i]]||typeof x[p[i]]!=='object')x[p[i]]={};x=x[p[i]];}x[p.at(-1)]=val;};
const getDeep=(obj,path,def='')=>{let x=obj;for(const p of path.split('.')){if(x==null||typeof x!=='object'||!(p in x))return def;x=x[p];}return x??def;};
let actionModal=null;
function closeActionModal(){if(!actionModal)return;actionModal.remove();actionModal=null;document.body.style.overflow='';}
function openActionModal({title='Conferma',message='',confirmLabel='Conferma',danger=false,inputLabel='',inputValue='',inputRequired=false,onConfirm=null}){
 closeActionModal();
 actionModal=document.createElement('div');actionModal.className='df-action-modal';
 const inputHtml=inputLabel?`<label class="df-action-input-label"><span>${esc(inputLabel)}</span><input class="df-action-input" value="${esc(inputValue)}" ${inputRequired?'required':''}></label>`:'';
 actionModal.innerHTML=`<div class="df-action-backdrop" data-action-close></div><div class="df-action-dialog" role="dialog" aria-modal="true" aria-labelledby="df-action-title"><div class="df-action-head"><strong id="df-action-title">${esc(title)}</strong><button type="button" class="df-action-x" data-action-close aria-label="Chiudi">×</button></div><div class="df-action-body"><p>${esc(message)}</p>${inputHtml}</div><div class="df-action-foot"><button type="button" class="df-btn" data-action-close>Annulla</button><button type="button" class="df-btn ${danger?'df-action-danger':'df-primary'}" data-action-confirm>${esc(confirmLabel)}</button></div></div>`;
 document.body.appendChild(actionModal);document.body.style.overflow='hidden';
 const input=actionModal.querySelector('.df-action-input'),confirm=actionModal.querySelector('[data-action-confirm]');
 const run=()=>{const value=input?input.value.trim():'';if(inputRequired&&!value){input?.focus();return;}closeActionModal();if(typeof onConfirm==='function')onConfirm(value);};
 actionModal.querySelectorAll('[data-action-close]').forEach(el=>el.addEventListener('click',closeActionModal));confirm.addEventListener('click',run);input?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run();}});
 requestAnimationFrame(()=>{(input||confirm)?.focus();input?.select();});
}
function confirmDelete(label,onConfirm){openActionModal({title:'Conferma eliminazione',message:`Vuoi davvero eliminare ${label}?`,confirmLabel:'Elimina',danger:true,onConfirm});}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&actionModal)closeActionModal();});

const tr=<?php echo json_encode([
'add'=>Text::_('COM_DECAROFORMS_ADD'),'empty'=>Text::_('COM_DECAROFORMS_NO_FIELDS_SELECTED'),'options'=>Text::_('COM_DECAROFORMS_OPTIONS_ONE_LINE'),'moveUp'=>Text::_('COM_DECAROFORMS_MOVE_UP'),'moveDown'=>Text::_('COM_DECAROFORMS_MOVE_DOWN'),'remove'=>Text::_('COM_DECAROFORMS_REMOVE'),'label'=>Text::_('COM_DECAROFORMS_LABEL'),'key'=>Text::_('COM_DECAROFORMS_FIELD_KEY'),'type'=>Text::_('COM_DECAROFORMS_TYPE'),'placeholder'=>Text::_('COM_DECAROFORMS_PLACEHOLDER'),'help'=>Text::_('COM_DECAROFORMS_HELP_TEXT'),'default'=>Text::_('COM_DECAROFORMS_DEFAULT_VALUE'),'required'=>Text::_('COM_DECAROFORMS_REQUIRED_FIELD'),'layout'=>Text::_('COM_DECAROFORMS_FIELD_LAYOUT'),'conditions'=>Text::_('COM_DECAROFORMS_CONDITIONS'),'addCondition'=>Text::_('COM_DECAROFORMS_ADD_CONDITION'),'all'=>Text::_('COM_DECAROFORMS_ALL_CONDITIONS'),'any'=>Text::_('COM_DECAROFORMS_ANY_CONDITION'),'selected'=>Text::_('COM_DECAROFORMS_TEMPLATE_SELECTED'),'preview'=>Text::_('COM_DECAROFORMS_PREVIEW'),'customize'=>Text::_('COM_DECAROFORMS_CUSTOMIZE'),'html'=>Text::_('COM_DECAROFORMS_HTML_FREE'),'chatgpt'=>Text::_('COM_DECAROFORMS_CHATGPT_GENERATOR'),'copyPrompt'=>Text::_('COM_DECAROFORMS_COPY_CHATGPT_PROMPT'),'copied'=>Text::_('COM_DECAROFORMS_COPIED'),'newEmail'=>Text::_('COM_DECAROFORMS_NEW_EMAIL'),'noAdditional'=>Text::_('COM_DECAROFORMS_NO_ADDITIONAL_EMAILS'),'emailName'=>Text::_('COM_DECAROFORMS_EMAIL_INTERNAL_NAME'),'condition'=>Text::_('COM_DECAROFORMS_CONDITION'),'template'=>Text::_('COM_DECAROFORMS_EMAIL_TEMPLATE'),
'cats'=>['personal'=>Text::_('COM_DECAROFORMS_CATEGORY_PERSONAL'),'contact'=>Text::_('COM_DECAROFORMS_CATEGORY_CONTACT'),'address'=>Text::_('COM_DECAROFORMS_CATEGORY_ADDRESS'),'choices'=>Text::_('COM_DECAROFORMS_CATEGORY_CHOICES'),'values'=>Text::_('COM_DECAROFORMS_CATEGORY_VALUES'),'datetime'=>Text::_('COM_DECAROFORMS_CATEGORY_DATETIME'),'document'=>Text::_('COM_DECAROFORMS_CATEGORY_DOCUMENT'),'payment'=>Text::_('COM_DECAROFORMS_CATEGORY_PAYMENT'),'structure'=>Text::_('COM_DECAROFORMS_CATEGORY_STRUCTURE'),'consent'=>Text::_('COM_DECAROFORMS_CATEGORY_CONSENT'),'custom'=>Text::_('COM_DECAROFORMS_CATEGORY_CUSTOM')],
'types'=>['text'=>Text::_('COM_DECAROFORMS_TYPE_TEXT'),'email'=>Text::_('COM_DECAROFORMS_TYPE_EMAIL'),'tel'=>Text::_('COM_DECAROFORMS_TYPE_TEL'),'url'=>'URL','number'=>Text::_('COM_DECAROFORMS_TYPE_NUMBER'),'date'=>Text::_('COM_DECAROFORMS_TYPE_DATE'),'time'=>Text::_('COM_DECAROFORMS_TYPE_TIME'),'datetime'=>Text::_('COM_DECAROFORMS_TYPE_DATETIME'),'textarea'=>Text::_('COM_DECAROFORMS_TYPE_TEXTAREA'),'select'=>Text::_('COM_DECAROFORMS_TYPE_SELECT'),'multiselect'=>Text::_('COM_DECAROFORMS_TYPE_MULTISELECT'),'radio'=>Text::_('COM_DECAROFORMS_TYPE_RADIO'),'checkboxes'=>Text::_('COM_DECAROFORMS_TYPE_CHECKBOXES'),'checkbox'=>Text::_('COM_DECAROFORMS_TYPE_CHECKBOX'),'toggle'=>Text::_('COM_DECAROFORMS_TYPE_TOGGLE'),'consent'=>Text::_('COM_DECAROFORMS_TYPE_CONSENT'),'file'=>Text::_('COM_DECAROFORMS_TYPE_FILE'),'upload'=>Text::_('COM_DECAROFORMS_TYPE_UPLOAD'),'nationality'=>Text::_('COM_DECAROFORMS_FIELD_NATIONALITY'),'country'=>Text::_('COM_DECAROFORMS_FIELD_COUNTRY'),'region'=>Text::_('COM_DECAROFORMS_FIELD_REGION'),'city'=>Text::_('COM_DECAROFORMS_FIELD_CITY'),'province'=>'Provincia','tax_code'=>'Codice fiscale','postcode'=>Text::_('COM_DECAROFORMS_FIELD_POSTCODE'),'member_number'=>Text::_('COM_DECAROFORMS_FIELD_MEMBER_NUMBER'),'range'=>Text::_('COM_DECAROFORMS_TYPE_RANGE'),'separator'=>Text::_('COM_DECAROFORMS_TYPE_SEPARATOR'),'pagebreak'=>Text::_('COM_DECAROFORMS_TYPE_PAGEBREAK'),'page'=>Text::_('COM_DECAROFORMS_TYPE_MULTIPAGE'),'heading'=>Text::_('COM_DECAROFORMS_TYPE_HEADING'),'info'=>Text::_('COM_DECAROFORMS_TYPE_INFO'),'fieldset'=>Text::_('COM_DECAROFORMS_TYPE_FIELDSET'),'hidden'=>Text::_('COM_DECAROFORMS_TYPE_HIDDEN'),'map'=>Text::_('COM_DECAROFORMS_TYPE_MAP'),'payment'=>Text::_('COM_DECAROFORMS_TYPE_PAYMENT'),'calculated'=>Text::_('COM_DECAROFORMS_TYPE_CALCULATED')]
], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
const structureUi={expandAll:'<?php echo addslashes(Text::_('COM_DECAROFORMS_EXPAND_ALL')); ?>',collapseAll:'<?php echo addslashes(Text::_('COM_DECAROFORMS_COLLAPSE_ALL')); ?>',general:'<?php echo addslashes(Text::_('COM_DECAROFORMS_GENERAL_SECTION')); ?>',section:'<?php echo addslashes(Text::_('COM_DECAROFORMS_SECTION')); ?>',row:'<?php echo addslashes(Text::_('COM_DECAROFORMS_ROW')); ?>',fields:'<?php echo addslashes(Text::_('COM_DECAROFORMS_FIELDS')); ?>',rows:'<?php echo addslashes(Text::_('COM_DECAROFORMS_ROWS')); ?>',sectionSettings:'<?php echo addslashes(Text::_('COM_DECAROFORMS_SECTION_SETTINGS')); ?>',rowSettings:'<?php echo addslashes(Text::_('COM_DECAROFORMS_ROW_SETTINGS')); ?>',title:'<?php echo addslashes(Text::_('COM_DECAROFORMS_TITLE')); ?>',description:'<?php echo addslashes(Text::_('COM_DECAROFORMS_DESCRIPTION')); ?>'};
const library=<?php echo json_encode(FormHelper::fieldLibrary(), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;

/* Forms 1.3.8: reusable saved field presets. */
const savedPresetStorageKey='decaroforms_saved_field_presets_v1';
function loadSavedFieldPresets(){
 try{
  const parsed=JSON.parse(localStorage.getItem(savedPresetStorageKey)||'[]');
  return Array.isArray(parsed)?parsed.filter(x=>x&&typeof x==='object'&&x.label&&x.type).slice(0,100):[];
 }catch(e){console.warn('Forms saved field presets could not be loaded',e);return [];}
}
function persistSavedFieldPresets(){
 try{localStorage.setItem(savedPresetStorageKey,JSON.stringify(savedFieldPresets));}
 catch(e){console.warn('Forms saved field presets could not be saved',e);}
}
let savedFieldPresets=loadSavedFieldPresets();
savedFieldPresets.forEach(p=>library.push({...p,category:'custom',_savedPresetId:p._savedPresetId||p.id||''}));
function saveFieldPreset(field){
 const copy=JSON.parse(JSON.stringify(field||{}));
 copy.category='custom';
 copy.options=Array.isArray(copy.options)?copy.options:[];
 const existing=savedFieldPresets.find(p=>String(p.key||'')===String(copy.key||'')&&String(p.label||'')===String(copy.label||''));
 copy._savedPresetId=existing?existing._savedPresetId:('saved_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7));
 const idx=savedFieldPresets.findIndex(p=>p._savedPresetId===copy._savedPresetId);
 if(idx>=0)savedFieldPresets[idx]=copy;else savedFieldPresets.push(copy);
 persistSavedFieldPresets();
 const libIdx=library.findIndex(p=>p._savedPresetId===copy._savedPresetId);
 if(libIdx>=0)library[libIdx]=copy;else library.push(copy);
 renderLibrary();
 return copy._savedPresetId;
}
function deleteSavedFieldPreset(id){
 savedFieldPresets=savedFieldPresets.filter(p=>p._savedPresetId!==id);
 persistSavedFieldPresets();
 for(let i=library.length-1;i>=0;i--)if(library[i]._savedPresetId===id)library.splice(i,1);
 renderLibrary();
}

let selected=<?php echo json_encode($initialFields, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
let statuses=<?php echo json_encode($initialStatuses, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
let columns=<?php echo json_encode($initialColumns, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
let builderConfig=<?php echo json_encode($builderConfig, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
let emailConfig=<?php echo json_encode($emailConfig, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
let additionalEmails=<?php echo json_encode(array_values($additionalEmails), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
let integrations=<?php echo json_encode($integrations, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;

builderConfig.layout={columns:1,widths:[100],mobile_stack:true,...(builderConfig.layout||{})};
builderConfig.validation={ajax:true,scroll_error:true,required_marker:'*',error_message:'<?php echo addslashes(Text::_('COM_DECAROFORMS_DEFAULT_ERROR_MESSAGE')); ?>',...(builderConfig.validation||{})};
builderConfig.confirmation={enabled:true,position:'below',format:'text',scroll:false,continue:false,continue_label:'<?php echo addslashes(Text::_('COM_DECAROFORMS_CONTINUE')); ?>',continue_url:'',...(builderConfig.confirmation||{})};
builderConfig.security={min_seconds:2,rate_seconds:8,...(builderConfig.security||{})};
builderConfig.geography={default_country:'IT',default_region:'Lazio',...(builderConfig.geography||{})};
integrations.google_sheets={enabled:false,webhook_url:'',secret:'',include_files:false,...(integrations.google_sheets||{})};
emailConfig.admin=emailConfig.admin||{};emailConfig.user=emailConfig.user||{};
emailConfig.admin.custom={base:'standard',primary:'#e60046',secondary:'#26364a',background:'#ffffff',text:'#20262d',button:'#e60046',border:'#dfe3e7',radius:8,...(emailConfig.admin.custom||{})};
emailConfig.user.custom={base:'standard',primary:'#e60046',secondary:'#26364a',background:'#ffffff',text:'#20262d',button:'#e60046',border:'#dfe3e7',radius:8,...(emailConfig.user.custom||{})};

const hidden={fields:document.getElementById('df-fields-json'),fieldCount:document.getElementById('df-fields-count'),statuses:document.getElementById('df-statuses-json'),columns:document.getElementById('df-columns-json'),builder:document.getElementById('df-builder-config-json'),email:document.getElementById('df-email-config-json'),additional:document.getElementById('df-additional-emails-json'),integrations:document.getElementById('df-integrations-json')};
const sel=document.getElementById('df-selected'),lib=document.getElementById('df-library'),search=document.getElementById('df-library-search'),filter=document.getElementById('df-library-filter'),statusEditor=document.getElementById('df-status-editor'),columnList=document.getElementById('df-column-list');
const types=Object.keys(tr.types);
const categoryOrder=['personal','contact','address','choices','values','datetime','document','payment','structure','consent','custom'];
const templateDefs=[['standard','Standard'],['minimal','Minimal'],['institutional','Istituzionale'],['card','Scheda'],['compact','Compatto'],['modern','Moderno'],['elegant','Elegante'],['receipt','Ricevuta'],['professional','Professionale'],['custom','Personalizzato'],['html','HTML libero'],['chatgpt','AI']];

let historyStates=[],historyIndex=-1,historyReady=false,historyApplying=false,historyTimer=null,initialHistorySignature='';
function simpleFormControls(){return [...document.querySelectorAll('#df-builder-form [name]:not([type="hidden"])')].filter(el=>!el.closest('[data-email-editor-host]'));}function simpleFormState(){return simpleFormControls().map(el=>({name:el.name,type:el.type,value:el.type==='checkbox'||el.type==='radio'?!!el.checked:el.value}));}
function captureHistoryState(){return {selected:clone(selected),statuses:clone(statuses),columns:clone(columns),builderConfig:clone(builderConfig),emailConfig:clone(emailConfig),additionalEmails:clone(additionalEmails),integrations:clone(integrations),activeFieldKey,activeStructureSelection:clone(activeStructureSelection),form:simpleFormState()};}
function historySignature(state){return JSON.stringify(state);}
function updateHistoryButtons(){const locked=document.querySelector('.df-builder')?.classList.contains('is-locked');document.getElementById('df-undo').disabled=locked||historyIndex<=0;document.getElementById('df-redo').disabled=locked||historyIndex<0||historyIndex>=historyStates.length-1;}
function pushHistory(){if(!historyReady||historyApplying)return;const state=captureHistoryState(),sig=historySignature(state);if(historyIndex>=0&&historySignature(historyStates[historyIndex])===sig)return;historyStates=historyStates.slice(0,historyIndex+1);historyStates.push(state);if(historyStates.length>50)historyStates.shift();historyIndex=historyStates.length-1;updateHistoryButtons();}
function scheduleHistory(){if(!historyReady||historyApplying)return;clearTimeout(historyTimer);historyTimer=setTimeout(pushHistory,300);}
function restoreHistory(index){if(index<0||index>=historyStates.length)return;historyApplying=true;const s=clone(historyStates[index]);selected=s.selected;statuses=s.statuses;columns=s.columns;builderConfig=s.builderConfig&&typeof s.builderConfig==='object'?s.builderConfig:{};builderConfig.layout={columns:1,widths:[100],mobile_stack:true,...(builderConfig.layout||{})};emailConfig=s.emailConfig;additionalEmails=s.additionalEmails;integrations=s.integrations;activeFieldKey=s.activeFieldKey;activeStructureSelection=s.activeStructureSelection||null;renderSelected();renderLayout();renderStatuses();renderColumns();renderTokens();renderUserEmailFields();if(emailPickersRendered)renderEmailPickers();renderAdditional();const controls=simpleFormControls();(s.form||[]).forEach((v,i)=>{const el=controls[i];if(el&&el.name===v.name){if(el.type==='checkbox'||el.type==='radio')el.checked=!!v.value;else el.value=v.value;}});historyIndex=index;sync();historyApplying=false;applyLockState();updateHistoryButtons();}
function sync(){hidden.fields.value=JSON.stringify(selected);if(hidden.fieldCount)hidden.fieldCount.value=String(selected.length);hidden.statuses.value=JSON.stringify(statuses.map(({_new,...st})=>st));hidden.columns.value=JSON.stringify(columns);hidden.builder.value=JSON.stringify(builderConfig);hidden.email.value=JSON.stringify(emailConfig);hidden.additional.value=JSON.stringify(additionalEmails);hidden.integrations.value=JSON.stringify(integrations);document.getElementById('df-legacy-admin-template').value=emailConfig.admin.template||'standard';document.getElementById('df-legacy-user-template').value=emailConfig.user.template||'standard';scheduleHistory();if(document.querySelector('.df-builder')?.classList.contains('is-locked'))queueMicrotask(applyLockState);}
function uniqueKey(base,ignoreKey=''){base=String(base||'field').replace(/[^a-zA-Z0-9_]+/g,'_').replace(/^_+|_+$/g,'').toLowerCase()||'field';let k=base,n=2;while(selected.some(x=>x.key===k&&x.key!==ignoreKey))k=base+'_'+n++;return k;}
function defaultFieldConfig(x){x.config=x.config&&typeof x.config==='object'?x.config:{};x.config.layout={row:Number(x.config.layout?.row||selected.length+1),col:Number(x.config.layout?.col||1),width:Number(x.config.layout?.width||100),...(x.config.layout||{})};x.config.conditions=Array.isArray(x.config.conditions)?x.config.conditions:[];x.config.condition_logic=x.config.condition_logic||'all';x.config.condition_action=x.config.condition_action||'show';return x;}
selected=selected.map(defaultFieldConfig);window.dfBuilderSync=sync;window.dfBuilderFieldCount=()=>selected.length;window.dfBuilderFieldsSnapshot=()=>clone(selected);
function fieldsInRow(row){return selected.map((f,i)=>[f,i]).filter(([f])=>Number(f.config?.layout?.row||1)===Number(row)).sort(([a],[b])=>(a.config.layout.col||1)-(b.config.layout.col||1));}
function smartAutoWidths(n){n=Math.max(1,Number(n)||1);if(n===1)return[100];if(n===2)return[50,50];if(n===3)return[33,33,34];if(n===4)return[25,25,25,25];const base=Math.floor(100/n),extra=100-base*n;return Array.from({length:n},(_,i)=>base+(i>=n-extra?1:0));} function smartOffsetBefore(f){return Math.max(0,Math.min(90,Number(f?.config?.layout?.offset_before||0)||0));} function smartOffsetAfter(f){return Math.max(0,Math.min(90,Number(f?.config?.layout?.offset_after||0)||0));} function smartClearOffsets(f){if(!f)return;defaultFieldConfig(f);delete f.config.layout.offset_before;delete f.config.layout.offset_after;} function smartEffectiveWidth(f){return smartOffsetBefore(f)+Math.max(1,Math.min(100,Number(f?.config?.layout?.width||100)))+smartOffsetAfter(f);}
function visualLinesForItems(items){const lines=[];let line=[],total=0;(Array.isArray(items)?items:[]).forEach(entry=>{const f=entry?.[0],span=smartEffectiveWidth(f);if(line.length&&total+span>101){lines.push(line);line=[];total=0;}line.push(entry);total+=span;if(total>=99){lines.push(line);line=[];total=0;}});if(line.length)lines.push(line);return lines;}
function visualLinesInRow(row){return visualLinesForItems(fieldsInRow(row));}
function visualLineForField(field){if(!field)return[];const row=Number(field.config?.layout?.row||1);return visualLinesInRow(row).find(line=>line.some(([f])=>f===field))||[];}
function setLogicalRowOrder(row,fields){(Array.isArray(fields)?fields:[]).forEach((f,i)=>{defaultFieldConfig(f);f.config.layout.row=Number(row);f.config.layout.col=i+1;});}
function normalizeVisualLines(row){const items=fieldsInRow(row);if(!items.length)return;const lines=visualLinesForItems(items);lines.forEach(line=>{if(!line.length)return;if(line.length===1){const f=line[0][0],w=Math.max(1,Math.min(100,Number(f.config?.layout?.width||100))),before=smartOffsetBefore(f),after=smartOffsetAfter(f),total=before+w+after;if((before>0||after>0)&&total>=99&&total<=101)return;smartClearOffsets(f);f.config.layout.width=100;return;}const effective=line.reduce((n,[f])=>n+smartEffectiveWidth(f),0),hasSlots=line.some(([f])=>smartOffsetBefore(f)>0||smartOffsetAfter(f)>0);if(hasSlots&&effective>=99&&effective<=101)return;line.forEach(([f])=>smartClearOffsets(f));const widths=line.map(([f])=>Number(f.config?.layout?.width||0)),total=widths.reduce((a,b)=>a+b,0),valid=total>=99&&total<=101&&widths.every(w=>Number.isFinite(w)&&w>0&&w<100);if(!valid){const auto=smartAutoWidths(line.length);line.forEach(([f],i)=>f.config.layout.width=auto[i]??100);}});fieldsInRow(row).forEach(([f],i)=>f.config.layout.col=i+1);}
function distributeRow(row){normalizeVisualLines(row);}
function smartFitRow(row){normalizeVisualLines(row);}
function repairInvalidRows(){[...new Set(selected.map(f=>Number(f.config?.layout?.row||1)))].forEach(row=>normalizeVisualLines(row));}
repairInvalidRows();
const openFieldKeys=new Set(selected.slice(0,1).map(x=>x.key));let activeFieldKey=selected[0]?.key||null;
/* Forms 1.3.69: direct structure creation actions. */
function builderActiveSectionId(){
 const groups=layoutGroups();
 if(activeStructureSelection?.type==='row'){
  refreshActiveRowSelection();
  const rowNo=Math.max(1,Number(activeStructureSelection?.row)||1);
  return groups.find(g=>g.rows.some(r=>Number(r.rowNo)===rowNo))?.id||'general';
 }
 if(activeFieldKey){
  return groups.find(g=>g.sectionField?.[0]?.key===activeFieldKey||g.rows.some(r=>r.items.some(([f])=>f.key===activeFieldKey)))?.id||'general';
 }
 return'general';
}
function addBuilderSection(){
 if(editorLocked)return false;
 const row=Math.max(0,...logicalRowNumbers())+1;
 const x=defaultFieldConfig({key:'section',label:'Nuova sezione',type:'heading',category:'structure',required:false,placeholder:'',default:'',help:'',options:[],config:{content:'',conditions:[],condition_logic:'all',condition_action:'show',layout:{row,col:1,width:100}}});
 x.key=uniqueKey(x.key);x.config.layout={...(x.config.layout||{}),row,col:1,width:100};
 selected.push(x);normalizeLayoutRows();sortSelectedByLayout();
 activeStructureSelection=null;activeFieldKey=x.key;openFieldKeys.clear();openFieldKeys.add(x.key);
 const sectionId='section:'+x.key;layoutSectionState.set(sectionId,true);
 renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();sync();clearTimeout(historyTimer);pushHistory();
 requestAnimationFrame(()=>{[...document.querySelectorAll('.df-layout-section-group')].find(el=>el.dataset.sectionId===sectionId)?.scrollIntoView({behavior:'smooth',block:'nearest'});});
 return true;
}
function addBuilderRow(){
 if(editorLocked)return false;
 normalizeLayoutRows();
 const sectionId=builderActiveSectionId(),blocks=structureRowBlocks(),rowId=newRowId();
 const empty={rowNo:0,rowId,fields:[],meta:{id:rowId,title:'',description:''},sectionKey:null,openState:true};
 let at=blocks.length;
 if(sectionId==='general'){
  const range=structureSectionRange(blocks,'general');at=range?.end??0;
 }else{
  const range=structureSectionRange(blocks,sectionId);at=range?.end??blocks.length;
 }
 blocks.splice(Math.max(0,Math.min(blocks.length,at)),0,empty);structureApplyBlocks(blocks);normalizeLayoutRows();
 const newRow=rowNoForId(rowId)||Math.max(1,at+1);
 activeStructureSelection={type:'row',id:rowId,row:newRow};layoutRowState.set(rowId,true);if(sectionId!=='general')layoutSectionState.set(sectionId,true);
 renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();sync();clearTimeout(historyTimer);pushHistory();
 requestAnimationFrame(()=>{[...document.querySelectorAll('.df-layout-row-group')].find(el=>el.dataset.rowId===rowId)?.scrollIntoView({behavior:'smooth',block:'nearest'});});
 return true;
}
/* End Forms 1.3.69 direct structure creation actions. */

function add(item){
 const x=defaultFieldConfig(clone(item));x.key=uniqueKey(x.key);x.options=Array.isArray(x.options)?x.options:[];
 const structural=['heading','fieldset','separator'].includes(String(x.type||''));let preferredRow=null;
 if(activeStructureSelection?.type==='row')preferredRow=Math.max(1,Number(activeStructureSelection.row)||1);
 else if(activeFieldKey){const ai=selected.findIndex(f=>f.key===activeFieldKey);if(ai>=0)preferredRow=Number(selected[ai].config?.layout?.row||1);}
 const currentItems=preferredRow!=null?fieldsInRow(preferredRow):[],rowHasStructure=currentItems.some(([f])=>['heading','fieldset','separator'].includes(String(f.type||''))),canUseLogicalRow=preferredRow!=null&&!structural&&!rowHasStructure;
 if(canUseLogicalRow){x.config.layout={row:preferredRow,col:currentItems.length+1,width:100};selected.push(x);normalizeLayoutRows();sortSelectedByLayout();normalizeVisualLines(Number(x.config.layout.row||preferredRow));}
 else if(preferredRow!=null){const insertRow=preferredRow+1;smartShiftRowMeta(insertRow);selected.forEach(f=>{defaultFieldConfig(f);if(Number(f.config.layout.row||1)>=insertRow)f.config.layout.row=Number(f.config.layout.row)+1;});x.config.layout={row:insertRow,col:1,width:100};selected.push(x);normalizeLayoutRows();sortSelectedByLayout();}
 else{const maxRow=Math.max(0,...logicalRowNumbers());x.config.layout={row:maxRow+1,col:1,width:100};selected.push(x);normalizeLayoutRows();sortSelectedByLayout();}
 activeStructureSelection=null;activeFieldKey=x.key;openFieldKeys.clear();openFieldKeys.add(x.key);renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();sync();const selectedSection=[...document.querySelectorAll('[data-accordion]')][2];if(selectedSection){selectedSection.classList.add('is-open');selectedSection.querySelector('.df-section-toggle')?.setAttribute('aria-expanded','true');}setTimeout(()=>{sel.querySelector('.df-selected-item.is-open')?.scrollIntoView({behavior:'smooth',block:'nearest'});},100);
}

/* Forms 1.3.67: AI mode selector/* Forms 1.3.67: AI mode selector + saved-page ZIP import + runtime guard. */
function ensureAiImportDom(){
 if(document.getElementById('df-ai-import-modal'))return true;
 const host=document.querySelector('.df-builder')||document.body;
 if(!host)return false;
 host.insertAdjacentHTML('beforeend',`<div class="df-ai-modal" id="df-ai-import-modal" hidden aria-hidden="true">
  <div class="df-ai-backdrop" data-ai-close></div>
  <div class="df-ai-dialog" role="dialog" aria-modal="true" aria-labelledby="df-ai-title">
   <div class="df-ai-head"><div class="df-ai-head-title"><strong id="df-ai-title">✨ Importa campi con AI</strong><span class="df-note">L’AI prepara una bozza: i campi entrano nel modulo solo dopo la tua conferma.</span></div><button class="df-ai-close" type="button" data-ai-close aria-label="Chiudi">×</button></div>
   <div class="df-ai-body">
    <p class="df-ai-intro">Ricrea solo i campi del modulo. Template, CSS, colori, immagini, pulsanti decorativi e contenuti del sito originale non vengono importati.</p>
    <div class="df-ai-modes"><div class="df-ai-mode df-ai-html-mode"><div class="df-ai-mode-head"><strong>📄 Da pagina salvata</strong><span class="df-ai-badge df-ai-badge-free">Senza API</span></div><div class="df-ai-direct-note">Carica una pagina salvata dal sito in formato HTML oppure ZIP. Forms legge i campi e usa anche le risorse locali disponibili per ricostruire meglio layout e struttura.</div><div class="df-ai-file-row"><input type="file" id="df-ai-html-file" accept="text/html,.html,.htm,.zip,application/zip,application/x-zip-compressed"><button class="df-ai-clear-file df-icon-only" type="button" id="df-ai-html-clear" title="Rimuovi pagina" aria-label="Rimuovi pagina" hidden><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 3h6l1 2h4v2h-1l-1 14H6L5 7H4V5h4l1-2zm-1.9 4 .86 12h8.08l.86-12H7.1zM10 9h2v8h-2V9zm4 0h2v8h-2V9z" fill="currentColor"/></svg></button><button class="df-btn df-small" type="button" id="df-ai-html-analyze">Analizza pagina</button><span class="df-note" id="df-ai-html-status">HTML/ZIP massimo 25 MB</span></div></div><div class="df-ai-mode is-disabled" aria-disabled="true"><div class="df-ai-mode-head"><strong>⚡ Analizza direttamente</strong><span class="df-ai-badge df-ai-badge-soon">API opzionale · prossimamente</span></div><div class="df-ai-direct-note">In futuro potrà analizzare lo screenshot senza uscire dal Builder. Richiederà un provider API configurato.</div></div></div>
    <div class="df-ai-workflow">
     <div class="df-ai-box"><h4>1. Usa ChatGPT</h4><p class="df-ai-direct-note">Scarica il file istruzioni di Forms e caricalo in ChatGPT insieme allo screenshot. ChatGPT genera il JSON pronto per Forms.</p><ol class="df-ai-steps"><li>Scarica il file istruzioni di Forms.</li><li>Apri ChatGPT e allega screenshot + file istruzioni.</li><li>ChatGPT genera <strong>forms-ai-import.json</strong>.</li><li>Scarica il JSON e caricalo qui sotto.</li></ol><div class="df-ai-actions"><button class="df-btn df-primary" type="button" id="df-ai-download-instructions">⬇ Scarica file per ChatGPT</button><a class="df-btn" href="https://chatgpt.com/" target="_blank" rel="noopener noreferrer">Apri ChatGPT</a></div><details class="df-ai-quick"><summary>Descrizione rapida senza AI</summary><div class="df-ai-quick-body"><p class="df-note">Per moduli semplici puoi evitare anche ChatGPT. Esempio: “nome, cognome, email, telefono, data di nascita, corso, privacy e note”.</p><textarea class="df-ai-description" id="df-ai-description" placeholder="Descrivi i campi del modulo..."></textarea><div class="df-ai-actions" style="margin-top:8px"><button class="df-btn" type="button" id="df-ai-description-build">Prepara campi</button></div></div></details></div>
     <div class="df-ai-box"><h4>2. Carica il file generato</h4><div class="df-ai-file-row"><input type="file" id="df-ai-file" accept="application/json,.json"><button class="df-ai-clear-file df-icon-only" type="button" id="df-ai-file-clear" title="Rimuovi file JSON" aria-label="Rimuovi file JSON" hidden><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 3h6l1 2h4v2h-1l-1 14H6L5 7H4V5h4l1-2zm-1.9 4 .86 12h8.08l.86-12H7.1zM10 9h2v8h-2V9zm4 0h2v8h-2V9z" fill="currentColor"/></svg></button><span class="df-note" id="df-ai-file-status">Nessun file selezionato · JSON massimo 1 MB</span></div><div class="df-ai-actions"><button class="df-btn df-primary" type="button" id="df-ai-check">Controlla e mostra anteprima</button></div><div class="df-ai-error" id="df-ai-error" hidden></div></div>
    </div>
    <div class="df-ai-preview" id="df-ai-preview" hidden><div class="df-ai-preview-head"><div><div class="df-ai-preview-summary" id="df-ai-preview-summary"></div><div class="df-note">Correggi i campi prima dell’importazione. I duplicati e i riconoscimenti poco sicuri sono evidenziati.</div></div><div class="df-ai-preview-tools"><button class="df-btn df-small" type="button" id="df-ai-select-all">Seleziona tutti</button><button class="df-btn df-small" type="button" id="df-ai-select-safe">Solo sicuri</button><button class="df-btn df-small df-ai-filter-btn" type="button" id="df-ai-filter-review">Da controllare (0)</button><button class="df-btn df-small df-ai-filter-btn" type="button" id="df-ai-filter-duplicates">Duplicati (0)</button><label><span class="df-note">Posizione</span> <select id="df-ai-position"><option value="append">In fondo al modulo</option><option value="current">Dopo la riga del campo corrente</option></select></label></div></div><div class="df-ai-preview-list" id="df-ai-preview-list"></div></div>
   </div>
   <div class="df-ai-foot"><button class="df-btn" type="button" data-ai-close>Annulla</button><button class="df-btn df-primary" type="button" id="df-ai-import" disabled>Importa nel modulo <span class="df-ai-import-count" id="df-ai-import-count">· 0 campi</span></button></div>
  </div>
 </div>`);
 return !!document.getElementById('df-ai-import-modal');
}
ensureAiImportDom();
const aiModal=document.getElementById('df-ai-import-modal'),aiError=document.getElementById('df-ai-error'),aiPreview=document.getElementById('df-ai-preview'),aiPreviewList=document.getElementById('df-ai-preview-list'),aiImportButton=document.getElementById('df-ai-import'),aiImportCount=document.getElementById('df-ai-import-count');

const modernUiIcon=name=>{const common='viewBox="0 0 24 24" aria-hidden="true" focusable="false" class="df-modern-ui-icon"';const icons={
 edit:`<svg ${common}><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/></svg>`,
 copy:`<svg ${common}><rect x="9" y="9" width="11" height="11" rx="2"/><rect x="4" y="4" width="11" height="11" rx="2"/></svg>`,
 trash:`<svg ${common}><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="m6 7 1 13h10l1-13"/><path d="M10 11v5M14 11v5"/></svg>`,
 grip:`<svg ${common}><circle cx="9" cy="6" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="18" r="1"/></svg>`
};return icons[name]||uiIcon(name);};

const aiAllowedTypes=new Set(['text','email','tel','url','number','date','time','datetime','textarea','select','multiselect','radio','checkboxes','checkbox','toggle','consent','upload','nationality','country','region','city','province','tax_code','postcode','member_number','heading','fieldset','separator']);
const aiWidths=[100,75,66,50,33,25];
const aiChoiceTypes=new Set(['select','multiselect','radio','checkboxes']);
const aiIgnoredTypes=new Set(['button','submit','reset','image','img','html','script','style','hidden','map','payment','calculated','page','pagebreak']);
const aiAliases={phone:'tel',telephone:'tel',telefono:'tel',mail:'email','e-mail':'email',integer:'number',numeric:'number',decimal:'number',birthdate:'date','date_of_birth':'date',multiline:'textarea','text-area':'textarea',dropdown:'select',combo:'select',combobox:'select',checkbox_group:'checkboxes',checkboxgroup:'checkboxes',checkgroup:'checkboxes',privacy:'consent',gdpr:'consent',file:'upload',attachment:'upload',allegato:'upload',section:'heading',title:'heading'};
let aiDraftFields=[];let aiLoadedJson='';let aiPreviewFilter='all';
function aiPromptText(){return `Sei un convertitore di moduli per il componente Joomla Forms di xdecaro.\n\nAnalizza SOLO i campi del modulo presenti nello screenshot allegato. Non copiare template, CSS, colori, font, immagini, logo, menu, pulsanti Invia/Continua/Indietro, testi decorativi del sito, hidden field, token, honeypot o codice. Un titolo va incluso solo se è chiaramente una sezione interna del modulo.\n\nRiconosci quando possibile: etichetta, tipo, obbligatorio, placeholder, opzioni, ordine, riga e larghezza. Non inventare opzioni, testi legali o dati che non si vedono. Se un dato è incerto lascialo vuoto e segnala confidence=low o warning. Se nel campo è già scritto un dato personale, non trasformarlo automaticamente in placeholder.\n\nRestituisci SOLO JSON valido, senza Markdown e senza spiegazioni, con questo formato:\n{\n  "format": "xdecaro-forms-ai",\n  "schema_version": 1,\n  "source": "screenshot",\n  "fields": [\n    {\n      "label": "Nome",\n      "key": "nome",\n      "type": "text",\n      "required": true,\n      "width": 50,\n      "row": 1,\n      "placeholder": "",\n      "options": [],\n      "confidence": "high",\n      "warning": ""\n    }\n  ]\n}\n\nTipi consentiti: ${[...aiAllowedTypes].join(', ')}.\nLarghezze consentite: ${aiWidths.join(', ')}. Usa solo questi valori e scegli quello più vicino al layout visibile.\nconfidence deve essere high, medium oppure low.\nPer select, radio, checkboxes e multiselect inserisci options solo se sono realmente visibili o fornite.\nPer un consenso/privacy usa type=consent oppure checkbox.\nPer allegati o caricamento documenti usa type=upload. Se visibili, puoi aggiungere config.accept, config.max_mb e config.multiple senza inventare valori.\nPer una sezione interna reale del form puoi usare type=heading.\nSe vengono forniti più screenshot dello stesso modulo in stati diversi, confrontali e riconosci i campi condizionali solo quando la relazione è chiaramente osservabile. Per una condizione usa "conditions":[{"field":"chiave_campo","operator":"eq","value":"valore"}], "condition_logic":"all", "condition_action":"show". Non inventare condizioni.\nIgnora tutto ciò che non è un campo del modulo.\n\nIMPORTANTE: crea un file scaricabile chiamato forms-ai-import.json contenente esclusivamente il JSON valido. Non aggiungere Markdown, spiegazioni o testo fuori dal file.`;}
function aiShowError(message=''){if(!aiError)return;aiError.hidden=!message;aiError.textContent=message;}
function aiOpen(){if(editorLocked)return;if(!aiModal){console.error('Forms AI: modal non disponibile');return;}aiShowError('');aiModal.hidden=false;aiModal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';requestAnimationFrame(()=>document.getElementById('df-ai-download-instructions')?.focus());}
function aiClose(){if(!aiModal)return;aiModal.hidden=true;aiModal.setAttribute('aria-hidden','true');document.body.style.overflow='';}
function aiResetAfterImport(){aiDraftFields=[];aiPreviewFilter='all';aiLoadedJson='';const file=document.getElementById('df-ai-file'),status=document.getElementById('df-ai-file-status'),description=document.getElementById('df-ai-description');if(file)file.value='';if(status)status.textContent='Nessun file selezionato · JSON massimo 1 MB';if(description)description.value='';const htmlFile=document.getElementById('df-ai-html-file'),htmlStatus=document.getElementById('df-ai-html-status');if(htmlFile)htmlFile.value='';if(htmlStatus)htmlStatus.textContent='HTML/ZIP massimo 25 MB';if(aiPreview)aiPreview.hidden=true;if(aiPreviewList)aiPreviewList.innerHTML='';if(aiImportButton)aiImportButton.disabled=true;if(aiImportCount)aiImportCount.textContent='· 0 campi';aiShowError('');aiRefreshFileClearButtons();}
document.getElementById('df-open-ai-import')?.addEventListener('click',aiOpen);aiModal?.querySelectorAll('[data-ai-close]').forEach(x=>x.addEventListener('click',aiClose));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&aiModal&&!aiModal.hidden)aiClose();});
document.getElementById('df-ai-download-instructions')?.addEventListener('click',()=>{const blob=new Blob([aiPromptText()],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='forms-ai-chatgpt.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),500);});
document.getElementById('df-ai-file')?.addEventListener('change',async e=>{const file=e.target.files?.[0],status=document.getElementById('df-ai-file-status');aiLoadedJson='';if(!file){if(status)status.textContent='Nessun file selezionato · JSON massimo 1 MB';return;}if(file.size>1024*1024){aiShowError('Il file JSON supera 1 MB.');e.target.value='';if(status)status.textContent='Nessun file selezionato · JSON massimo 1 MB';return;}try{aiLoadedJson=await file.text();aiShowError('');if(status)status.textContent=`✓ ${file.name}`;}catch{aiLoadedJson='';aiShowError('Impossibile leggere il file JSON.');if(status)status.textContent='Errore lettura file';}});
function aiNorm(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'').trim();}
function aiSlug(v){return String(v||'field').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,60)||'field';}
function aiNearestWidth(v){const n=Number(v||100);return aiWidths.reduce((a,b)=>Math.abs(b-n)<Math.abs(a-n)?b:a,100);}
function aiBool(v){if(typeof v==='boolean')return v;if(typeof v==='number')return v===1;return ['1','true','yes','si','sì','required','obbligatorio'].includes(String(v||'').trim().toLowerCase());}
function aiOptions(v){if(Array.isArray(v))return v.map(x=>String(x||'').trim().slice(0,180)).filter(Boolean).slice(0,100);if(typeof v==='string')return v.split(/\r?\n|\s*\|\s*/).map(x=>x.trim().slice(0,180)).filter(Boolean).slice(0,100);return [];}
function aiCategory(type){if(['email','tel','url'].includes(type))return'contact';if(['country','region','city','province','postcode','nationality'].includes(type))return'address';if(aiChoiceTypes.has(type)||['checkbox','toggle'].includes(type))return'choices';if(['number','member_number','tax_code'].includes(type))return'values';if(['date','time','datetime'].includes(type))return'datetime';if(type==='upload')return'document';if(['heading','fieldset','separator'].includes(type))return'structure';if(type==='consent')return'consent';return'personal';}
function aiConditions(v){const allowed=new Set(['eq','neq','contains','not_contains','empty','not_empty','gt','lt','checked','not_checked']);if(!Array.isArray(v))return[];return v.slice(0,12).map(r=>{if(!r||typeof r!=='object')return null;const field=aiSlug(r.field||r.key||r.name||''),operator=String(r.operator||'eq').toLowerCase(),value=String(r.value??'').replace(/[<>]/g,'').slice(0,180);if(!field||!allowed.has(operator))return null;return{field,operator,value};}).filter(Boolean);}
function aiFindDuplicate(field){const l=aiNorm(field.label),k=aiNorm(field.key);return selected.find(x=>(l&&aiNorm(x.label)===l)||(k&&aiNorm(x.key)===k))||null;}
function aiParse(raw){let text=String(raw||'').trim();if(!text)throw new Error('Carica il file forms-ai-import.json generato da ChatGPT.');text=text.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();let data;try{data=JSON.parse(text);}catch{const a=text.indexOf('{'),b=text.lastIndexOf('}');if(a>=0&&b>a){try{data=JSON.parse(text.slice(a,b+1));}catch{}}}if(!data)throw new Error('Il file non contiene un JSON valido. Genera di nuovo forms-ai-import.json con il file istruzioni di Forms.');if(data.format&&data.format!=='xdecaro-forms-ai')throw new Error('Il file non usa il formato xdecaro-forms-ai.');const fields=Array.isArray(data)?data:Array.isArray(data.fields)?data.fields:null;if(!fields)throw new Error('Nel JSON manca l’elenco fields.');if(fields.length>100)throw new Error('Il file contiene più di 100 campi. Riduci il modulo prima di importarlo.');return fields;}
function aiNormalizeField(raw,index){if(!raw||typeof raw!=='object')return null;let type=String(raw.type||'text').trim().toLowerCase().replace(/\s+/g,'_');type=aiAliases[type]||type;if(aiIgnoredTypes.has(type))return null;const warnings=[];if(!aiAllowedTypes.has(type)){warnings.push(`Tipo “${type}” non supportato: convertito in Testo.`);type='text';}let label=String(raw.label||raw.name||raw.title||`Campo ${index+1}`).trim().replace(/[<>]/g,'').slice(0,150)||`Campo ${index+1}`;const uploadCfg=type==='upload'?{accept:String(raw.config?.accept??raw.accept??'').replace(/[<>]/g,'').slice(0,500),max_mb:Math.max(1,Math.min(100,Number(raw.config?.max_mb??raw.max_mb??5)||5)),multiple:aiBool(raw.config?.multiple??raw.multiple),max_files:Math.max(1,Math.min(20,Number(raw.config?.max_files??raw.max_files??1)||1))}:{};const field={label,key:aiSlug(raw.key||raw.name||label),type,required:aiBool(raw.required),width:aiNearestWidth(raw.width),row:Math.max(0,parseInt(raw.row,10)||0),placeholder:String(raw.placeholder||'').replace(/[<>]/g,'').slice(0,255),options:aiOptions(raw.options),config:uploadCfg,conditions:aiConditions(raw.conditions),condition_logic:String(raw.condition_logic||'all')==='any'?'any':'all',condition_action:['show','hide','require','disable'].includes(String(raw.condition_action||'show'))?String(raw.condition_action||'show'):'show',confidence:['high','medium','low'].includes(String(raw.confidence||'').toLowerCase())?String(raw.confidence).toLowerCase():'medium',warning:String(raw.warning||'').replace(/[<>]/g,'').slice(0,260),_include:true,_duplicate:null};if(aiChoiceTypes.has(type)&&!field.options.length)warnings.push('Controlla le opzioni: non sono state fornite.');if(field.warning)warnings.push(field.warning);if(field.conditions.length)warnings.push(`Condizione rilevata: ${field.conditions.map(c=>`${c.field} ${c.operator==='neq'?'≠':'='} ${c.value}`).join(' · ')}`);field._warnings=warnings;field._duplicate=aiFindDuplicate(field);if(field._duplicate){field._warnings.push(`Possibile duplicato di “${field._duplicate.label}” già presente.`);field._include=false;}if(field.confidence==='low'){field._warnings.push('Riconoscimento con poca sicurezza: verifica questo campo.');field._include=false;}return field;}
function aiNeedsReview(f){return f?.confidence==='medium'||f?.confidence==='low';}
function aiMatchesPreviewFilter(f){if(aiPreviewFilter==='review')return aiNeedsReview(f);if(aiPreviewFilter==='duplicates')return!!f?._duplicate;return true;}
function aiUpdatePreviewFilterButtons(){const review=aiDraftFields.filter(aiNeedsReview).length,dup=aiDraftFields.filter(f=>f._duplicate).length,rb=document.getElementById('df-ai-filter-review'),db=document.getElementById('df-ai-filter-duplicates');if(rb){rb.textContent=`Da controllare (${review})`;rb.classList.toggle('is-active',aiPreviewFilter==='review');rb.setAttribute('aria-pressed',aiPreviewFilter==='review'?'true':'false');rb.disabled=review===0;}if(db){db.textContent=`Duplicati (${dup})`;db.classList.toggle('is-active',aiPreviewFilter==='duplicates');db.setAttribute('aria-pressed',aiPreviewFilter==='duplicates'?'true':'false');db.disabled=dup===0;}}
function aiSetPreviewFilter(filter){filter=['review','duplicates'].includes(filter)?filter:'all';aiPreviewFilter=aiPreviewFilter===filter?'all':filter;aiRenderPreview();}
function aiPrepare(fields){const ignored=fields.length;aiPreviewFilter='all';aiDraftFields=fields.map(aiNormalizeField).filter(Boolean);const skipped=ignored-aiDraftFields.length;if(!aiDraftFields.length)throw new Error('Non ho trovato campi importabili nel risultato.');aiDraftFields.forEach(f=>{f._duplicate=aiFindDuplicate(f);});aiRenderPreview(skipped);}
function aiTypeOptions(current){return [...aiAllowedTypes].map(t=>`<option value="${esc(t)}" ${t===current?'selected':''}>${esc(tr.types[t]||t)}</option>`).join('');}
function aiWidthOptions(current){return aiWidths.map(w=>`<option value="${w}" ${Number(current)===w?'selected':''}>${w}%</option>`).join('');}
function aiRefreshDuplicates(){aiDraftFields.forEach(f=>{f._duplicate=aiFindDuplicate(f);});}
function aiUpdateImportCount(){const n=aiDraftFields.filter(f=>f._include).length;if(aiImportCount)aiImportCount.textContent=`· ${n} camp${n===1?'o':'i'}`;if(aiImportButton)aiImportButton.disabled=n===0;const dup=aiDraftFields.filter(f=>f._duplicate).length,review=aiDraftFields.filter(aiNeedsReview).length;const summary=document.getElementById('df-ai-preview-summary');if(summary)summary.textContent=`${aiDraftFields.length} campi riconosciuti · ${dup} duplicat${dup===1?'o':'i'} · ${review} da controllare`;aiUpdatePreviewFilterButtons();}
function aiRenderPreview(skipped=0){aiRefreshDuplicates();aiPreview.hidden=false;aiPreviewList.innerHTML='';let visible=0;aiDraftFields.forEach((f,i)=>{if(!aiMatchesPreviewFilter(f))return;visible++;const row=document.createElement('div');row.className='df-ai-row'+(f._duplicate?' is-duplicate':'')+(f.confidence==='low'?' is-low':'');const warnings=[...new Set(f._warnings||[])];const choice=aiChoiceTypes.has(f.type);row.innerHTML=`<div class="df-ai-row-check"><input type="checkbox" data-ai-include ${f._include?'checked':''} aria-label="Importa ${esc(f.label)}"></div><label class="df-ai-main-label"><span>Etichetta</span><input type="text" data-ai-label value="${esc(f.label)}" aria-label="Etichetta"></label><select data-ai-type aria-label="Tipo">${aiTypeOptions(f.type)}</select><label class="df-ai-required"><input type="checkbox" data-ai-required ${f.required?'checked':''}> Obbl.</label><select data-ai-width aria-label="Larghezza">${aiWidthOptions(f.width)}</select><span class="df-ai-confidence ${esc(f.confidence)}">${f.confidence==='high'?'Alta':f.confidence==='low'?'Bassa':'Media'}</span><div class="df-ai-order"><button type="button" data-ai-up title="Sposta su">↑</button><button type="button" data-ai-down title="Sposta giù">↓</button></div><div class="df-ai-row-extra"><label>Placeholder<input type="text" data-ai-placeholder value="${esc(f.placeholder)}"></label><label class="df-ai-options-wrap ${choice?'':'is-hidden'}">Opzioni<textarea data-ai-options>${esc((f.options||[]).join('\n'))}</textarea></label></div>${warnings.length?`<div class="df-ai-warning">⚠ ${warnings.map(esc).join(' · ')}</div>`:''}`;const include=row.querySelector('[data-ai-include]');include.onchange=()=>{f._include=include.checked;aiUpdateImportCount();};row.querySelector('[data-ai-label]').onchange=e=>{f.label=e.target.value.slice(0,150);f.key=aiSlug(f.label);aiRefreshDuplicates();aiRenderPreview(skipped);};row.querySelector('[data-ai-type]').onchange=e=>{f.type=e.target.value;f._warnings=(f._warnings||[]).filter(x=>!x.startsWith('Controlla le opzioni'));if(aiChoiceTypes.has(f.type)&&!f.options.length)f._warnings.push('Controlla le opzioni: non sono state fornite.');aiRenderPreview(skipped);};row.querySelector('[data-ai-required]').onchange=e=>{f.required=e.target.checked;};row.querySelector('[data-ai-width]').onchange=e=>{f.width=Number(e.target.value);};row.querySelector('[data-ai-placeholder]').oninput=e=>{f.placeholder=e.target.value.slice(0,255);};row.querySelector('[data-ai-options]').oninput=e=>{f.options=aiOptions(e.target.value);};row.querySelector('[data-ai-up]').onclick=()=>{if(i<1)return;[aiDraftFields[i-1],aiDraftFields[i]]=[aiDraftFields[i],aiDraftFields[i-1]];aiRenderPreview(skipped);};row.querySelector('[data-ai-down]').onclick=()=>{if(i>=aiDraftFields.length-1)return;[aiDraftFields[i+1],aiDraftFields[i]]=[aiDraftFields[i],aiDraftFields[i+1]];aiRenderPreview(skipped);};aiPreviewList.appendChild(row);});if(!visible){const empty=document.createElement('div');empty.className='df-note df-ai-filter-empty';empty.textContent=aiPreviewFilter==='review'?'Nessun campo da controllare.':aiPreviewFilter==='duplicates'?'Nessun duplicato rilevato.':'Nessun campo da mostrare.';aiPreviewList.appendChild(empty);}if(skipped){const note=document.createElement('div');note.className='df-note';note.textContent=`${skipped} elemento/i decorativo/i o non importabile/i ignorato/i automaticamente.`;aiPreviewList.appendChild(note);}aiUpdateImportCount();aiPreview.scrollIntoView({behavior:'smooth',block:'nearest'});}

/* Forms 1.3.67 HTML import: local parser, no network and no script execution. */
function aiHtmlClean(v,max=150){return String(v??'').replace(/\s+/g,' ').trim().slice(0,max);}
function aiHtmlIsTechnical(el){if(!el||el.tagName!=='INPUT')return false;const type=String(el.getAttribute('type')||'text').toLowerCase();if(type==='hidden')return true;const idname=`${el.id||''} ${el.getAttribute('name')||''}`.toLowerCase();return /(^|[\s_\-])(csrf|token|honeypot|captcha|form_token|security_token)([\s_\-]|$)/.test(idname);}
function aiHtmlHiddenHint(el,root){let n=el,depth=0;while(n&&n!==root&&depth++<7){const cls=String(n.className||'').toLowerCase(),style=String(n.getAttribute?.('style')||'').toLowerCase();if(n.hasAttribute?.('hidden')||n.getAttribute?.('aria-hidden')==='true'||/(^|\s)(d-none|uk-hidden|is-hidden|conditional-hidden|js-hidden|hide)(\s|$)/.test(cls)||/(display\s*:\s*none|visibility\s*:\s*hidden)/.test(style))return true;n=n.parentElement;}return false;}
function aiHtmlLabelFor(el,root){let text='';if(el.id){const lab=[...root.querySelectorAll('label')].find(l=>l.htmlFor===el.id);if(lab)text=aiHtmlClean(lab.textContent);}if(!text){const wrap=el.closest('label');if(wrap)text=aiHtmlClean(wrap.textContent);}if(!text){let n=el.parentElement,depth=0;while(n&&n!==root&&depth++<5){const direct=[...n.children].find(c=>c.tagName==='LABEL'&&!c.contains(el));if(direct){text=aiHtmlClean(direct.textContent);if(text)break;}n=n.parentElement;}}return text||aiHtmlClean(el.getAttribute('aria-label'))||aiHtmlClean(el.getAttribute('placeholder'))||aiHtmlClean(el.getAttribute('name'))||aiHtmlClean(el.id);}
function aiHtmlGroupLabel(els,root){const first=els[0];let n=first?.parentElement,depth=0;while(n&&n!==root&&depth++<6){if(n.tagName==='FIELDSET'){const legend=[...n.children].find(c=>c.tagName==='LEGEND');const t=aiHtmlClean(legend?.textContent);if(t)return t;}const direct=[...n.children].find(c=>c.tagName==='LABEL'&&!els.some(e=>c.contains(e)));const t=aiHtmlClean(direct?.textContent);if(t)return t;n=n.parentElement;}return aiHtmlClean(first?.getAttribute('name'))||aiHtmlLabelFor(first,root);}
function aiHtmlOptionLabel(el,root){return aiHtmlLabelFor(el,root)||aiHtmlClean(el.value);}

function aiRegexEscape(v){return String(v||'').replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function aiCssWidthHint(el,root,cssText=''){if(!cssText)return null;let n=el,depth=0;while(n&&n!==root&&depth++<7){for(const cls of [...(n.classList||[])]){if(!/^[A-Za-z0-9_-]{1,80}$/.test(cls))continue;const re=new RegExp('\\.'+aiRegexEscape(cls)+'(?:[^,{]*)\\{([^}]*)\\}','gi');let m,found=null;while((m=re.exec(cssText))){const body=m[1]||'',wm=body.match(/(?:^|;)\\s*(?:width|flex-basis)\\s*:\\s*(\\d+(?:\\.\\d+)?)%/i);if(wm)found=Number(wm[1]);}if(found>0&&found<=100)return aiNearestWidth(found);}n=n.parentElement;}return null;}

function aiHtmlWidth(el,root,cssText=''){let n=el,depth=0,best=null,bestPriority=-1;while(n&&n!==root&&depth++<7){const data=Number(n.getAttribute?.('data-width')||0);if(data>0&&data<=100)return aiNearestWidth(data);const style=String(n.getAttribute?.('style')||'');const sm=style.match(/(?:width|flex-basis)\s*:\s*(\d+(?:\.\d+)?)%/i);if(sm)return aiNearestWidth(Number(sm[1]));const cls=String(n.className||'');const childUk=cls.match(/(?:^|\s)uk-child-width-(\d+)-(\d+)(?:@[a-z]+)?(?=\s|$)/i);if(childUk){const a=Number(childUk[1]),b=Number(childUk[2]);if(a>0&&b>0)return aiNearestWidth(100*a/b);}for(const m of cls.matchAll(/(?:^|\s)col(?:-(xs|sm|md|lg|xl|xxl))?-(\d{1,2})(?=\s|$)/gi)){const p={xxl:6,xl:5,lg:4,md:3,sm:2,xs:1}[String(m[1]||'').toLowerCase()]||0,num=Number(m[2]);if(num>=1&&num<=12&&p>=bestPriority){best=100*num/12;bestPriority=p;}}const uk=cls.match(/uk-width-(\d+)-(\d+)(?:@[a-z]+)?/i);if(uk){const a=Number(uk[1]),b=Number(uk[2]);if(a>0&&b>0)return aiNearestWidth(100*a/b);}if(/\b(half|w-50|width-50)\b/i.test(cls))return 50;if(/\b(third|w-33|width-33)\b/i.test(cls))return 33;if(/\b(two-thirds|w-66|width-66)\b/i.test(cls))return 66;if(/\b(quarter|w-25|width-25)\b/i.test(cls))return 25;if(/\b(three-quarters|w-75|width-75)\b/i.test(cls))return 75;n=n.parentElement;}const cssHint=aiCssWidthHint(el,root,cssText);if(cssHint)return cssHint;return best!=null?aiNearestWidth(best):100;}
function aiHtmlSemanticType(type,label,key){const txt=`${label} ${key}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();if(type==='text'){if(/nationalit|nationality/.test(txt))return'nationality';if(/(^|\s)(country|paese|stato)(\s|$)/.test(txt))return'country';if(/(^|\s)(province|provincia)(\s|$)/.test(txt))return'province';if(/(^|\s)(city|citta|localita|comune)(\s|$)/.test(txt))return'city';if(/postcode|postal|cap\b|code postal/.test(txt))return'postcode';if(/codice fiscale|tax code|fiscal code/.test(txt))return'tax_code';}return type;}
function aiHtmlExplicitConditions(el,root){const nodes=[];let n=el,depth=0;while(n&&n!==root&&depth++<7){nodes.push(n);n=n.parentElement;}for(const node of nodes){const get=(...names)=>{for(const name of names){const v=node.getAttribute?.(name);if(v!=null&&String(v).trim()!=='')return String(v).trim();}return'';};let field=get('data-condition-field','data-show-if-field','data-visible-if-field','data-depends-on','data-dependency-field');let value=get('data-condition-value','data-show-if-value','data-visible-if-value','data-dependency-value','data-value');let operator=get('data-condition-operator','data-operator')||'eq';let action=get('data-condition-action','data-action')||'show';if(field){operator={"=":'eq','==':'eq','!=':'neq','<>':'neq'}[operator]||operator;if(!['eq','neq','contains','not_contains','empty','not_empty','gt','lt','checked','not_checked'].includes(operator))operator='eq';if(!['show','hide','require','disable'].includes(action))action='show';return{conditions:[{field:aiSlug(field),operator,value:aiHtmlClean(value,180)}],condition_logic:'all',condition_action:action};}for(const attr of ['data-show-if','data-visible-if','data-condition','data-hide-if']){const expr=get(attr);if(!expr)continue;try{if(expr.trim().startsWith('{')){const j=JSON.parse(expr);const jf=j.field||j.key||j.name,jv=j.value??'',jo=j.operator||'eq';if(jf)return{conditions:[{field:aiSlug(jf),operator:['neq','!='].includes(jo)?'neq':'eq',value:aiHtmlClean(jv,180)}],condition_logic:j.logic==='any'?'any':'all',condition_action:attr==='data-hide-if'?'hide':(j.action||'show')};}}catch{}const m=expr.match(/^\s*([A-Za-z0-9_.\-\[\]]+)\s*(==|=|!=|:)\s*["']?(.+?)["']?\s*$/);if(m)return{conditions:[{field:aiSlug(m[1]),operator:m[2]==='!='?'neq':'eq',value:aiHtmlClean(m[3],180)}],condition_logic:'all',condition_action:attr==='data-hide-if'?'hide':'show'};}}
 return{conditions:[],condition_logic:'all',condition_action:'show'};}
function aiHtmlControlType(el,label,key,groupCount=1){if(el.tagName==='TEXTAREA')return'textarea';if(el.tagName==='SELECT')return el.multiple?'multiselect':'select';let type=String(el.getAttribute('type')||'text').toLowerCase();const map={'datetime-local':'datetime','phone':'tel',file:'upload'};type=map[type]||type;if(type==='radio')return'radio';if(type==='checkbox'){const txt=`${label} ${key}`.toLowerCase();if(groupCount>1)return'checkboxes';if(/privacy|gdpr|consent|consenso|autorizz/.test(txt))return'consent';return'checkbox';}if(!aiAllowedTypes.has(type))type='text';return aiHtmlSemanticType(type,label,key);}
function aiHtmlUploadConfig(el,root){if(String(el?.getAttribute?.('type')||'').toLowerCase()!=='file')return{};const cfg={accept:aiHtmlClean(el.getAttribute('accept')||'',500),multiple:!!el.multiple,max_files:el.multiple?2:1};let n=el,depth=0,text='';while(n&&n!==root&&depth++<4){text+=' '+String(n.textContent||'').replace(/\s+/g,' ').slice(0,1500);n=n.parentElement;}const m=text.match(/(?:massim[oa]|maximum|max(?:imum)?(?:\s+size)?)[^0-9]{0,35}(\d+(?:[.,]\d+)?)\s*MB/i)||text.match(/(\d+(?:[.,]\d+)?)\s*MB/i);if(m)cfg.max_mb=Math.max(1,Math.min(100,Number(String(m[1]).replace(',','.'))||5));return cfg;}
function aiHtmlRowToken(el,root){let n=el,depth=0;while(n&&n!==root&&depth++<6){const cls=String(n.className||'').toLowerCase();if(/(^|\s)(row|form-row|fields-row|uk-grid|grid)(\s|$)/.test(cls))return n;n=n.parentElement;}return null;}

function aiHtmlSectionCandidates(root,raw){
 const fieldLabels=new Set(raw.map(f=>aiSlug(f.label||''))),nodes=[],seen=new Set();
 const add=node=>{if(node&&!seen.has(node)){seen.add(node);nodes.push(node);}};
 root.querySelectorAll('legend,h2,h3,h4,h5,h6,[role="heading"],[data-section-title],.form-section-title,.section-title,.fieldset-title,.field-section-title,.group-title,.block-title,.uk-heading-line,.uk-heading-bullet,.uk-heading-small,.uk-heading-medium,.uk-heading-large,.uk-heading-xlarge').forEach(add);
 root.querySelectorAll('div,p,strong,span').forEach(el=>{
  if(el.closest('label,button,option'))return;
  if(el.querySelector('input,select,textarea,button'))return;
  let text=aiHtmlClean(el.textContent,120);if(!text||text.length<3||text.length>100)return;
  const meta=`${el.id||''} ${el.className||''} ${el.getAttribute?.('data-role')||''}`.toLowerCase();
  if(/form-title|page-title|article-title|module-title/.test(meta))return;
  const letters=(text.match(/[A-Za-zÀ-ÖØ-öø-ÿ]/g)||[]),upper=letters.length>=4&&letters.filter(ch=>ch===ch.toLocaleUpperCase()&&ch!==ch.toLocaleLowerCase()).length/letters.length>=.82;
  const named=/(^|[-_\s])(section|fieldset|heading|headline|legend|group-title|block-title|section-title)([-_\s]|$)|uk-heading/.test(meta);
  if(named||upper)add(el);
 });
 const order=[...root.querySelectorAll('*')],index=new Map(order.map((n,i)=>[n,i])),out=[];
 for(const node of nodes){
  if(node.closest('label,button,option'))continue;
  if(node.querySelector('input,select,textarea,button'))continue;
  let title=aiHtmlClean(node.textContent,120).replace(/\s*[*:]+\s*$/,'').trim();
  if(!title||title.length<3||title.length>100)continue;
  const slug=aiSlug(title);if(!slug||fieldLabels.has(slug))continue;
  if(/^(invia|submit|send|continua|continue|indietro|back|next|previous|seleziona file|select file)$/i.test(title))continue;
  const words=title.split(/\s+/).filter(Boolean);const tag=node.tagName||'';const semantic=/^(LEGEND|H2|H3|H4|H5|H6)$/.test(tag);
  if(words.length>10&&!semantic)continue;
  const pos=index.get(node);if(pos==null)continue;
  const meta=`${node.id||''} ${node.className||''}`.toLowerCase(),confidence=(semantic||/(section|fieldset|heading|legend|uk-heading)/.test(meta))?'high':'medium';
  out.push({node,index:pos,title,id:`section_${pos}_${slug}`,confidence});
 }
 out.sort((a,b)=>a.index-b.index);
 return{items:out,index};
}
function aiHtmlNearestSection(node,sectionInfo){
 const idx=sectionInfo?.index?.get(node);if(idx==null)return null;let found=null;
 for(const item of sectionInfo.items){if(item.index>=idx)break;found=item;}
 return found;
}


function aiHtmlPackSectionRows(fields,startRow){
 const tokenCounts=new Map();
 fields.forEach(f=>{const t=f._rowToken;if(t)tokenCounts.set(t,(tokenCounts.get(t)||0)+1);});
 let row=startRow,current=[],sum=0,sharedToken=null;
 const flush=()=>{if(!current.length)return;current.forEach(f=>{f.row=row;});row++;current=[];sum=0;sharedToken=null;};
 for(const f of fields){
  const width=Math.max(1,Math.min(100,Number(f.width||100))),token=f._rowToken,tokenShared=!!token&&(tokenCounts.get(token)||0)>1;
  let breakBefore=false;
  if(current.length){
   if(width>=100||sum+width>100)breakBefore=true;
   if(sharedToken&&(!tokenShared||token!==sharedToken))breakBefore=true;
   if(!sharedToken&&tokenShared)breakBefore=true;
  }
  if(breakBefore)flush();
  current.push(f);sum+=width;if(tokenShared)sharedToken=token;
  if(width>=100||sum>=99)flush();
 }
 flush();return row;
}

function aiHtmlParsePage(html,assets={}){const doc=new DOMParser().parseFromString(String(html||''),'text/html');const forms=[...doc.querySelectorAll('form')];const root=(forms.length?forms.sort((a,b)=>b.querySelectorAll('input,select,textarea').length-a.querySelectorAll('input,select,textarea').length)[0]:doc.body);if(!root)throw new Error('Il file HTML non contiene una pagina leggibile.');const all=[...root.querySelectorAll('input,select,textarea')].filter(el=>!aiHtmlIsTechnical(el)&&!['submit','reset','button','image'].includes(String(el.getAttribute('type')||'').toLowerCase()));if(!all.length)throw new Error('Non ho trovato campi di modulo importabili nel file HTML.');const groups=new Map();all.forEach(el=>{const t=String(el.getAttribute('type')||'').toLowerCase();if((t==='radio'||t==='checkbox')&&el.getAttribute('name')){const k=`${t}:${el.getAttribute('name')}`;if(!groups.has(k))groups.set(k,[]);groups.get(k).push(el);}});const processed=new Set(),raw=[];for(const el of all){if(processed.has(el))continue;const it=String(el.getAttribute('type')||'').toLowerCase(),gkey=(it==='radio'||it==='checkbox')&&el.getAttribute('name')?`${it}:${el.getAttribute('name')}`:'',group=gkey?(groups.get(gkey)||[el]):[el];group.forEach(x=>processed.add(x));const isGroup=group.length>1&&(it==='radio'||it==='checkbox');const label=isGroup?aiHtmlGroupLabel(group,root):aiHtmlLabelFor(el,root);const key=aiSlug(el.getAttribute('name')||el.id||label||`campo_${raw.length+1}`);const type=aiHtmlControlType(el,label,key,group.length);let options=[];if(el.tagName==='SELECT'){options=[...el.options].filter(o=>String(o.value||'').trim()!==''&&!o.disabled).map(o=>aiHtmlClean(o.textContent,180)).filter(Boolean).slice(0,100);}else if(isGroup){options=group.map(o=>aiHtmlOptionLabel(o,root)||aiHtmlClean(o.value,180)).filter(Boolean).slice(0,100);}let placeholder=aiHtmlClean(el.getAttribute('placeholder'),255);if(el.tagName==='SELECT'&&!placeholder){const empty=[...el.options].find(o=>String(o.value||'').trim()==='');if(empty)placeholder=aiHtmlClean(empty.textContent,255);}const hidden=group.some(x=>aiHtmlHiddenHint(x,root)),disabled=group.every(x=>x.disabled),cond=aiHtmlExplicitConditions(el,root),warnings=[];if(hidden&&cond.conditions.length)warnings.push('Campo nascosto con condizione esplicita rilevata nel markup.');else if(hidden)warnings.push('Campo nascosto nel markup: possibile condizionale, ma la regola non è esplicita.');if(disabled)warnings.push('Campo disabilitato nel file HTML.');const width=aiHtmlWidth(el,root,assets.css||'');raw.push({label:label||key,key,type,required:group.some(x=>x.required||x.getAttribute('aria-required')==='true'),width,row:0,placeholder,options,config:type==='upload'?aiHtmlUploadConfig(el,root):{},conditions:cond.conditions,condition_logic:cond.condition_logic,condition_action:cond.condition_action,confidence:hidden&&!cond.conditions.length?'medium':'high',warning:warnings.join(' '),_disabled:disabled,_rowToken:aiHtmlRowToken(el,root),_node:group[0]||el});}
 const uploadLabels=new Set(raw.filter(f=>f.type==='upload').map(f=>aiSlug(f.label)));for(let i=raw.length-1;i>=0;i--){const f=raw[i];if(f.type==='text'&&f._disabled&&uploadLabels.has(aiSlug(f.label)))raw.splice(i,1);}const keys=new Set(raw.map(f=>f.key));raw.forEach(f=>{if(f.conditions?.length){const before=f.conditions.length;f.conditions=f.conditions.filter(c=>keys.has(aiSlug(c.field))&&aiSlug(c.field)!==f.key);if(before&&!f.conditions.length){f.warning=`${f.warning?f.warning+' ':''}Condizione trovata ma il campo sorgente non è importabile o non è presente.`;f.confidence='medium';}}});
 const sectionInfo=aiHtmlSectionCandidates(root,raw);raw.forEach(f=>{f._section=aiHtmlNearestSection(f._node,sectionInfo);});
 const sectionGroups=[];let currentGroup=null;
 for(const f of raw){const sec=f._section||null,secId=sec?.id||'';if(!currentGroup||currentGroup.id!==secId){currentGroup={id:secId,section:sec,fields:[]};sectionGroups.push(currentGroup);}currentGroup.fields.push(f);}
 const out=[];let row=1,sectionCounter=0;
 for(const group of sectionGroups){
  if(group.section){const sec=group.section;out.push({label:sec.title,key:`section_${aiSlug(sec.title)}_${++sectionCounter}`,type:'heading',required:false,width:100,row,placeholder:'',options:[],config:{builder_role:'section',content:''},conditions:[],condition_logic:'all',condition_action:'show',confidence:sec.confidence||'high',warning:''});row++;}
  row=aiHtmlPackSectionRows(group.fields,row);
  group.fields.forEach(f=>{out.push(f);delete f._rowToken;delete f._disabled;delete f._node;delete f._section;});
 }
 out.sort((a,b)=>Number(a.row||0)-Number(b.row||0));return out.slice(0,100);}

function aiZipU16(view,pos){return view.getUint16(pos,true)}
function aiZipU32(view,pos){return view.getUint32(pos,true)}
async function aiZipInflateRaw(bytes){if(typeof DecompressionStream==='undefined')throw new Error('Questo browser non supporta la decompressione ZIP locale. Usa un file HTML oppure aggiorna il browser.');let stream;try{stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));}catch{throw new Error('Impossibile decomprimere il file ZIP in questo browser.');}return new Uint8Array(await new Response(stream).arrayBuffer());}
function aiZipFindEnd(view){const min=Math.max(0,view.byteLength-65557);for(let p=view.byteLength-22;p>=min;p--){if(view.getUint32(p,true)===0x06054b50)return p;}return-1;}
async function aiReadZipPage(file){const buffer=await file.arrayBuffer(),view=new DataView(buffer),bytes=new Uint8Array(buffer),end=aiZipFindEnd(view);if(end<0)throw new Error('Il file ZIP non è valido o non contiene una directory ZIP leggibile.');const count=aiZipU16(view,end+10),central=aiZipU32(view,end+16);if(count>3000)throw new Error('Lo ZIP contiene troppi file. Salva soltanto la pagina web completa.');let pos=central,totalText=0;const decoder=new TextDecoder('utf-8'),htmlFiles=[],cssFiles=[],jsFiles=[];for(let i=0;i<count;i++){if(pos+46>view.byteLength||view.getUint32(pos,true)!==0x02014b50)break;const flags=aiZipU16(view,pos+8),method=aiZipU16(view,pos+10),compSize=aiZipU32(view,pos+20),rawSize=aiZipU32(view,pos+24),nameLen=aiZipU16(view,pos+28),extraLen=aiZipU16(view,pos+30),commentLen=aiZipU16(view,pos+32),local=aiZipU32(view,pos+42),name=decoder.decode(bytes.slice(pos+46,pos+46+nameLen));pos+=46+nameLen+extraLen+commentLen;if(!name||name.endsWith('/')||(flags&1))continue;const lower=name.toLowerCase(),kind=/\.html?$/.test(lower)?'html':/\.css$/.test(lower)?'css':/\.js$/.test(lower)?'js':'';if(!kind)continue;if(rawSize>4*1024*1024||totalText+rawSize>12*1024*1024)continue;if(local+30>view.byteLength||view.getUint32(local,true)!==0x04034b50)continue;const ln=aiZipU16(view,local+26),le=aiZipU16(view,local+28),start=local+30+ln+le,endData=start+compSize;if(endData>view.byteLength)continue;let out;if(method===0)out=bytes.slice(start,endData);else if(method===8)out=await aiZipInflateRaw(bytes.slice(start,endData));else continue;totalText+=out.byteLength;const text=decoder.decode(out);if(kind==='html')htmlFiles.push({name,text});else if(kind==='css')cssFiles.push({name,text});else jsFiles.push({name,text});}if(!htmlFiles.length)throw new Error('Nello ZIP non è stato trovato alcun file .html o .htm.');const score=x=>{const t=x.text||'';return((t.match(/<form\b/gi)||[]).length*10000)+((t.match(/<(?:input|select|textarea)\b/gi)||[]).length*100)+Math.min(t.length,500000)/1000;};htmlFiles.sort((a,b)=>score(b)-score(a));const css=cssFiles.map(x=>x.text).join('\n').slice(0,3*1024*1024),js=jsFiles.map(x=>x.text).join('\n').slice(0,2*1024*1024);return{html:htmlFiles[0].text,css,js,mainName:htmlFiles[0].name,resourceCount:cssFiles.length+jsFiles.length};}
async function aiReadSavedPage(file){const lower=String(file?.name||'').toLowerCase();if(lower.endsWith('.zip')||/zip/.test(String(file?.type||'')))return aiReadZipPage(file);return{html:await file.text(),css:'',js:'',mainName:file.name||'pagina.html',resourceCount:0};}

document.getElementById('df-ai-html-analyze')?.addEventListener('click',async()=>{const input=document.getElementById('df-ai-html-file'),file=input?.files?.[0],status=document.getElementById('df-ai-html-status');if(!file){aiShowError('Seleziona prima un file HTML oppure ZIP.');return;}if(file.size>25*1024*1024){aiShowError('Il file supera 25 MB. Crea uno ZIP più leggero oppure carica soltanto il file HTML.');return;}try{if(status)status.textContent='Analisi pagina…';const page=await aiReadSavedPage(file),fields=aiHtmlParsePage(page.html,{css:page.css,js:page.js});aiShowError('');aiPrepare(fields);if(status)status.textContent=`✓ ${fields.length} campi trovati${page.resourceCount?` · ${page.resourceCount} risorse CSS/JS lette`:''}`;}catch(err){if(status)status.textContent='Analisi non riuscita';aiShowError(err?.message||'Impossibile analizzare la pagina salvata.');}});
/* End Forms 1.3.67 HTML import. */


/* Forms 1.3.67: selected-file clear buttons. */
function aiClearPreparedPreview(){aiDraftFields=[];aiPreviewFilter='all';if(aiPreview)aiPreview.hidden=true;if(aiPreviewList)aiPreviewList.innerHTML='';if(aiImportButton)aiImportButton.disabled=true;if(aiImportCount)aiImportCount.textContent='· 0 campi';aiShowError('');}
function aiRefreshFileClearButtons(){const jf=document.getElementById('df-ai-file'),hf=document.getElementById('df-ai-html-file'),jc=document.getElementById('df-ai-file-clear'),hc=document.getElementById('df-ai-html-clear');if(jc)jc.hidden=!(jf?.files?.length);if(hc)hc.hidden=!(hf?.files?.length);}
document.getElementById('df-ai-file')?.addEventListener('change',()=>queueMicrotask(aiRefreshFileClearButtons));
document.getElementById('df-ai-html-file')?.addEventListener('change',()=>queueMicrotask(aiRefreshFileClearButtons));
document.getElementById('df-ai-file-clear')?.addEventListener('click',()=>{const input=document.getElementById('df-ai-file'),status=document.getElementById('df-ai-file-status');if(input)input.value='';aiLoadedJson='';if(status)status.textContent='Nessun file selezionato · JSON massimo 1 MB';aiClearPreparedPreview();aiRefreshFileClearButtons();});
document.getElementById('df-ai-html-clear')?.addEventListener('click',()=>{const input=document.getElementById('df-ai-html-file'),status=document.getElementById('df-ai-html-status');if(input)input.value='';if(status)status.textContent='HTML/ZIP massimo 25 MB';aiClearPreparedPreview();aiRefreshFileClearButtons();});

function aiRefreshPremiumPicker(inputId){const input=document.getElementById(inputId);if(!input)return;const shell=input.closest('.df-ai-file-row')?.querySelector('.df-ai-upload-shell'),name=shell?.querySelector('[data-ai-upload-name]');if(!shell||!name)return;const file=input.files?.[0];shell.classList.toggle('has-file',!!file);name.textContent=file?.name||(inputId==='df-ai-file'?'Trascina qui il JSON o selezionalo':'Trascina qui HTML/ZIP o selezionalo');}
function aiEnhanceFilePicker(inputId,clearId,statusId){const input=document.getElementById(inputId),clear=document.getElementById(clearId),status=document.getElementById(statusId);if(!input||!clear||input.dataset.premiumPicker==='1')return;input.dataset.premiumPicker='1';input.classList.add('df-ai-native-file');clear.innerHTML=modernUiIcon('trash');clear.classList.add('df-ai-ui-delete');const row=input.closest('.df-ai-file-row');if(!row)return;row.classList.add('df-ai-premium-file-row');const shell=document.createElement('div');shell.className='df-ai-upload-shell';shell.tabIndex=0;shell.setAttribute('role','button');shell.setAttribute('aria-label','Seleziona file');shell.innerHTML=`<span class="df-ai-upload-copy"><strong>Seleziona file</strong><span data-ai-upload-name></span></span>`;row.insertBefore(shell,input);shell.appendChild(input);shell.appendChild(clear);const pick=()=>input.click();shell.addEventListener('click',e=>{if(e.target.closest('.df-ai-ui-delete'))return;pick();});shell.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick();}});['dragenter','dragover'].forEach(ev=>shell.addEventListener(ev,e=>{e.preventDefault();shell.classList.add('is-dragover');}));['dragleave','drop'].forEach(ev=>shell.addEventListener(ev,e=>{e.preventDefault();shell.classList.remove('is-dragover');}));shell.addEventListener('drop',e=>{const file=e.dataTransfer?.files?.[0];if(!file)return;try{const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));}catch{}});input.addEventListener('change',()=>queueMicrotask(()=>aiRefreshPremiumPicker(inputId)));aiRefreshPremiumPicker(inputId);if(status)row.appendChild(status);if(inputId==='df-ai-html-file'){const analyze=document.getElementById('df-ai-html-analyze');if(analyze){let actions=row.parentElement?.querySelector('.df-ai-page-actions');if(!actions){actions=document.createElement('div');actions.className='df-ai-actions df-ai-page-actions';row.after(actions);}analyze.classList.remove('df-small');analyze.classList.add('df-primary');actions.appendChild(analyze);}}}
function aiEnhanceUploadControls(){aiEnhanceFilePicker('df-ai-file','df-ai-file-clear','df-ai-file-status');aiEnhanceFilePicker('df-ai-html-file','df-ai-html-clear','df-ai-html-status');}
aiEnhanceUploadControls();document.getElementById('df-open-ai-import')?.addEventListener('click',()=>setTimeout(aiEnhanceUploadControls,0));
document.getElementById('df-ai-file-clear')?.addEventListener('click',()=>queueMicrotask(()=>aiRefreshPremiumPicker('df-ai-file')));document.getElementById('df-ai-html-clear')?.addEventListener('click',()=>queueMicrotask(()=>aiRefreshPremiumPicker('df-ai-html-file')));


function aiInitModeSelector(){const modal=document.getElementById('df-ai-import-modal');if(!modal)return;const modes=modal.querySelector('.df-ai-modes');if(!modes||modes.dataset.aiModesReady==='1')return;const pageCard=modes.querySelector('.df-ai-html-mode'),directCard=[...modes.querySelectorAll('.df-ai-mode')].find(x=>x.textContent.includes('Analizza direttamente')),workflow=modal.querySelector('.df-ai-workflow');if(!pageCard||!directCard||!workflow)return;modes.dataset.aiModesReady='1';const chatCard=document.createElement('div');chatCard.className='df-ai-mode is-active';chatCard.dataset.aiModeSelect='chatgpt';chatCard.tabIndex=0;chatCard.setAttribute('role','button');chatCard.innerHTML='<div class="df-ai-mode-head"><strong>✨ Usa ChatGPT</strong><span class="df-ai-badge df-ai-badge-free">Senza API</span></div><div class="df-ai-direct-note">Screenshot + file istruzioni → JSON pronto per Forms.</div>';modes.insertBefore(chatCard,pageCard);pageCard.dataset.aiModeSelect='page';pageCard.tabIndex=0;pageCard.setAttribute('role','button');const pageTitle=pageCard.querySelector('strong');if(pageTitle)pageTitle.textContent='📄 Da pagina salvata';const pageNote=pageCard.querySelector('.df-ai-direct-note');if(pageNote)pageNote.textContent='HTML o ZIP della pagina completa, con struttura e risorse locali.';const pageFileRow=pageCard.querySelector('.df-ai-file-row');if(pageFileRow)pageFileRow.remove();directCard.classList.remove('is-disabled');directCard.removeAttribute('aria-disabled');directCard.dataset.aiModeSelect='direct';directCard.tabIndex=0;directCard.setAttribute('role','button');const panels=document.createElement('div');panels.className='df-ai-mode-panels';const chatPanel=document.createElement('div');chatPanel.className='df-ai-mode-panel';chatPanel.dataset.aiPanel='chatgpt';chatPanel.appendChild(workflow);const pagePanel=document.createElement('div');pagePanel.className='df-ai-mode-panel df-ai-page-panel';pagePanel.dataset.aiPanel='page';pagePanel.hidden=true;pagePanel.innerHTML='<h4>Da pagina salvata</h4><div class="df-ai-direct-note">Carica <strong>.html / .htm / .zip</strong>. Con uno ZIP di “Pagina web, completa”, Forms prova a usare anche CSS e risorse locali per riconoscere meglio il layout.</div>';if(pageFileRow)pagePanel.appendChild(pageFileRow);const pageActions=pageCard.querySelector('.df-ai-page-actions');if(pageActions)pagePanel.appendChild(pageActions);const directPanel=document.createElement('div');directPanel.className='df-ai-mode-panel df-ai-direct-panel';directPanel.dataset.aiPanel='direct';directPanel.hidden=true;directPanel.innerHTML='<h4>⚡ Analizza direttamente</h4><div class="df-ai-direct-note">Funzione API opzionale prevista per una versione futura. Al momento non effettua chiamate esterne.</div>';panels.append(chatPanel,pagePanel,directPanel);modes.after(panels);const cards={chatgpt:chatCard,page:pageCard,direct:directCard};function selectMode(name){modes.classList.remove('is-chatgpt','is-page','is-direct');modes.classList.add('is-'+name);Object.entries(cards).forEach(([k,c])=>{c.classList.toggle('is-active',k===name);c.setAttribute('aria-pressed',k===name?'true':'false');});panels.querySelectorAll('[data-ai-panel]').forEach(p=>p.hidden=p.dataset.aiPanel!==name);}Object.entries(cards).forEach(([name,card])=>{card.addEventListener('click',()=>selectMode(name));card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectMode(name);}});});selectMode('chatgpt');}
aiInitModeSelector();
document.getElementById('df-open-ai-import')?.addEventListener('click',()=>queueMicrotask(aiInitModeSelector),true);


document.getElementById('df-ai-check')?.addEventListener('click',()=>{try{aiShowError('');aiPrepare(aiParse(aiLoadedJson));}catch(err){aiShowError(err?.message||'Impossibile controllare il risultato.');aiPreview.hidden=true;}});
document.getElementById('df-ai-select-all')?.addEventListener('click',()=>{aiPreviewFilter='all';aiDraftFields.forEach(f=>f._include=true);aiRenderPreview();});document.getElementById('df-ai-select-safe')?.addEventListener('click',()=>{aiPreviewFilter='all';aiDraftFields.forEach(f=>f._include=!f._duplicate&&f.confidence==='high');aiRenderPreview();});document.getElementById('df-ai-filter-review')?.addEventListener('click',()=>aiSetPreviewFilter('review'));document.getElementById('df-ai-filter-duplicates')?.addEventListener('click',()=>aiSetPreviewFilter('duplicates'));
function aiQuickFromDescription(text){const v=String(text||'').toLowerCase(),defs=[[/\bnome\b/,'Nome','nome','text',50],[/\bcognome\b/,'Cognome','cognome','text',50],[/e-?mail/,'Email','email','email',100],[/telefono|cellulare|phone/,'Telefono','telefono','tel',100],[/data di nascita|nascita/,'Data di nascita','data_nascita','date',50],[/codice fiscale/,'Codice fiscale','codice_fiscale','tax_code',50],[/indirizzo/,'Indirizzo','indirizzo','text',100],[/\bcap\b|codice postale/,'CAP','cap','postcode',33],[/\bcitt[aà]\b|comune/,'Città','citta','city',33],[/provincia/,'Provincia','provincia','province',33],[/corso|scelta corso/,'Corso scelto','corso','select',100],[/privacy|consenso/,'Privacy','privacy','consent',100],[/note|messaggio|comment/,'Note','note','textarea',100]];const out=[];defs.forEach(([re,label,key,type,width])=>{if(re.test(v))out.push({label,key,type,width,required:['nome','cognome','email','privacy'].includes(key),options:[],confidence:'high',warning:type==='select'?'Inserisci le opzioni disponibili.':''});});return out;}
document.getElementById('df-ai-description-build')?.addEventListener('click',()=>{const text=document.getElementById('df-ai-description')?.value||'';try{const fields=aiQuickFromDescription(text);if(!fields.length)throw new Error('Non riconosco abbastanza campi nella descrizione. Usa nomi come nome, cognome, email, telefono, corso, privacy, note oppure usa ChatGPT.');aiShowError('');aiPrepare(fields);}catch(err){aiShowError(err?.message||'Impossibile preparare i campi.');}});
function aiLayoutGroups(drafts){const groups=[];let current=[],sum=0,lastRow=null;drafts.forEach((f,i)=>{const explicit=Number(f.row||0)>0?Number(f.row):null;if(current.length&&((explicit&&lastRow&&explicit!==lastRow)||sum+Number(f.width||100)>100)){groups.push(current);current=[];sum=0;}current.push(f);sum+=Number(f.width||100);if(explicit)lastRow=explicit;if(sum>=99){groups.push(current);current=[];sum=0;lastRow=null;}});if(current.length)groups.push(current);return groups;}
function aiBuildImportedField(draft,row,col){const x=defaultFieldConfig({key:uniqueKey(draft.key||draft.label),type:draft.type,category:aiCategory(draft.type),label:draft.label,placeholder:draft.placeholder||'',help:'',default:'',options:Array.isArray(draft.options)?draft.options:[],required:!!draft.required,config:{...(draft.config&&typeof draft.config==='object'?draft.config:{}),conditions:aiConditions(draft.conditions),condition_logic:draft.condition_logic==='any'?'any':'all',condition_action:['show','hide','require','disable'].includes(draft.condition_action)?draft.condition_action:'show'}});x.config.layout={row,col,width:Number(draft.width||100)};return x;}
function aiImportSelected(){if(editorLocked)return;const chosen=aiDraftFields.filter(f=>f._include);if(!chosen.length)return;const groups=aiLayoutGroups(chosen),position=document.getElementById('df-ai-position')?.value||'append';let startRow=Math.max(0,...selected.map(f=>Number(f.config?.layout?.row||0)))+1,insertIndex=selected.length;if(position==='current'&&activeFieldKey){const active=selected.find(f=>f.key===activeFieldKey);const activeRow=Number(active?.config?.layout?.row||0);if(activeRow>0){selected.forEach(f=>{defaultFieldConfig(f);if(Number(f.config.layout.row||0)>activeRow)f.config.layout.row=Number(f.config.layout.row)+groups.length;});startRow=activeRow+1;const indexes=selected.map((f,i)=>[f,i]).filter(([f])=>Number(f.config?.layout?.row||0)===activeRow).map(([,i])=>i);insertIndex=indexes.length?Math.max(...indexes)+1:selected.findIndex(f=>f.key===activeFieldKey)+1;}}const imported=[];groups.forEach((group,ri)=>group.forEach((draft,ci)=>imported.push(aiBuildImportedField(draft,startRow+ri,ci+1))));selected.splice(insertIndex,0,...imported);activeFieldKey=imported[0]?.key||activeFieldKey;openFieldKeys.clear();if(activeFieldKey)openFieldKeys.add(activeFieldKey);renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();sync();clearTimeout(historyTimer);pushHistory();aiResetAfterImport();aiClose();const fieldsSection=[...document.querySelectorAll('[data-accordion]')][2];fieldsSection?.classList.add('is-open');fieldsSection?.querySelector('.df-section-toggle')?.setAttribute('aria-expanded','true');setTimeout(()=>document.querySelector(`[data-layout-key="${CSS.escape(activeFieldKey||'')}"]`)?.scrollIntoView({behavior:'smooth',block:'nearest'}),80);}
aiImportButton?.addEventListener('click',aiImportSelected);

/* Forms 1.3.6: bind quick templates early so unrelated later initializers cannot disable them. */
const quickFormTemplates={contact:['first_name','last_name','email','phone','subject','message','privacy_consent'],registration:['first_name','last_name','birth_date','email','phone','address','postcode','city','privacy_consent'],event:['first_name','last_name','email','event_date','participants','notes','privacy_consent'],membership:['first_name','last_name','birth_date','email','phone','address','postcode','city','member_number','privacy_consent'],reservation:['first_name','last_name','email','phone','event_date','participants','notes'],blank:[]};
function applyQuickTemplate(button){
 const name=button.dataset.formTemplate;
 const map=Object.fromEntries(library.map(x=>[x.key,x]));
 try{
  const wanted=quickFormTemplates[name]||[];
  const next=[];
  if(name!=='blank')wanted.forEach(k=>{if(!map[k])return;const f=defaultFieldConfig(clone(map[k]));f.key=String(f.key||k);f.options=Array.isArray(f.options)?f.options:[];next.push(f);});
  if(name!=='blank'&&!next.length)throw new Error('Quick template contains no available fields: '+name);
  selected.splice(0,selected.length,...next);
  selected.forEach((f,i)=>{defaultFieldConfig(f);f.config.layout={row:i+1,col:1,width:100};});
  openFieldKeys.clear();
  activeFieldKey=selected[0]?.key||null;
  if(activeFieldKey)openFieldKeys.add(activeFieldKey);
  sync();renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();renderAdditional();
  document.querySelectorAll('[data-form-template]').forEach(x=>x.classList.toggle('is-active',x===button));
  const quick=[...document.querySelectorAll('[data-accordion]')][1];
  quick?.classList.remove('is-open');quick?.querySelector('.df-section-toggle')?.setAttribute('aria-expanded','false');
  openBuilderSection(2,true);
 }catch(err){console.error('Forms quick template error',err);alert('Impossibile caricare il modello rapido. Ricarica la pagina e riprova.');}
}
document.addEventListener('click',e=>{const button=e.target.closest('[data-form-template]');if(!button)return;e.preventDefault();e.stopPropagation();applyQuickTemplate(button);});

/* Forms 1.3.17: reusable quick models saved from the current module structure. */
const savedQuickTemplateStorageKey='decaroforms_saved_quick_templates_v1';
function loadSavedQuickTemplates(){
 try{const parsed=JSON.parse(localStorage.getItem(savedQuickTemplateStorageKey)||'[]');return Array.isArray(parsed)?parsed:[];}
 catch(e){console.warn('Forms saved quick models could not be loaded',e);return [];}
}
function persistSavedQuickTemplates(){
 try{localStorage.setItem(savedQuickTemplateStorageKey,JSON.stringify(savedQuickTemplates));}
 catch(e){console.warn('Forms saved quick models could not be saved',e);}
}
let savedQuickTemplates=loadSavedQuickTemplates();
function renderSavedQuickTemplates(){
 const box=document.getElementById('df-saved-quick-templates'),heading=document.getElementById('df-saved-quick-heading');
 if(!box)return;
 box.innerHTML='';
 if(heading)heading.hidden=!savedQuickTemplates.length;
 savedQuickTemplates.forEach(tpl=>{
  const wrap=document.createElement('span');wrap.className='df-saved-quick-item';
  wrap.innerHTML=`<button type="button" class="df-saved-quick-use" data-saved-quick="${esc(tpl.id)}" title="Carica modello rapido">${esc(tpl.name)}</button><button type="button" class="df-saved-quick-delete df-icon-only" data-saved-quick-delete="${esc(tpl.id)}" title="Elimina modello salvato" aria-label="Elimina modello salvato">${modernUiIcon('trash')}</button>`;
  box.appendChild(wrap);
 });
}
function saveQuickTemplateNamed(name){
 const fields=clone(selected);
 const existing=savedQuickTemplates.find(x=>String(x.name).toLowerCase()===name.toLowerCase());
 const entry={id:existing?.id||('quick_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)),name,fields};
 const idx=savedQuickTemplates.findIndex(x=>x.id===entry.id);
 if(idx>=0)savedQuickTemplates[idx]=entry;else savedQuickTemplates.push(entry);
 persistSavedQuickTemplates();renderSavedQuickTemplates();
 const quick=[...document.querySelectorAll('[data-accordion]')][1];
 quick?.classList.add('is-open');quick?.querySelector('.df-section-toggle')?.setAttribute('aria-expanded','true');
 document.getElementById('df-saved-quick-heading')?.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function saveCurrentStructureAsQuickTemplate(){
 if(!selected.length){openActionModal({title:'Salva struttura',message:'Aggiungi almeno un campo prima di salvare la struttura.',confirmLabel:'Chiudi',onConfirm:()=>{}});return;}
 const suggested=(document.querySelector('[name="title"]')?.value||'Modello personalizzato').trim();
 openActionModal({title:'Salva struttura del modulo',message:'Salva questa struttura nei Modelli rapidi per riutilizzarla in altri moduli.',inputLabel:'Nome del modello',inputValue:suggested,inputRequired:true,confirmLabel:'Salva',onConfirm:saveQuickTemplateNamed});
}
function applySavedQuickTemplate(id,button){
 const tpl=savedQuickTemplates.find(x=>x.id===id);if(!tpl)return;
 const next=(Array.isArray(tpl.fields)?tpl.fields:[]).map(f=>defaultFieldConfig(clone(f)));
 selected.splice(0,selected.length,...next);
 activeFieldKey=selected[0]?.key||null;
 normalizeLayoutRows();renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();renderAdditional();sync();
 document.querySelectorAll('[data-form-template],.df-saved-quick-use').forEach(x=>x.classList.toggle('is-active',x===button));
 const quick=[...document.querySelectorAll('[data-accordion]')][1];
 quick?.classList.remove('is-open');quick?.querySelector('.df-section-toggle')?.setAttribute('aria-expanded','false');
 const fieldsSection=[...document.querySelectorAll('[data-accordion]')][2];
 fieldsSection?.classList.add('is-open');fieldsSection?.querySelector('.df-section-toggle')?.setAttribute('aria-expanded','true');
}
document.getElementById('df-save-structure')?.addEventListener('click',saveCurrentStructureAsQuickTemplate);
document.addEventListener('click',e=>{
 const use=e.target.closest('[data-saved-quick]');
 if(use){e.preventDefault();e.stopPropagation();applySavedQuickTemplate(use.dataset.savedQuick,use);return;}
 const del=e.target.closest('[data-saved-quick-delete]');
 if(del){e.preventDefault();e.stopPropagation();const tpl=savedQuickTemplates.find(x=>x.id===del.dataset.savedQuickDelete);confirmDelete(`il modello salvato “${tpl?.name||'Modello personalizzato'}”`,()=>{savedQuickTemplates=savedQuickTemplates.filter(x=>x.id!==del.dataset.savedQuickDelete);persistSavedQuickTemplates();renderSavedQuickTemplates();});}
});
renderSavedQuickTemplates();



// Accordion behavior.
const accordionSections=[...document.querySelectorAll('[data-accordion]')];accordionSections.forEach((section,index)=>{const btn=section.querySelector('.df-section-toggle');const setOpen=open=>{section.classList.toggle('is-open',open);btn?.setAttribute('aria-expanded',open?'true':'false');};setOpen(index===0);btn?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const open=!section.classList.contains('is-open');setOpen(open);});});

let activeLibraryCategory='personal';
function renderLibrary(){
 const tabs=document.getElementById('df-library-tabs');
 const q=(search.value||'').trim().toLowerCase();
 const counts=Object.fromEntries(categoryOrder.map(c=>[c,library.filter(x=>x.category===c).length]));
 tabs.innerHTML=`<button type="button" class="df-library-tab ${activeLibraryCategory==='all'?'is-active':''}" data-libcat="all">Tutti <span class="df-library-tab-count">${library.length}</span></button>`+categoryOrder.map(c=>`<button type="button" class="df-library-tab ${activeLibraryCategory===c?'is-active':''}" data-libcat="${c}">${esc(tr.cats[c]||c)} <span class="df-library-tab-count">${counts[c]||0}</span></button>`).join('');
 tabs.querySelectorAll('[data-libcat]').forEach(b=>b.onclick=()=>{activeLibraryCategory=b.dataset.libcat;renderLibrary();});
 const items=library.filter(x=>(q||activeLibraryCategory==='all'||x.category===activeLibraryCategory)&&(!q||`${x.label} ${x.key} ${x.type} ${tr.cats[x.category]||''}`.toLowerCase().includes(q)));
 lib.innerHTML='';
 if(!items.length){lib.innerHTML='<div class="df-library-empty">Nessun campo trovato.</div>';return;}
 const grid=document.createElement('div');grid.className='df-library-items-grid';
 items.forEach(x=>{const d=document.createElement('div');d.className='df-lib-item';const saved=!!x._savedPresetId;d.innerHTML=`<div><strong>${esc(x.label)}</strong><small>${esc(tr.cats[x.category]||x.category)} · ${esc(tr.types[x.type]||x.type)}${saved?' · Salvato':''}</small></div><div class="df-lib-actions"><button class="df-add" type="button">${esc(tr.add)}</button>${saved?`<button class="df-lib-delete df-icon-only" type="button" title="${esc(tr.remove)}" aria-label="${esc(tr.remove)}">${modernUiIcon('trash')}</button>`:''}</div>`;d.querySelector('.df-add').onclick=()=>add(x);d.querySelector('.df-lib-delete')?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();confirmDelete(`il campo personalizzato “${x.label||'Campo'}”`,()=>deleteSavedFieldPreset(x._savedPresetId));});grid.appendChild(d);});lib.appendChild(grid);
}
filter.innerHTML='';filter.hidden=true;search.addEventListener('input',renderLibrary);renderLibrary();

function fieldSelectOptions(current=''){return selected.map(f=>`<option value="${esc(f.key)}" ${f.key===current?'selected':''}>${esc(f.label)} (${esc(f.key)})</option>`).join('');}
function configHtml(x){const c=x.config||{},t=x.type;let h='';if(['select','multiselect','radio','checkboxes','city'].includes(t)){h+=`<div class="full"><label>${esc(tr.options)}</label><textarea class="df-options" data-k="options">${esc((x.options||[]).join('\n'))}</textarea><div class="df-note"><?php echo addslashes(Text::_('COM_DECAROFORMS_OPTIONS_COMPACT_NOTE')); ?></div></div>`;}
if(['file','upload'].includes(t)){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_UPLOAD_SETTINGS')); ?></strong><div class="df-config-grid"><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_FILE_TYPES')); ?></label><input data-cfg="accept" value="${esc(c.accept||'.pdf,.jpg,.jpeg,.png,.webp,.doc,.docx')}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_MAX_MB')); ?></label><input type="number" min="1" max="25" data-cfg="max_mb" value="${esc(c.max_mb||5)}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_MAX_FILES')); ?></label><input type="number" min="1" max="10" data-cfg="max_files" value="${esc(c.max_files||1)}"></div><div class="df-required"><input type="checkbox" data-cfg-check="multiple" ${c.multiple?'checked':''}><label><?php echo addslashes(Text::_('COM_DECAROFORMS_MULTIPLE_FILES')); ?></label></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_BUTTON_LABEL')); ?></label><input data-cfg="button_label" value="${esc(c.button_label||'')}"></div></div></div>`;}
if(t==='range'){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_RANGE_SETTINGS')); ?></strong><div class="df-config-grid"><div><label>Min</label><input type="number" data-cfg="min" value="${esc(c.min??0)}"></div><div><label>Max</label><input type="number" data-cfg="max" value="${esc(c.max??100)}"></div><div><label>Step</label><input type="number" data-cfg="step" value="${esc(c.step??1)}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_UNIT')); ?></label><input data-cfg="unit" value="${esc(c.unit||'')}"></div><div class="df-required"><input type="checkbox" data-cfg-check="dual" ${c.dual?'checked':''}><label><?php echo addslashes(Text::_('COM_DECAROFORMS_DUAL_RANGE')); ?></label></div></div></div>`;}
if(['separator','pagebreak'].includes(t)){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_LINE_SETTINGS')); ?></strong><div class="df-config-grid"><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_COLOR')); ?></label><input type="color" data-cfg="color" value="${esc(c.color||'#dfe3e7')}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_BORDER_WIDTH')); ?> (px)</label><input type="number" min="0" max="20" data-cfg="border_width" value="${esc(c.border_width??1)}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_BORDER_STYLE')); ?></label><select data-cfg="border_style"><option value="solid" ${c.border_style==='solid'||!c.border_style?'selected':''}>Continua</option><option value="dashed" ${c.border_style==='dashed'?'selected':''}>Tratteggiata</option><option value="dotted" ${c.border_style==='dotted'?'selected':''}>Puntinata</option><option value="double" ${c.border_style==='double'?'selected':''}>Doppia</option></select></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_LINE_LENGTH')); ?> %</label><input type="number" min="0" max="100" data-cfg="line_width" value="${esc(c.line_width??100)}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_MARGIN')); ?> px</label><input type="number" min="0" max="200" data-cfg="margin" value="${esc(c.margin??20)}"></div>${t==='pagebreak'?`<div class="df-required"><input type="checkbox" data-cfg-check="show_line" ${c.show_line!==false?'checked':''}><label><?php echo addslashes(Text::_('COM_DECAROFORMS_SHOW_LINE_FRONTEND')); ?></label></div>`:''}</div></div>`;}
if(t==='page'){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_MULTIPAGE_SETTINGS')); ?></strong><div class="df-config-grid"><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_PAGE_TITLE')); ?></label><input data-cfg="page_title" value="${esc(c.page_title||x.label)}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_PAGE_DESCRIPTION')); ?></label><input data-cfg="page_description" value="${esc(c.page_description||'')}"></div><div class="df-required"><input type="checkbox" data-cfg-check="show_progress" ${c.show_progress!==false?'checked':''}><label><?php echo addslashes(Text::_('COM_DECAROFORMS_SHOW_PROGRESS')); ?></label></div></div></div>`;}
if(t==='map'){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_MAP_SETTINGS')); ?></strong><div class="df-config-grid"><div><label>Lat</label><input data-cfg="lat" value="${esc(c.lat||'41.9028')}"></div><div><label>Lng</label><input data-cfg="lng" value="${esc(c.lng||'12.4964')}"></div><div><label>Zoom</label><input type="number" min="2" max="19" data-cfg="zoom" value="${esc(c.zoom||12)}"></div><div class="df-required"><input type="checkbox" data-cfg-check="use_location" ${c.use_location!==false?'checked':''}><label><?php echo addslashes(Text::_('COM_DECAROFORMS_ALLOW_GEOLOCATION')); ?></label></div></div></div>`;}
if(t==='payment'){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_PAYMENT_SETTINGS')); ?></strong><div class="df-config-grid"><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_PAYMENT_METHOD')); ?></label><select data-cfg="method"><option value="bank">Bonifico bancario</option><option disabled>Carta — <?php echo addslashes(Text::_('COM_DECAROFORMS_COMING_SOON')); ?></option><option disabled>PayPal — <?php echo addslashes(Text::_('COM_DECAROFORMS_COMING_SOON')); ?></option></select></div><div><label>IBAN</label><input data-cfg="iban" value="${esc(c.iban||'')}"></div><div><label>BIC / SWIFT</label><input data-cfg="bic" value="${esc(c.bic||'')}" placeholder="BCITITMM"></div><div><label>Paese banca</label><input data-cfg="bank_country" value="${esc(c.bank_country||'IT')}" placeholder="IT"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_ACCOUNT_HOLDER')); ?></label><input data-cfg="holder" value="${esc(c.holder||'')}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_AMOUNT')); ?></label><input data-cfg="amount" value="${esc(c.amount||'')}"></div><div class="full"><label><?php echo addslashes(Text::_('COM_DECAROFORMS_PAYMENT_CAUSE')); ?></label><input data-cfg="cause" value="${esc(c.cause||'{last_name} {first_name} - {riferimento}')}"><div class="df-note">{first_name} {last_name} {email} {riferimento} {data} {anno}</div></div></div></div>`;}
if(t==='calculated'){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_CALC_SETTINGS')); ?></strong><div class="df-config-grid"><div class="full"><label><?php echo addslashes(Text::_('COM_DECAROFORMS_FORMULA')); ?></label><input data-cfg="formula" value="${esc(c.formula||'')}"><div class="df-note">Esempio: {participants} * 25</div></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_PREFIX')); ?></label><input data-cfg="prefix" value="${esc(c.prefix||'')}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_SUFFIX')); ?></label><input data-cfg="suffix" value="${esc(c.suffix||'')}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_DECIMALS')); ?></label><input type="number" min="0" max="6" data-cfg="decimals" value="${esc(c.decimals??2)}"></div><div class="df-required"><input type="checkbox" data-cfg-check="visible" ${c.visible!==false?'checked':''}><label><?php echo addslashes(Text::_('COM_DECAROFORMS_VISIBLE_FIELD')); ?></label></div></div></div>`;}
if(['heading','info','fieldset'].includes(t)){h+=`<div class="df-config-panel"><strong><?php echo addslashes(Text::_('COM_DECAROFORMS_CONTENT')); ?></strong><textarea class="df-options" data-cfg="content">${esc(c.content||'')}</textarea></div>`;}
if(t==='province'){h+=`<div class="df-config-panel"><label>Formato provincia</label><select data-cfg="display_format"><option value="name_code" ${c.display_format==='name_code'||!c.display_format?'selected':''}>Nome e sigla — Roma (RM)</option><option value="name" ${c.display_format==='name'?'selected':''}>Solo nome — Roma</option><option value="code" ${c.display_format==='code'?'selected':''}>Solo sigla — RM</option></select></div>`;}
if(t==='tax_code'){const linkNames=[['first_name','Nome'],['last_name','Cognome'],['birth_date','Data di nascita'],['gender','Sesso'],['birth_city','Comune di nascita'],['birth_country','Stato estero'],['birth_province','Provincia di nascita']];c.links=c.links||{};const opts=(role,current)=>`<option value="">Campo non collegato — Aggiungi campo</option>`+selected.filter(f=>f.key!==x.key).map(f=>`<option value="${esc(f.key)}" ${current===f.key?'selected':''}>${esc(f.label)} (${esc(f.key)})</option>`).join('');h+=`<details class="df-tax-links"><summary>Verifica codice fiscale</summary><div class="df-tax-links-body"><p class="df-note">Collega i dati già presenti per verificare la coerenza. Il codice resta quello dichiarato dall’utente.</p>${linkNames.map(([role,label])=>`<div class="df-field"><label>${label}</label><select data-tax-link="${role}">${opts(role,c.links[role]||'')}</select></div>`).join('')}<div class="df-tax-conflict" hidden></div></div></details>`;}
if(t==='member_number'){h+=`<div class="df-config-panel"><div class="df-config-grid"><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_MIN_LENGTH')); ?></label><input type="number" data-cfg="min_length" value="${esc(c.min_length||1)}"></div><div><label><?php echo addslashes(Text::_('COM_DECAROFORMS_MAX_LENGTH')); ?></label><input type="number" data-cfg="max_length" value="${esc(c.max_length||20)}"></div></div><div class="df-note"><?php echo addslashes(Text::_('COM_DECAROFORMS_NUMERIC_ID_NOTE')); ?></div></div>`;}
if(t==='postcode'){h+=`<div class="df-config-panel"><div class="df-note"><?php echo addslashes(Text::_('COM_DECAROFORMS_POSTCODE_ITALY_NOTE')); ?></div></div>`;}
return h;}
function renderConditions(x,i){const c=x.config||{},rules=Array.isArray(c.conditions)?c.conditions:[];const rows=rules.map((r,ri)=>`<div class="df-condition-row"><select data-cond-field="${ri}"><option value="">— Campo —</option>${fieldSelectOptions(r.field||'')}</select><select data-cond-op="${ri}">${[['eq','='],['neq','≠'],['contains','contiene'],['not_contains','non contiene'],['empty','vuoto'],['not_empty','non vuoto'],['gt','>'],['lt','<'],['checked','selezionato'],['not_checked','non selezionato']].map(([v,l])=>`<option value="${v}" ${r.operator===v?'selected':''}>${l}</option>`).join('')}</select><input data-cond-value="${ri}" value="${esc(r.value||'')}" placeholder="Valore"><button type="button" data-cond-remove="${ri}">${modernUiIcon('trash')}<span>Elimina condizione</span></button></div>`).join('');return `<details class="df-condition-details"><summary>${esc(tr.conditions)} <span class="df-note">${rules.length?rules.length+' regola'+(rules.length===1?'':'e'):''}</span></summary><div class="df-condition-body"><p class="df-note">Mostra, nascondi o rendi obbligatorio questo campo in base ad altri valori.</p><div class="df-condition-controls"><div><label>Azione</label><select data-cfg="condition_action"><option value="show" ${c.condition_action==='show'?'selected':''}>Mostra</option><option value="hide" ${c.condition_action==='hide'?'selected':''}>Nascondi</option><option value="require" ${c.condition_action==='require'?'selected':''}>Rendi obbligatorio</option><option value="disable" ${c.condition_action==='disable'?'selected':''}>Disabilita</option></select></div><div><label>Applica le condizioni</label><select data-cfg="condition_logic"><option value="all" ${c.condition_logic!=='any'?'selected':''}>${esc(tr.all)}</option><option value="any" ${c.condition_logic==='any'?'selected':''}>${esc(tr.any)}</option></select></div></div><div class="df-condition-list">${rows||`<div class="df-note">Nessuna condizione configurata.</div>`}</div><button class="df-btn df-small" type="button" data-add-condition>+ ${esc(tr.addCondition)}</button></div></details>`;}

let activeStructureSelection=null;
function newRowId(){try{if(globalThis.crypto?.randomUUID)return 'row_'+globalThis.crypto.randomUUID();}catch(e){}return 'row_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,10);}
function rowMetaStore(){builderConfig=builderConfig&&typeof builderConfig==='object'?builderConfig:{};builderConfig.layout=builderConfig.layout&&typeof builderConfig.layout==='object'?builderConfig.layout:{};builderConfig.layout.row_meta=builderConfig.layout.row_meta&&typeof builderConfig.layout.row_meta==='object'?builderConfig.layout.row_meta:{};return builderConfig.layout.row_meta;}
function rowLabelSeq(){builderConfig=builderConfig&&typeof builderConfig==='object'?builderConfig:{};builderConfig.layout=builderConfig.layout&&typeof builderConfig.layout==='object'?builderConfig.layout:{};return Math.max(0,Math.floor(Number(builderConfig.layout.row_label_seq)||0));}
function rowBumpLabelSeq(value){const n=Math.max(0,Math.floor(Number(value)||0));if(n>rowLabelSeq())builderConfig.layout.row_label_seq=n;return n;}
function nextRowDisplayNo(){const store=rowMetaStore();let seq=rowLabelSeq();Object.values(store).forEach(meta=>{const n=Math.floor(Number(meta?.display_no)||0);if(n>seq)seq=n;});seq+=1;builderConfig.layout.row_label_seq=seq;return seq;}
function ensureRowDisplayNo(meta,rowNo,legacyPreferred=false){meta=meta&&typeof meta==='object'?meta:{};let n=Math.floor(Number(meta.display_no)||0);if(n>0){rowBumpLabelSeq(n);return n;}if(legacyPreferred){n=Math.max(1,Math.floor(Number(rowNo)||1));rowBumpLabelSeq(n);}else n=nextRowDisplayNo();meta.display_no=n;return n;}
function rowMeta(rowNo){rowNo=Math.max(1,Number(rowNo)||1);const store=rowMetaStore(),key=String(rowNo),meta=store[key]&&typeof store[key]==='object'?store[key]:{};if(!meta.id)meta.id=newRowId();if(typeof meta.title!=='string')meta.title='';if(typeof meta.description!=='string')meta.description='';const legacy=Number(builderConfig?.layout?.row_label_version||0)<1;ensureRowDisplayNo(meta,rowNo,legacy);store[key]=meta;return meta;}
function rowAutoLabel(rowNo){const meta=rowMeta(rowNo),displayNo=ensureRowDisplayNo(meta,rowNo,false);return `${structureUi.row} ${displayNo}`;}
function rowDisplayTitle(rowNo){const meta=rowMeta(rowNo);return meta.title||rowAutoLabel(rowNo);}
function rowIdForRow(rowNo){return String(rowMeta(rowNo).id||'');}
function rowNoForId(id){id=String(id||'');if(!id)return 0;const store=rowMetaStore();for(const [k,meta] of Object.entries(store)){if(meta&&String(meta.id||'')===id){const n=Number(k);if(Number.isFinite(n)&&n>0)return n;}}return 0;}
function logicalRowNumbers(){const fieldRows=selected.map(f=>Number(f.config?.layout?.row||1)).filter(n=>Number.isFinite(n)&&n>0),metaRows=Object.keys(rowMetaStore()).map(Number).filter(n=>Number.isFinite(n)&&n>0);return [...new Set([...fieldRows,...metaRows])].sort((a,b)=>a-b);}
function refreshActiveRowSelection(){if(activeStructureSelection?.type!=='row')return;if(activeStructureSelection.id){const n=rowNoForId(activeStructureSelection.id);if(n){activeStructureSelection.row=n;return;}activeStructureSelection=null;return;}const n=Math.max(1,Number(activeStructureSelection.row)||1);activeStructureSelection.id=rowIdForRow(n);activeStructureSelection.row=n;}
function renderSectionSettings(x,i){defaultFieldConfig(x);sel.innerHTML='';const d=document.createElement('div');d.className='df-selected-item is-open df-structure-settings';d.innerHTML=`<div class="df-selected-top"><div class="df-field-toggle-main"><strong>${esc(structureUi.sectionSettings)}</strong><span class="df-field-summary"><span class="df-summary-chip">${esc(structureUi.section)}</span></span></div><div class="df-mini-actions"><button type="button" data-structure-remove class="df-icon-only" title="${esc(tr.remove)}" aria-label="${esc(tr.remove)}">${modernUiIcon('trash')}</button></div></div><div class="df-selected-config-wrap"><div class="df-selected-config-inner"><div class="df-selected-config"><details class="full df-main-settings" open><summary>${esc(structureUi.sectionSettings)}</summary><div class="df-main-settings-body"><div class="df-main-settings-grid"><div class="full"><label>${esc(structureUi.title)}</label><input data-section-title value="${esc(x.label||'')}"></div><div class="full"><label>${esc(structureUi.description)}</label><textarea class="df-options" data-section-description>${esc(x.config?.content||'')}</textarea></div></div></div></details></div></div></div>`;d.querySelector('[data-section-title]').oninput=e=>{x.label=e.target.value;sync();renderLayoutCanvas();};d.querySelector('[data-section-description]').oninput=e=>{x.config.content=e.target.value;sync();renderLayoutCanvas();};d.querySelector('[data-structure-remove]').onclick=()=>confirmDelete(`la sezione “${x.label||structureUi.section}”`,()=>removeCanvasField(i));sel.appendChild(d);sync();}
function duplicateLayoutRow(rowNo){rowNo=Math.max(1,Number(rowNo)||1);const items=fieldsInRow(rowNo).map(([f])=>f),originalMeta=clone(rowMeta(rowNo)),insertRow=rowNo+1;smartShiftRowMeta(insertRow);selected.forEach(f=>{defaultFieldConfig(f);if(Number(f.config.layout.row||1)>=insertRow)f.config.layout.row=Number(f.config.layout.row)+1;});const copies=items.map((f,i)=>{const c=clone(f);c.key=uniqueKey(c.key);defaultFieldConfig(c);c.config.layout={...(c.config.layout||{}),row:insertRow,col:i+1,width:Number(f.config?.layout?.width||100)};return c;});selected.push(...copies);const copyMeta={...originalMeta,id:newRowId(),title:originalMeta.title?`${originalMeta.title} copia`:'',description:originalMeta.description||''};rowMetaStore()[String(insertRow)]=copyMeta;normalizeLayoutRows();sortSelectedByLayout();const newRow=rowNoForId(copyMeta.id)||insertRow;if(copies.length)smartFitRow(newRow);activeFieldKey=copies[0]?.key||activeFieldKey;activeStructureSelection={type:'row',id:copyMeta.id,row:newRow};layoutRowState.set(copyMeta.id,layoutRowState.get(originalMeta.id)??false);renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();sync();clearTimeout(historyTimer);pushHistory();}
function requestRemoveLayoutRow(rowNo){rowNo=Math.max(1,Number(rowNo)||1);const items=fieldsInRow(rowNo).map(([f])=>f),count=items.length,meta=rowMeta(rowNo),title=rowDisplayTitle(rowNo),rowId=meta.id;confirmDelete(`la riga “${title}” con ${count} camp${count===1?'o':'i'}`,()=>{const refs=new Set(items);for(let i=selected.length-1;i>=0;i--){if(refs.has(selected[i]))selected.splice(i,1);}if(builderConfig?.layout?.row_meta)delete builderConfig.layout.row_meta[String(rowNo)];layoutRowState.delete(rowId);activeStructureSelection=null;activeFieldKey=selected[0]?.key||null;normalizeLayoutRows();repairInvalidRows();renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();renderAdditional();sync();clearTimeout(historyTimer);pushHistory();});}
function renderRowSettings(rowNo){const meta=rowMeta(rowNo);sel.innerHTML='';const d=document.createElement('div');d.className='df-selected-item is-open df-structure-settings';d.innerHTML=`<div class="df-selected-top"><div class="df-field-toggle-main"><strong>${esc(structureUi.rowSettings)}</strong><span class="df-field-summary"><span class="df-summary-chip">${esc(rowAutoLabel(rowNo))}</span></span></div><div class="df-mini-actions"><button type="button" data-row-copy class="df-icon-only" title="Duplica riga" aria-label="Duplica riga">${modernUiIcon('copy')}</button><button type="button" data-row-remove class="df-icon-only df-row-remove" title="Elimina riga" aria-label="Elimina riga">${modernUiIcon('trash')}</button></div></div><div class="df-selected-config-wrap"><div class="df-selected-config-inner"><div class="df-selected-config"><details class="full df-main-settings" open><summary>${esc(structureUi.rowSettings)}</summary><div class="df-main-settings-body"><div class="df-main-settings-grid"><div class="full"><label>${esc(structureUi.title)}</label><input data-row-title value="${esc(meta.title||'')}" placeholder="${esc(rowAutoLabel(rowNo))}"></div><div class="full"><label>${esc(structureUi.description)}</label><textarea class="df-options" data-row-description>${esc(meta.description||'')}</textarea></div><div class="full df-note">Titolo e descrizione della riga servono per organizzare più velocemente il Builder e non vengono inviati come dati del modulo.</div></div></div></details></div></div></div>`;d.querySelector('[data-row-title]').oninput=e=>{meta.title=e.target.value;sync();renderLayoutCanvas();};d.querySelector('[data-row-description]').oninput=e=>{meta.description=e.target.value;sync();renderLayoutCanvas();};d.querySelector('[data-row-copy]').onclick=()=>duplicateLayoutRow(rowNo);d.querySelector('[data-row-remove]').onclick=()=>requestRemoveLayoutRow(rowNo);sel.appendChild(d);sync();}
function selectRowSettings(rowNo){rowNo=Math.max(1,Number(rowNo)||1);activeFieldKey=null;activeStructureSelection={type:'row',id:rowIdForRow(rowNo),row:rowNo};renderSelected();renderLayoutCanvas();}

function renderSelected(){sel.innerHTML='';if(activeStructureSelection?.type==='row'){refreshActiveRowSelection();if(activeStructureSelection?.type==='row'){renderRowSettings(activeStructureSelection.row);return;}}if(!selected.length){activeFieldKey=null;openFieldKeys.clear();sel.innerHTML='<div class="df-selected-empty">Seleziona o aggiungi un campo per modificarne le impostazioni.</div>';sync();renderLayoutCanvas();return;}if(!selected.some(x=>x.key===activeFieldKey))activeFieldKey=selected[0].key;const activeIndex=selected.findIndex(x=>x.key===activeFieldKey),activeItem=selected[activeIndex];if(activeItem&&isLayoutSectionField(activeItem)){renderSectionSettings(activeItem,activeIndex);return;}openFieldKeys.clear();openFieldKeys.add(activeFieldKey);selected.map((x,i)=>[x,i]).filter(([x])=>x.key===activeFieldKey).forEach(([x,i])=>{defaultFieldConfig(x);const d=document.createElement('div');d.className='df-selected-item is-open';const req=x.required?'<span class="df-summary-chip df-required-badge">Obbligatorio</span>':'';d.innerHTML=`<div class="df-selected-top"><button type="button" class="df-field-toggle" data-field-toggle><span class="df-field-chevron">⌄</span><span class="df-field-toggle-main"><strong>${i+1}. ${esc(x.label)}</strong><span class="df-field-summary"><span class="df-summary-chip">${esc(tr.types[x.type]||x.type)}</span>${req}<span class="df-summary-chip">${esc(x.config.layout.width||100)}%</span></span></span></button><div class="df-mini-actions"><button type="button" data-act="save-preset" class="df-save-preset" title="Salva come campo personalizzato" aria-label="Salva come campo personalizzato"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 3h11l3 3v15H5V3zm2 2v5h9V5H7zm0 14h10v-6H7v6z" fill="currentColor"/></svg></button><button type="button" data-act="up" title="${esc(tr.moveUp)}">↑</button><button type="button" data-act="down" title="${esc(tr.moveDown)}">↓</button><button type="button" data-act="remove" class="df-icon-only" title="${esc(tr.remove)}" aria-label="${esc(tr.remove)}">${modernUiIcon('trash')}</button></div></div><div class="df-selected-config-wrap"><div class="df-selected-config-inner"><div class="df-selected-config"><details class="full df-main-settings" open><summary>Impostazioni principali</summary><div class="df-main-settings-body"><div class="df-main-settings-grid"><div><label>${esc(tr.label)}</label><input data-k="label" value="${esc(x.label)}"></div><div><label>${esc(tr.key)}</label><input data-k="key" value="${esc(x.key)}"></div><div><label>${esc(tr.type)}</label><select data-k="type">${types.map(t=>`<option value="${t}" ${x.type===t?'selected':''}>${esc(tr.types[t]||t)}</option>`).join('')}</select></div><div><label>${esc(tr.placeholder)}</label><input data-k="placeholder" value="${esc(x.placeholder||'')}"></div><div><label>${esc(tr.default)}</label><input data-k="default" value="${esc(x.default||'')}"></div><div><label>${esc(tr.help)}</label><input data-k="help" value="${esc(x.help||'')}"></div></div></div></details><details class="full df-layout-settings"><summary>Layout e larghezza</summary><div class="df-layout-settings-body"><div class="df-required"><input type="checkbox" data-k-check="required" ${x.required?'checked':''}><label>${esc(tr.required)}</label></div><div class="df-field-width-block"><label>Larghezza</label><div class="df-field-width-pills">${[100,75,66,60,50,40,33,25].map(w=>`<button type="button" data-field-width="${w}" class="${Number(x.config.layout.width||100)===w?'is-active':''}">${w}%</button>`).join('')}</div></div></div></details>${configHtml(x)}${renderConditions(x,i)}</div></div></div>`;
 d.querySelector('[data-field-toggle]').onclick=()=>{};d.querySelectorAll('[data-field-width]').forEach(btn=>btn.onclick=()=>{setFieldWidth(i,Number(btn.dataset.fieldWidth));});
 d.querySelectorAll('[data-k]').forEach(el=>el.addEventListener('input',()=>{const k=el.dataset.k;if(k==='options')x.options=el.value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean);else{if(k==='key'){const old=x.key,next=uniqueKey(el.value,old);x.key=next;el.value=next;openFieldKeys.delete(old);openFieldKeys.add(next);activeFieldKey=next;}else x[k]=el.value;}sync();if(k==='label'||k==='key'){renderColumns();renderTokens();renderUserEmailFields();renderAdditional();renderLayoutCanvas();}if(k==='type'){renderSelected();renderColumns();renderUserEmailFields();}}));
 d.querySelectorAll('[data-k-check]').forEach(el=>el.addEventListener('change',()=>{x[el.dataset.kCheck]=el.checked;sync();renderSelected();renderLayoutCanvas();}));
 d.querySelectorAll('[data-cfg]').forEach(el=>{const ev=el.tagName==='SELECT'?'change':'input';el.addEventListener(ev,()=>{setDeep(x.config,el.dataset.cfg,el.type==='number'?Number(el.value):el.value);sync();if(el.dataset.cfg.startsWith('layout.'))renderLayoutCanvas();});});
 d.querySelectorAll('[data-cfg-check]').forEach(el=>el.addEventListener('change',()=>{setDeep(x.config,el.dataset.cfgCheck,el.checked);sync();})); d.querySelectorAll('[data-tax-link]').forEach(el=>el.addEventListener('change',()=>{x.config.links=x.config.links||{};x.config.links[el.dataset.taxLink]=el.value;sync();}));const labelCounts=selected.reduce((m,f)=>{const k=String(f.label||'').trim().toLocaleLowerCase();if(k)m[k]=(m[k]||0)+1;return m;},{}),hasDuplicateLabels=Object.values(labelCounts).some(n=>n>1);const conflict=d.querySelector('.df-tax-conflict');if(conflict&&hasDuplicateLabels){conflict.hidden=false;conflict.className='df-status-warning';conflict.textContent='Attenzione: esistono campi con lo stesso nome. Usa la chiave mostrata tra parentesi per scegliere quello corretto.';}
 d.querySelector('[data-act="save-preset"]').onclick=e=>{e.preventDefault();e.stopPropagation();const btn=e.currentTarget;openActionModal({title:'Salva campo personalizzato',message:`Salvare “${x.label||'Campo'}” nella Libreria campi → Personalizzati?`,confirmLabel:'Salva',onConfirm:()=>{saveFieldPreset(x);btn.classList.add('is-saved');btn.title='Salvato nei campi personalizzati';setTimeout(()=>{btn.classList.remove('is-saved');btn.title='Salva come campo personalizzato';},1200);}});}; d.querySelector('[data-act="up"]').onclick=()=>{if(i>0){[selected[i-1],selected[i]]=[selected[i],selected[i-1]];renderSelected();renderLayoutCanvas();}};d.querySelector('[data-act="down"]').onclick=()=>{if(i<selected.length-1){[selected[i+1],selected[i]]=[selected[i],selected[i+1]];renderSelected();renderLayoutCanvas();}};d.querySelector('[data-act="remove"]').onclick=()=>confirmDelete(`il campo “${x.label||'Campo'}”`,()=>{const removedRow=Number(x.config.layout.row||1);openFieldKeys.delete(x.key);selected.splice(i,1);activeFieldKey=selected[Math.min(i,selected.length-1)]?.key||null;normalizeLayoutRows();distributeRow(removedRow);renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();renderAdditional();sync();});
 d.querySelector('[data-add-condition]')?.addEventListener('click',e=>{e.preventDefault();x.config.conditions.push({field:'',operator:'eq',value:''});renderSelected();setTimeout(()=>{const items=sel.querySelectorAll('.df-selected-item');items[i]?.querySelector('.df-condition-details')?.setAttribute('open','');},0);});d.querySelectorAll('[data-cond-field]').forEach(el=>el.addEventListener('change',()=>{x.config.conditions[Number(el.dataset.condField)].field=el.value;sync();}));d.querySelectorAll('[data-cond-op]').forEach(el=>el.addEventListener('change',()=>{x.config.conditions[Number(el.dataset.condOp)].operator=el.value;sync();}));d.querySelectorAll('[data-cond-value]').forEach(el=>el.addEventListener('input',()=>{x.config.conditions[Number(el.dataset.condValue)].value=el.value;sync();}));d.querySelectorAll('[data-cond-remove]').forEach(el=>el.addEventListener('click',()=>confirmDelete('questa condizione',()=>{x.config.conditions.splice(Number(el.dataset.condRemove),1);renderSelected();sync();})));sel.appendChild(d);});sync();}

// Layout.
const layoutColumns=document.getElementById('df-layout-columns'),layoutWidths=document.getElementById('df-layout-widths'),layoutTotal=document.getElementById('df-layout-total'),mobileStack=document.getElementById('df-layout-mobile-stack'),layoutCanvas=document.getElementById('df-layout-canvas'),layoutNewRow=document.getElementById('df-layout-newrow');
let draggedFieldIndex=null;
function normalizeLayoutRows(){
 builderConfig=builderConfig&&typeof builderConfig==='object'?builderConfig:{};builderConfig.layout=builderConfig.layout&&typeof builderConfig.layout==='object'?builderConfig.layout:{};
 const oldMeta=rowMetaStore(),rows=logicalRowNumbers(),legacyLabels=Number(builderConfig.layout.row_label_version||0)<1;
 let seq=rowLabelSeq();Object.values(oldMeta).forEach(meta=>{const n=Math.floor(Number(meta?.display_no)||0);if(n>seq)seq=n;});
 if(!rows.length){builderConfig.layout.row_meta={};builderConfig.layout.row_label_seq=seq;builderConfig.layout.row_label_version=1;activeStructureSelection=null;return;}
 const map=new Map(rows.map((r,i)=>[r,i+1])),nextMeta={},usedDisplayNos=new Set();
 rows.forEach(r=>{
  const nr=map.get(r),existing=oldMeta[String(r)]&&typeof oldMeta[String(r)]==='object'?oldMeta[String(r)]:null,meta=existing||{};
  if(!meta.id)meta.id=newRowId();if(typeof meta.title!=='string')meta.title='';if(typeof meta.description!=='string')meta.description='';
  let displayNo=Math.floor(Number(meta.display_no)||0);
  if(displayNo<=0){if(legacyLabels)displayNo=Math.max(1,Math.floor(Number(r)||1));else{seq+=1;displayNo=seq;}}
  if(usedDisplayNos.has(displayNo)){do{seq+=1;}while(usedDisplayNos.has(seq));displayNo=seq;}
  usedDisplayNos.add(displayNo);seq=Math.max(seq,displayNo);meta.display_no=displayNo;nextMeta[String(nr)]=meta;
 });
 builderConfig.layout.row_meta=nextMeta;builderConfig.layout.row_label_seq=seq;builderConfig.layout.row_label_version=1;
 selected.forEach(f=>{defaultFieldConfig(f);f.config.layout.row=map.get(Number(f.config.layout.row||1))||1;});
 for(const row of logicalRowNumbers()){selected.filter(f=>Number(f.config.layout.row||1)===Number(row)).sort((a,b)=>(a.config.layout.col||1)-(b.config.layout.col||1)).forEach((f,i)=>f.config.layout.col=i+1);normalizeVisualLines(row);}
 refreshActiveRowSelection();const validIds=new Set(Object.values(builderConfig.layout.row_meta||{}).map(meta=>String(meta?.id||'')).filter(Boolean));for(const id of [...layoutRowState.keys()])if(!validIds.has(String(id)))layoutRowState.delete(id);
}
function sortSelectedByLayout(){selected.sort((a,b)=>Number(a.config?.layout?.row||1)-Number(b.config?.layout?.row||1)||Number(a.config?.layout?.col||1)-Number(b.config?.layout?.col||1));}
function widthChoices(current){const vals=[100,75,66,60,50,40,33,25];if(!vals.includes(Number(current)))vals.push(Number(current)||100);return vals.map(v=>`<option value="${v}" ${Number(current)===v?'selected':''}>${v}%</option>`).join('');}
function setFieldWidth(index,width){if(index==null||!selected[index])return;const field=selected[index],row=Number(field.config.layout.row||1),line=visualLineForField(field),members=line.map(([f])=>f);width=Math.max(10,Math.min(100,Number(width)||100));if(members.length<=1){const wasRight=smartOffsetBefore(field)>0;field.config.layout.width=width;if(width>=100){smartClearOffsets(field);field.config.layout.width=100;}else if(wasRight){field.config.layout.offset_before=100-width;delete field.config.layout.offset_after;}else{field.config.layout.offset_after=100-width;delete field.config.layout.offset_before;}}else if(width===100){members.forEach(f=>{smartClearOffsets(f);f.config.layout.width=100;});}else{members.forEach(f=>smartClearOffsets(f));field.config.layout.width=width;const others=members.filter(f=>f!==field),remaining=100-width,base=Math.floor(remaining/Math.max(1,others.length)),extra=remaining-base*Math.max(1,others.length);others.forEach((f,i)=>f.config.layout.width=Math.max(1,base+(i<extra?1:0)));}normalizeVisualLines(row);sync();renderSelected();renderLayoutCanvas();}
function selectField(index){if(index==null||!selected[index])return;activeStructureSelection=null;activeFieldKey=selected[index].key;openFieldKeys.clear();openFieldKeys.add(activeFieldKey);renderSelected();renderLayoutCanvas();}
function duplicateField(index){if(index==null||!selected[index])return;const copy=clone(selected[index]);copy.key=uniqueKey(copy.key);copy.label=`${copy.label} copia`;defaultFieldConfig(copy);selected.splice(index+1,0,copy);activeFieldKey=copy.key;openFieldKeys.clear();openFieldKeys.add(copy.key);normalizeLayoutRows();smartFitRow(copy.config.layout.row);renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();sync();}
function removeCanvasField(index){if(index==null||!selected[index])return;const field=selected[index],old=field.key,oldRow=Number(field.config.layout.row||1),wasSection=isLayoutSectionField(field),line=visualLineForField(field),rest=line.map(([f])=>f).filter(f=>f!==field);if(rest.length){const auto=smartAutoWidths(rest.length);rest.forEach((f,i)=>{smartClearOffsets(f);f.config.layout.width=auto[i]??100;});}selected.splice(index,1);if(wasSection&&builderConfig?.layout?.row_meta)delete builderConfig.layout.row_meta[String(oldRow)];openFieldKeys.delete(old);activeFieldKey=selected[Math.min(index,selected.length-1)]?.key||null;normalizeLayoutRows();if(selected.some(f=>Number(f.config?.layout?.row||1)===oldRow))normalizeVisualLines(oldRow);renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();renderAdditional();sync();}
function moveFieldToRow(index,row,targetIndex=null){if(index==null||!selected[index])return;const field=selected[index],oldRow=Number(field.config.layout.row||1),sourceLine=visualLineForField(field),sourceRest=sourceLine.map(([f])=>f).filter(f=>f!==field);if(sourceRest.length){const auto=smartAutoWidths(sourceRest.length);sourceRest.forEach((f,i)=>{smartClearOffsets(f);f.config.layout.width=auto[i]??100;});}selected.splice(index,1);row=Math.max(1,Number(row)||1);const targetItems=fieldsInRow(row).map(([f])=>f).filter(f=>f!==field);field.config.layout={...(field.config.layout||{}),row,col:targetItems.length+1,width:100};targetItems.push(field);setLogicalRowOrder(row,targetItems);selected.push(field);normalizeLayoutRows();sortSelectedByLayout();if(selected.some(f=>Number(f.config?.layout?.row||1)===oldRow))normalizeVisualLines(oldRow);normalizeVisualLines(Number(field.config.layout.row||row));activeFieldKey=field.key;sync();renderSelected();renderLayoutCanvas();}
function moveFieldBeside(index,targetIndex,position='after'){if(smartMoveBeside(index,targetIndex,position)){sortSelectedByLayout();sync();renderSelected();renderLayoutCanvas();}}
function moveFieldToNewRowAfter(index,afterRow){if(index==null||!selected[index])return;if(smartMoveNewRow(index,Number(afterRow),'after')){sortSelectedByLayout();sync();renderSelected();renderLayoutCanvas();}}

/* Forms 1.3.67: intelligent field drag & drop. No external dependency. */
const smartDrag={pending:null,active:false,pointerId:null,pointerType:'',fieldKey:'',sourceCard:null,sourceRow:null,ghost:null,spec:null,specKey:'',pressTimer:null,lastX:0,lastY:0,originX:0,originY:0,grabXRatio:.5,grabYRatio:.5,sourceWidth:0,sourceHeight:0,intentAxis:'',intentLockX:0,intentLockY:0,raf:0,queuedX:0,queuedY:0,ghostWidth:0,ghostHeight:0};
let smartSuppressClickUntil=0;
const smartDragIgnoreSelector='button,select,input,textarea,a,label,[contenteditable="true"],summary,details';
function smartFieldIndex(key){return selected.findIndex(f=>f.key===key);}
function smartFieldByKey(key){const i=smartFieldIndex(key);return i>=0?selected[i]:null;}
function smartSpecId(spec){return spec?`${spec.kind}:${spec.targetKey||''}:${spec.row||''}:${spec.position||''}:${spec.slot?'slot':''}`:'';}
function smartCaptureRects(){const map=new Map();layoutCanvas?.querySelectorAll('.df-layout-card:not(.df-smart-source-hidden)').forEach(el=>{const r=el.getBoundingClientRect();if(r.width&&r.height)map.set(el.dataset.fieldKey,{left:r.left,top:r.top});});return map;}
function smartAnimateFrom(before){if(!before?.size)return;requestAnimationFrame(()=>{layoutCanvas?.querySelectorAll('.df-layout-card:not(.df-smart-source-hidden)').forEach(el=>{const b=before.get(el.dataset.fieldKey);if(!b||!el.animate)return;const r=el.getBoundingClientRect(),dx=b.left-r.left,dy=b.top-r.top;if(Math.abs(dx)<1&&Math.abs(dy)<1)return;el.animate([{transform:`translate(${dx}px,${dy}px)`},{transform:'translate(0,0)'}],{duration:125,easing:'cubic-bezier(.2,.82,.25,1)'});});});}
function smartRememberGrid(row){if(row&&!row.hasAttribute('data-smart-original-grid'))row.setAttribute('data-smart-original-grid',row.style.gridTemplateColumns||'');}
function smartSetGrid(row,widths){if(!row)return;smartRememberGrid(row);const vals=(Array.isArray(widths)&&widths.length?widths:[100]);row.style.gridTemplateColumns=vals.map(v=>`${Math.max(1,Number(v)||1)}fr`).join(' ');}
function smartRestorePreviewDom(){
 document.querySelectorAll('.df-smart-drop-overlay').forEach(el=>el.remove());
 layoutCanvas?.querySelectorAll('.df-smart-placeholder,.df-smart-newrow-preview,.df-smart-row-join-preview,.df-smart-line-preview,.df-smart-slot-preview').forEach(el=>el.remove());
 layoutCanvas?.querySelectorAll('.df-smart-target-left,.df-smart-target-right,.df-smart-row-target-before,.df-smart-row-target-after,.df-smart-row-join-target,.df-smart-line-target-before,.df-smart-line-target-after').forEach(el=>el.classList.remove('df-smart-target-left','df-smart-target-right','df-smart-row-target-before','df-smart-row-target-after','df-smart-row-join-target','df-smart-line-target-before','df-smart-line-target-after'));
 layoutCanvas?.querySelectorAll('.df-layout-row[data-smart-original-grid]').forEach(row=>{row.style.gridTemplateColumns=row.getAttribute('data-smart-original-grid')||'';row.removeAttribute('data-smart-original-grid');});
 layoutCanvas?.querySelectorAll('.df-smart-source-row-empty').forEach(el=>el.classList.remove('df-smart-source-row-empty'));
 layoutCanvas?.querySelectorAll('.df-smart-source-line-empty').forEach(el=>el.classList.remove('df-smart-source-line-empty'));
}
function smartReflowSourceRow(){const row=smartDrag.sourceRow;if(!row?.isConnected)return;const visible=[...row.querySelectorAll('.df-layout-card:not(.df-smart-source-hidden)')],group=row.closest('.df-layout-row-group');group?.classList.remove('df-smart-source-row-empty');if(!visible.length){smartRememberGrid(row);row.classList.add('df-smart-source-line-empty');row.style.gridTemplateColumns='1fr';return;}row.classList.remove('df-smart-source-line-empty');smartSetGrid(row,smartAutoWidths(visible.length));}
function smartCreateGhost(card,key,x,y){const f=smartFieldByKey(key),rect=card.getBoundingClientRect(),g=document.createElement('div');g.className='df-smart-drag-ghost';g.style.width=`${Math.min(Math.max(rect.width,210),380)}px`;g.style.left='0px';g.style.top='0px';g.innerHTML=`<span class="df-smart-ghost-handle">${modernUiIcon('grip')}</span><strong>${esc(f?.label||'Campo')}</strong><span class="df-smart-ghost-meta">${esc(tr.types[f?.type]||f?.type||'')}</span>`;document.body.appendChild(g);smartDrag.ghost=g;const gr=g.getBoundingClientRect();smartDrag.ghostWidth=Math.max(1,gr.width);smartDrag.ghostHeight=Math.max(1,gr.height);smartPositionGhost(x,y);}
function smartPositionGhost(x,y){const g=smartDrag.ghost;if(!g)return;const pad=14,w=Math.max(1,Number(smartDrag.ghostWidth)||g.offsetWidth),h=Math.max(1,Number(smartDrag.ghostHeight)||g.offsetHeight),maxX=Math.max(8,window.innerWidth-w-8),maxY=Math.max(8,window.innerHeight-h-8),left=Math.min(maxX,Math.max(8,x+pad)),top=Math.min(maxY,Math.max(8,y+pad));g.style.transform=`translate3d(${Math.round(left)}px,${Math.round(top)}px,0)`;}
function smartPreviewBesideWidths(spec){const target=smartFieldByKey(spec.targetKey),source=smartFieldByKey(smartDrag.fieldKey);if(!target||!source)return[100];const line=visualLineForField(target).map(([f])=>f).filter(f=>f!==source),pos=Math.max(0,line.indexOf(target)+(spec.position==='after'?1:0));line.splice(pos,0,source);return smartAutoWidths(line.length);}
function smartOverlayRect(rect,kind,label,position=''){if(!rect||!rect.width||!rect.height)return null;const el=document.createElement('div');el.className=`df-smart-drop-overlay is-${kind}${position?` is-${position}`:''}`;el.style.left=`${Math.round(rect.left)}px`;el.style.top=`${Math.round(rect.top)}px`;el.style.width=`${Math.round(rect.width)}px`;el.style.height=`${Math.round(rect.height)}px`;el.innerHTML=`<span>${esc(label)}</span>`;document.body.appendChild(el);return el;}
function smartHalfRect(rect,position,axis='vertical'){if(axis==='horizontal'){const w=rect.width/2;return{left:position==='before'?rect.left:rect.left+w,top:rect.top,width:w,height:rect.height};}const h=rect.height/2;return{left:rect.left,top:position==='before'?rect.top:rect.top+h,width:rect.width,height:h};}
function smartRenderPreview(spec){const id=smartSpecId(spec);if(id===smartDrag.specKey)return;smartRestorePreviewDom();smartDrag.spec=spec;smartDrag.specKey=id;if(!spec)return;
 const fieldLabel=smartFieldByKey(smartDrag.fieldKey)?.label||'Campo';
 if(spec.kind==='slot'){
  const row=smartDrag.sourceRow;if(row){const r=row.getBoundingClientRect(),chosen=smartHalfRect(r,spec.position==='left'?'before':'after','horizontal'),empty=smartHalfRect(r,spec.position==='left'?'after':'before','horizontal');smartOverlayRect(chosen,'slot-field',`${fieldLabel} · 50%`);smartOverlayRect(empty,'slot-empty','VUOTO 50%');}
 }else if(spec.kind==='beside'){
  if(spec.slot){const slot=layoutCanvas?.querySelector(`.df-layout-empty-slot[data-slot-target-key="${CSS.escape(spec.targetKey)}"][data-slot-side="${spec.position==='after'?'after':'before'}"]`);if(slot){smartOverlayRect(slot.getBoundingClientRect(),'empty-slot','INSERISCI QUI · 50%');return;}}
  const target=layoutCanvas?.querySelector(`.df-layout-card[data-field-key="${CSS.escape(spec.targetKey)}"]`);if(target){const r=target.getBoundingClientRect(),half=smartHalfRect(r,spec.position,'horizontal');smartOverlayRect(half,'beside',spec.position==='before'?'SINISTRA · 50%':'DESTRA · 50%',spec.position);target.classList.add(spec.position==='before'?'df-smart-target-left':'df-smart-target-right');}
 }else if(spec.kind==='line'){
  const target=layoutCanvas?.querySelector(`.df-layout-card[data-field-key="${CSS.escape(spec.targetKey)}"]`),line=target?.closest('.df-layout-row');if(line){const r=line.getBoundingClientRect(),half=smartHalfRect(r,spec.position,'vertical');smartOverlayRect(half,'line',spec.position==='before'?'SOPRA':'SOTTO',spec.position);line.classList.add(spec.position==='before'?'df-smart-line-target-before':'df-smart-line-target-after');}
 }else if(spec.kind==='joinrow'){
  const group=layoutCanvas?.querySelector(`.df-layout-row-group[data-row-no="${Number(spec.row)}"]`);if(group){smartOverlayRect(group.getBoundingClientRect(),'joinrow','AGGIUNGI A QUESTA RIGA');group.classList.add('df-smart-row-join-target');}
 }else if(spec.kind==='newrow'){
  const group=layoutCanvas?.querySelector(`.df-layout-row-group[data-row-no="${Number(spec.row)}"]`);if(group){const r=group.getBoundingClientRect(),h=Math.min(44,Math.max(28,r.height*.22)),band={left:r.left,top:spec.position==='before'?r.top:r.bottom-h,width:r.width,height:h};smartOverlayRect(band,'newrow',spec.position==='before'?'SOPRA · NUOVA RIGA':'SOTTO · NUOVA RIGA',spec.position);group.classList.add(spec.position==='before'?'df-smart-row-target-before':'df-smart-row-target-after');}
 }else if(spec.kind==='append'){
  const r=layoutNewRow?.getBoundingClientRect();if(r)smartOverlayRect({left:r.left,top:r.top-12,width:r.width,height:r.height+24},'append','NUOVA RIGA');
 }
}
function smartProjectedCanvasPoint(x,y){const sw=Math.max(1,Number(smartDrag.sourceWidth)||1),sh=Math.max(1,Number(smartDrag.sourceHeight)||1),gx=Math.max(0,Math.min(1,Number(smartDrag.grabXRatio)||.5)),gy=Math.max(0,Math.min(1,Number(smartDrag.grabYRatio)||.5));return{x:x+(.5-gx)*sw,y:y+(.5-gy)*sh};}
function smartUpdateIntentAxis(x,y){const dx=x-(Number(smartDrag.originX)||x),dy=y-(Number(smartDrag.originY)||y),adx=Math.abs(dx),ady=Math.abs(dy);if(!smartDrag.intentAxis){if(Math.max(adx,ady)<10)return'';smartDrag.intentAxis=ady>=adx*.82?'vertical':'horizontal';smartDrag.intentLockX=x;smartDrag.intentLockY=y;return smartDrag.intentAxis;}const ldx=Math.abs(x-(Number(smartDrag.intentLockX)||x)),ldy=Math.abs(y-(Number(smartDrag.intentLockY)||y));if(smartDrag.intentAxis==='vertical'&&ldx>=34&&ldx>ldy*1.65){smartDrag.intentAxis='horizontal';smartDrag.intentLockX=x;smartDrag.intentLockY=y;}else if(smartDrag.intentAxis==='horizontal'&&ldy>=34&&ldy>ldx*1.65){smartDrag.intentAxis='vertical';smartDrag.intentLockX=x;smartDrag.intentLockY=y;}return smartDrag.intentAxis;}
function smartProjectedPoint(card,x,y){
 const r=card.getBoundingClientRect(),sw=Math.max(1,Number(smartDrag.sourceWidth)||r.width),sh=Math.max(1,Number(smartDrag.sourceHeight)||r.height),gx=Math.max(0,Math.min(1,Number(smartDrag.grabXRatio)||.5)),gy=Math.max(0,Math.min(1,Number(smartDrag.grabYRatio)||.5));
 return{r,px:x+(.5-gx)*sw,py:y+(.5-gy)*sh};
}
function smartClassifyCard(card,x,y){
 if(!card||card.dataset.fieldKey===smartDrag.fieldKey)return null;
 const target=smartFieldByKey(card.dataset.fieldKey),source=smartFieldByKey(smartDrag.fieldKey);if(!target||!source)return null;
 const projected=smartProjectedPoint(card,x,y),r=projected.r,rx=(projected.px-r.left)/Math.max(1,r.width),ry=(projected.py-r.top)/Math.max(1,r.height),moveX=x-(Number(smartDrag.originX)||x),moveY=y-(Number(smartDrag.originY)||y),amx=Math.abs(moveX),amy=Math.abs(moveY),targetLine=visualLineForField(target).map(([f])=>f),sourceInLine=targetLine.includes(source),count=targetLine.filter(f=>f!==source).length+(sourceInLine?0:1),canSide=count<=4,row=Number(target.config?.layout?.row||1),current=smartDrag.spec&&smartDrag.spec.targetKey===target.key?smartDrag.spec:null;
 let axis=smartDrag.intentAxis||'vertical';if(!canSide)axis='vertical';
 if(axis==='horizontal'&&canSide){
  if(current?.kind==='beside'&&current.position==='before'&&rx<=.62)return{kind:'beside',targetKey:target.key,row,position:'before'};
  if(current?.kind==='beside'&&current.position==='after'&&rx>=.38)return{kind:'beside',targetKey:target.key,row,position:'after'};
  const position=Math.abs(rx-.5)<.07&&amx>=10?(moveX<0?'before':'after'):(rx<.5?'before':'after');
  return{kind:'beside',targetKey:target.key,row,position};
 }
 if(current?.kind==='line'&&current.position==='before'&&ry<=.64)return{kind:'line',row,targetKey:target.key,position:'before'};
 if(current?.kind==='line'&&current.position==='after'&&ry>=.36)return{kind:'line',row,targetKey:target.key,position:'after'};
 const position=Math.abs(ry-.5)<.07&&amy>=10?(moveY<0?'before':'after'):(ry<.5?'before':'after');
 return{kind:'line',row,targetKey:target.key,position};
}
function smartNearestCardInRow(row,x,y){const cards=[...row.querySelectorAll('.df-layout-card:not(.df-smart-source-hidden)')];if(!cards.length)return null;let best=null,score=Infinity;for(const card of cards){const r=card.getBoundingClientRect(),cx=Math.max(r.left,Math.min(x,r.right)),cy=Math.max(r.top,Math.min(y,r.bottom)),d=(x-cx)**2+(y-cy)**2;if(d<score){score=d;best=card;}}return best;}
function smartNearestEmptySlot(x,y,margin=30){const slots=[...(layoutCanvas?.querySelectorAll('.df-layout-empty-slot[data-slot-target-key]')||[])];let best=null,score=Infinity;for(const slot of slots){const r=slot.getBoundingClientRect();if(!r.width||!r.height)continue;const dx=x<r.left?r.left-x:x>r.right?x-r.right:0,dy=y<r.top?r.top-y:y>r.bottom?y-r.bottom:0,d=dx*dx+dy*dy;if(d<=margin*margin&&d<score){score=d;best=slot;}}return best;}
function smartNearestCardNearPoint(x,y,margin=44){const cards=[...(layoutCanvas?.querySelectorAll('.df-layout-card:not(.df-smart-source-hidden)')||[])];let best=null,score=Infinity;for(const card of cards){const r=card.getBoundingClientRect();if(!r.width||!r.height)continue;const dx=x<r.left?r.left-x:x>r.right?x-r.right:0,dy=y<r.top?r.top-y:y>r.bottom?y-r.bottom:0,d=dx*dx+dy*dy;if(d<=margin*margin&&d<score){score=d;best=card;}}return best;}
function smartFindDropSpec(x,y){const probe=smartProjectedCanvasPoint(x,y),hx=Math.max(1,Math.min(window.innerWidth-2,probe.x)),hy=Math.max(1,Math.min(window.innerHeight-2,probe.y)),stack=document.elementsFromPoint?document.elementsFromPoint(hx,hy):[];let emptySlot=stack.map(el=>el?.closest?.('.df-layout-empty-slot[data-slot-target-key]')).find(Boolean);if(!emptySlot)emptySlot=smartNearestEmptySlot(hx,hy,30);if(emptySlot){const targetKey=emptySlot.dataset.slotTargetKey||'',side=emptySlot.dataset.slotSide||'before',target=smartFieldByKey(targetKey);if(target&&targetKey!==smartDrag.fieldKey)return{kind:'beside',targetKey,row:Number(target.config?.layout?.row||1),position:side==='after'?'after':'before',slot:true};}let card=stack.find(el=>el?.classList?.contains('df-layout-card')&&!el.classList.contains('df-smart-source-hidden'));if(!card)card=smartNearestCardNearPoint(hx,hy,44);if(card)return smartClassifyCard(card,x,y);
 const row=stack.map(el=>el?.closest?.('.df-layout-row')).find(Boolean);if(row){card=smartNearestCardInRow(row,hx,hy);if(card)return smartClassifyCard(card,x,y);if(row===smartDrag.sourceRow||row.classList.contains('df-smart-source-line-empty')){const rr=row.getBoundingClientRect(),rx=(hx-rr.left)/Math.max(1,rr.width);return{kind:'slot',row:Number(row.dataset.row||1),position:rx<.5?'left':'right'};}return{kind:'joinrow',row:Number(row.dataset.row||1)};}
 const group=stack.map(el=>el?.closest?.('.df-layout-row-group')).find(Boolean);if(group){const rowNo=Number(group.dataset.rowNo||1),gr=group.getBoundingClientRect(),band=Math.min(42,Math.max(24,gr.height*.22));if(hy<=gr.top+band)return{kind:'newrow',row:rowNo,position:'before'};if(hy>=gr.bottom-band)return{kind:'newrow',row:rowNo,position:'after'};return{kind:'joinrow',row:rowNo};}
 if(layoutNewRow){const r=layoutNewRow.getBoundingClientRect();if(hx>=r.left-16&&hx<=r.right+16&&hy>=r.top-34&&hy<=r.bottom+42)return{kind:'append'};}
 const groups=[...(layoutCanvas?.querySelectorAll('.df-layout-row-group')||[])].filter(g=>!g.classList.contains('df-smart-source-row-empty'));let nearest=null,dist=Infinity;for(const g of groups){const r=g.getBoundingClientRect(),d=hy<r.top?r.top-hy:hy>r.bottom?hy-r.bottom:0;if(d<dist){dist=d;nearest=g;}}if(nearest&&dist<52){const r=nearest.getBoundingClientRect();return{kind:'newrow',row:Number(nearest.dataset.rowNo||1),position:hy<r.top+r.height/2?'before':'after'};}
 const current=smartDrag.spec;if(current?.targetKey){const el=layoutCanvas?.querySelector(`.df-layout-card[data-field-key="${CSS.escape(current.targetKey)}"]`);if(el){const r=el.getBoundingClientRect();if(hx>=r.left-48&&hx<=r.right+48&&hy>=r.top-38&&hy<=r.bottom+38)return current;}}
 return null;
}
function smartShiftRowMeta(insertRow){builderConfig=builderConfig&&typeof builderConfig==='object'?builderConfig:{};builderConfig.layout=builderConfig.layout&&typeof builderConfig.layout==='object'?builderConfig.layout:{};const meta=rowMetaStore(),next={};Object.keys(meta).forEach(k=>{const n=Number(k);next[String(Number.isFinite(n)&&n>=insertRow?n+1:n)]=meta[k];});builderConfig.layout.row_meta=next;refreshActiveRowSelection();}
function smartMoveBeside(index,targetIndex,position='after'){if(index<0||targetIndex<0||!selected[index]||!selected[targetIndex]||index===targetIndex)return false;const field=selected[index],target=selected[targetIndex],oldRow=Number(field.config?.layout?.row||1),targetRow=Number(target.config?.layout?.row||1),sourceLine=visualLineForField(field).map(([f])=>f),targetLine=visualLineForField(target).map(([f])=>f),sameLine=targetLine.includes(field),targetMembers=targetLine.filter(f=>f!==field);if(!sameLine&&targetMembers.length>=4)return smartMoveToExistingRow(index,targetRow,target.key);if(!sameLine){const sourceRest=sourceLine.filter(f=>f!==field);if(sourceRest.length){const auto=smartAutoWidths(sourceRest.length);sourceRest.forEach((f,i)=>{smartClearOffsets(f);f.config.layout.width=auto[i]??100;});}}const rowItems=fieldsInRow(targetRow).map(([f])=>f).filter(f=>f!==field),at=Math.max(0,rowItems.indexOf(target)+(position==='after'?1:0));rowItems.splice(at,0,field);field.config.layout.row=targetRow;setLogicalRowOrder(targetRow,rowItems);const newTargetLine=rowItems.filter(f=>targetMembers.includes(f)||f===field),auto=smartAutoWidths(newTargetLine.length);newTargetLine.forEach((f,i)=>{smartClearOffsets(f);f.config.layout.width=auto[i]??100;});normalizeLayoutRows();sortSelectedByLayout();if(selected.some(f=>Number(f.config?.layout?.row||1)===oldRow))normalizeVisualLines(oldRow);normalizeVisualLines(Number(field.config.layout.row||targetRow));activeStructureSelection=null;activeFieldKey=field.key;return true;}
function smartMoveLineRelative(index,targetKey,position='after'){if(index<0||!selected[index]||!targetKey)return false;const field=selected[index],target=smartFieldByKey(targetKey);if(!target||target===field)return false;const oldRow=Number(field.config?.layout?.row||1),targetRow=Number(target.config?.layout?.row||1),sourceLine=visualLineForField(field).map(([f])=>f),sourceRest=sourceLine.filter(f=>f!==field);if(sourceRest.length){const auto=smartAutoWidths(sourceRest.length);sourceRest.forEach((f,i)=>{smartClearOffsets(f);f.config.layout.width=auto[i]??100;});}const targetLine=visualLineForField(target).map(([f])=>f).filter(f=>f!==field),targetItems=fieldsInRow(targetRow).map(([f])=>f).filter(f=>f!==field);if(!targetLine.length)return smartMoveToExistingRow(index,targetRow,targetKey);let first=targetItems.indexOf(targetLine[0]),last=targetItems.indexOf(targetLine[targetLine.length-1]);if(first<0||last<0)return smartMoveToExistingRow(index,targetRow,targetKey);const at=position==='before'?first:last+1;smartClearOffsets(field);field.config.layout={...(field.config.layout||{}),row:targetRow,col:at+1,width:100};targetItems.splice(at,0,field);setLogicalRowOrder(targetRow,targetItems);normalizeLayoutRows();sortSelectedByLayout();if(selected.some(f=>Number(f.config?.layout?.row||1)===oldRow))normalizeVisualLines(oldRow);normalizeVisualLines(targetRow);activeStructureSelection=null;activeFieldKey=field.key;return true;}
function smartMoveToExistingRow(index,targetRow,targetKey=null){if(index<0||!selected[index])return false;targetRow=Math.max(1,Number(targetRow)||1);const field=selected[index],oldRow=Number(field.config?.layout?.row||1),sourceLine=visualLineForField(field).map(([f])=>f),sourceRest=sourceLine.filter(f=>f!==field);if(sourceRest.length){const auto=smartAutoWidths(sourceRest.length);sourceRest.forEach((f,i)=>{smartClearOffsets(f);f.config.layout.width=auto[i]??100;});}const target=targetKey?selected.find(f=>f.key===targetKey):null,targetLine=target?visualLineForField(target).map(([f])=>f).filter(f=>f!==field):[];selected.splice(index,1);const targetItems=fieldsInRow(targetRow).map(([f])=>f).filter(f=>f!==field);let at=targetItems.length;if(targetLine.length){const last=targetLine[targetLine.length-1],li=targetItems.indexOf(last);if(li>=0)at=li+1;}smartClearOffsets(field);field.config.layout={...(field.config.layout||{}),row:targetRow,col:at+1,width:100};targetItems.splice(at,0,field);setLogicalRowOrder(targetRow,targetItems);selected.push(field);normalizeLayoutRows();sortSelectedByLayout();if(selected.some(f=>Number(f.config?.layout?.row||1)===oldRow))normalizeVisualLines(oldRow);normalizeVisualLines(Number(field.config.layout.row||targetRow));activeStructureSelection=null;activeFieldKey=field.key;return true;}
function smartMoveToSlot(index,position='left'){if(index<0||!selected[index])return false;const field=selected[index],line=visualLineForField(field).map(([f])=>f);if(line.length!==1)return false;field.config.layout.width=50;if(position==='right'){field.config.layout.offset_before=50;delete field.config.layout.offset_after;}else{field.config.layout.offset_after=50;delete field.config.layout.offset_before;}normalizeVisualLines(Number(field.config.layout.row||1));activeStructureSelection=null;activeFieldKey=field.key;return true;} function smartMoveNewRow(index,targetRow,position='after'){if(index<0||!selected[index])return false;const field=selected[index],oldRow=Number(field.config?.layout?.row||1),oldItems=fieldsInRow(oldRow).map(([f])=>f),sourceLine=visualLineForField(field).map(([f])=>f),sourceRest=sourceLine.filter(f=>f!==field);if(oldRow===Number(targetRow)&&oldItems.length===1)return false;if(sourceRest.length){const auto=smartAutoWidths(sourceRest.length);sourceRest.forEach((f,i)=>{smartClearOffsets(f);f.config.layout.width=auto[i]??100;});}const insertRow=Math.max(1,Number(targetRow)+(position==='after'?1:0));smartShiftRowMeta(insertRow);selected.forEach(f=>{defaultFieldConfig(f);if(f!==field&&Number(f.config.layout.row||1)>=insertRow)f.config.layout.row=Number(f.config.layout.row)+1;});smartClearOffsets(field);field.config.layout={...(field.config.layout||{}),row:insertRow,col:1,width:100};normalizeLayoutRows();sortSelectedByLayout();if(selected.some(f=>Number(f.config?.layout?.row||1)===oldRow))normalizeVisualLines(oldRow);normalizeVisualLines(Number(field.config.layout.row||1));activeStructureSelection=null;activeFieldKey=field.key;return true;}
function smartCommitSpec(spec,key){const index=smartFieldIndex(key);if(index<0||!spec)return false;let changed=false;if(spec.kind==='slot')changed=smartMoveToSlot(index,spec.position);else if(spec.kind==='beside'){const ti=smartFieldIndex(spec.targetKey);changed=smartMoveBeside(index,ti,spec.position);}else if(spec.kind==='line')changed=smartMoveLineRelative(index,spec.targetKey,spec.position);else if(spec.kind==='joinrow')changed=smartMoveToExistingRow(index,Number(spec.row),spec.targetKey||null);else if(spec.kind==='newrow')changed=smartMoveNewRow(index,Number(spec.row),spec.position);else if(spec.kind==='append'){const max=Math.max(1,...logicalRowNumbers());changed=smartMoveNewRow(index,max,'after');}if(changed){sortSelectedByLayout();sync();renderSelected();clearTimeout(historyTimer);pushHistory();}return changed;}
function smartEndVisual(){clearTimeout(smartDrag.pressTimer);smartDrag.pressTimer=null;smartDrag.ghost?.remove();smartDrag.ghost=null;document.body.classList.remove('df-smart-drag-active');document.querySelector('.df-builder-workspace')?.classList.remove('is-smart-dragging');}
function smartBeginDrag(){const p=smartDrag.pending;if(!p||smartDrag.active||!p.card?.isConnected)return;const sourceRect=p.card.getBoundingClientRect();smartDrag.active=true;smartDrag.pointerId=p.pointerId;smartDrag.pointerType=p.pointerType;smartDrag.fieldKey=p.fieldKey;smartDrag.sourceCard=p.card;smartDrag.sourceRow=p.card.closest('.df-layout-row');smartDrag.lastX=p.x;smartDrag.lastY=p.y;smartDrag.queuedX=p.x;smartDrag.queuedY=p.y;smartDrag.originX=p.startX;smartDrag.originY=p.startY;smartDrag.sourceWidth=Math.max(1,sourceRect.width);smartDrag.sourceHeight=Math.max(1,sourceRect.height);smartDrag.grabXRatio=Math.max(0,Math.min(1,(p.startX-sourceRect.left)/smartDrag.sourceWidth));smartDrag.grabYRatio=Math.max(0,Math.min(1,(p.startY-sourceRect.top)/smartDrag.sourceHeight));smartDrag.intentAxis='';smartDrag.intentLockX=p.startX;smartDrag.intentLockY=p.startY;smartDrag.pending=null;clearTimeout(smartDrag.pressTimer);smartDrag.pressTimer=null;smartCreateGhost(p.card,p.fieldKey,p.x,p.y);p.card.classList.add('df-smart-source-hidden');document.body.classList.add('df-smart-drag-active');document.querySelector('.df-builder-workspace')?.classList.add('is-smart-dragging');if(p.pointerType!=='mouse'&&navigator.vibrate)try{navigator.vibrate(10);}catch{};}
function smartCancelPending(){clearTimeout(smartDrag.pressTimer);smartDrag.pressTimer=null;smartDrag.pending=null;}
function smartQueueDrag(e,card,key){if(editorLocked||!e.isPrimary||(e.pointerType==='mouse'&&e.button!==0)||e.target.closest(smartDragIgnoreSelector))return;smartCancelPending();smartDrag.pending={pointerId:e.pointerId,pointerType:e.pointerType||'mouse',fieldKey:key,card,x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY};if(e.pointerType==='touch'||e.pointerType==='pen')smartDrag.pressTimer=setTimeout(()=>smartBeginDrag(),300);}
function smartRunPointerFrame(){smartDrag.raf=0;if(!smartDrag.active)return;const x=smartDrag.queuedX,y=smartDrag.queuedY;smartUpdateIntentAxis(x,y);smartPositionGhost(x,y);smartRenderPreview(smartFindDropSpec(x,y));}
function smartSchedulePointerFrame(x,y){smartDrag.queuedX=x;smartDrag.queuedY=y;if(!smartDrag.raf)smartDrag.raf=requestAnimationFrame(smartRunPointerFrame);}
function smartFlushPointerFrame(){if(!smartDrag.active)return;if(smartDrag.raf){cancelAnimationFrame(smartDrag.raf);smartDrag.raf=0;}smartRunPointerFrame();}
function smartPointerMove(e){const p=smartDrag.pending;if(p&&e.pointerId===p.pointerId&&!smartDrag.active){p.x=e.clientX;p.y=e.clientY;const d=Math.hypot(e.clientX-p.startX,e.clientY-p.startY);if(p.pointerType==='mouse'){if(d>=4)smartBeginDrag();}else if(d>12){smartCancelPending();return;}}if(!smartDrag.active||e.pointerId!==smartDrag.pointerId)return;e.preventDefault();smartDrag.lastX=e.clientX;smartDrag.lastY=e.clientY;smartSchedulePointerFrame(e.clientX,e.clientY);}
function smartFinishDrag(commit,e){if(!smartDrag.active){smartCancelPending();return;}if(e&&e.pointerId!==smartDrag.pointerId)return;e?.preventDefault?.();smartDrag.queuedX=smartDrag.lastX;smartDrag.queuedY=smartDrag.lastY;smartFlushPointerFrame();const before=smartCaptureRects(),spec=smartDrag.spec,key=smartDrag.fieldKey;smartEndVisual();smartRestorePreviewDom();const changed=commit&&spec?smartCommitSpec(spec,key):false;smartSuppressClickUntil=Date.now()+260;smartDrag.active=false;smartDrag.pointerId=null;smartDrag.pointerType='';smartDrag.fieldKey='';smartDrag.sourceCard=null;smartDrag.sourceRow=null;smartDrag.spec=null;smartDrag.specKey='';smartDrag.intentAxis='';smartDrag.ghostWidth=0;smartDrag.ghostHeight=0;if(smartDrag.raf){cancelAnimationFrame(smartDrag.raf);smartDrag.raf=0;}renderLayoutCanvas();smartAnimateFrom(before);}
function smartPointerUp(e){if(smartDrag.active)smartFinishDrag(true,e);else if(smartDrag.pending&&e.pointerId===smartDrag.pending.pointerId)smartCancelPending();}
function smartPointerCancel(e){if(smartDrag.active)smartFinishDrag(false,e);else if(smartDrag.pending&&e.pointerId===smartDrag.pending.pointerId)smartCancelPending();}
window.addEventListener('pointermove',smartPointerMove,{passive:false});window.addEventListener('pointerup',smartPointerUp,{passive:false});window.addEventListener('pointercancel',smartPointerCancel,{passive:false});document.addEventListener('touchmove',e=>{if(smartDrag.active)e.preventDefault();},{passive:false});window.addEventListener('keydown',e=>{if(e.key==='Escape'&&smartDrag.active)smartFinishDrag(false);});
/* End Forms 1.3.67 intelligent field drag & drop. */

const layoutSectionState=new Map(),layoutRowState=new Map();
function isLayoutSectionField(f){return !!f&&(f.type==='heading'||(f.type==='fieldset'&&f.config?.builder_role==='section'));}
function layoutSectionTitle(f){if(!f)return structureUi.general;return String(f.label||f.config?.content||structureUi.section).trim()||structureUi.section;}
function layoutFieldCount(rows){return rows.reduce((n,r)=>n+r.items.filter(([f])=>!isLayoutSectionField(f)).length,0);}
function renderLayoutFieldCard(f,i,rowNo,row){
 const card=document.createElement('div');card.className='df-layout-card'+(!activeStructureSelection&&f.key===activeFieldKey?' is-active':'');card.dataset.fieldKey=f.key;card.draggable=false;card.style.width='100%';const required=f.required?'<span class="df-required-badge">Obbligatorio</span>':'';
 card.innerHTML=`<span class="df-layout-handle" title="Trascina campo" aria-hidden="true">${modernUiIcon('grip')}</span><strong>${esc(f.label)}</strong><span class="df-layout-meta"><span class="df-layout-type">${esc(tr.types[f.type]||f.type)}</span>${required}<select aria-label="Larghezza campo">${widthChoices(f.config.layout.width||100)}</select><span class="df-layout-actions"><button type="button" data-canvas-edit class="df-icon-only" title="Modifica campo" aria-label="Modifica campo">${modernUiIcon('edit')}</button><button type="button" data-canvas-duplicate class="df-icon-only" title="Duplica campo" aria-label="Duplica campo">${modernUiIcon('copy')}</button><button type="button" data-canvas-remove class="df-canvas-remove df-icon-only" title="Elimina campo" aria-label="Elimina campo">${modernUiIcon('trash')}</button></span></span>`;
 card.addEventListener('pointerdown',e=>smartQueueDrag(e,card,f.key));
 card.addEventListener('click',e=>{if(Date.now()<smartSuppressClickUntil||e.target.closest('button,select,input,textarea,a,label'))return;selectField(i);});
 card.querySelector('select').onchange=e=>setFieldWidth(i,Number(e.target.value));card.querySelector('[data-canvas-edit]').onclick=()=>selectField(i);card.querySelector('[data-canvas-duplicate]').onclick=()=>duplicateField(i);card.querySelector('[data-canvas-remove]').onclick=()=>confirmDelete(`il campo “${f.label||'Campo'}”`,()=>removeCanvasField(i));row.appendChild(card);
}

/* Forms 1.3.67: drag whole sections and rows as structural blocks. */
const structureDrag={pending:null,active:false,pointerId:null,type:'',id:null,handle:null,ghost:null,spec:null,pressTimer:null,lastX:0,lastY:0,raf:0,queuedX:0,queuedY:0,ghostWidth:0,ghostHeight:0};
let structureSuppressClickUntil=0;
function structureRowBlocks(){
 normalizeLayoutRows();
 return logicalRowNumbers().map(rowNo=>{
  const fields=fieldsInRow(rowNo).map(([f])=>f),storedMeta=clone(rowMeta(rowNo)),rowId=String(storedMeta.id||rowIdForRow(rowNo)),sectionKey=fields.find(isLayoutSectionField)?.key||null;
  const node=layoutCanvas?.querySelector(`.df-layout-row-group[data-row-id="${CSS.escape(rowId)}"]`),openState=sectionKey?null:(layoutRowState.has(rowId)?!!layoutRowState.get(rowId):!!node?.classList.contains('is-open'));
  return{rowNo,rowId,fields,meta:storedMeta,sectionKey,openState};
 });
}
function structureApplyBlocks(blocks){
 builderConfig=builderConfig&&typeof builderConfig==='object'?builderConfig:{};builderConfig.layout=builderConfig.layout&&typeof builderConfig.layout==='object'?builderConfig.layout:{};
 const nextMeta={},ordered=[],nextRowState=new Map();
 blocks.forEach((block,bi)=>{
  const row=bi+1,meta=block.meta&&typeof block.meta==='object'?clone(block.meta):{title:'',description:''};if(!meta.id)meta.id=block.rowId||newRowId();if(typeof meta.title!=='string')meta.title='';if(typeof meta.description!=='string')meta.description='';block.rowId=meta.id;nextMeta[String(row)]=meta;
  if(!block.sectionKey&&block.openState!==null&&block.openState!==undefined)nextRowState.set(meta.id,!!block.openState);
  block.fields.forEach((f,ci)=>{defaultFieldConfig(f);f.config.layout={...(f.config.layout||{}),row,col:ci+1};ordered.push(f);});
 });
 builderConfig.layout.row_meta=nextMeta;layoutRowState.clear();nextRowState.forEach((value,id)=>layoutRowState.set(String(id),value));selected.splice(0,selected.length,...ordered);sortSelectedByLayout();refreshActiveRowSelection();
}
function structureSectionRange(blocks,sectionId){
 if(sectionId==='general'){const end=blocks.findIndex(b=>b.sectionKey);return{start:0,end:end<0?blocks.length:end};}
 const key=String(sectionId||'').replace(/^section:/,'');const start=blocks.findIndex(b=>b.sectionKey===key);if(start<0)return null;let end=blocks.length;for(let i=start+1;i<blocks.length;i++){if(blocks[i].sectionKey){end=i;break;}}return{start,end};
}
function remapSectionCloneRefs(value,keyMap){
 if(Array.isArray(value))return value.map(v=>remapSectionCloneRefs(v,keyMap));
 if(value&&typeof value==='object'){Object.keys(value).forEach(k=>{value[k]=remapSectionCloneRefs(value[k],keyMap);});return value;}
 if(typeof value==='string'&&keyMap.has(value))return keyMap.get(value);
 return value;
}
function duplicateLayoutSection(sectionId){
 if(!sectionId||sectionId==='general')return false;
 const blocks=structureRowBlocks(),range=structureSectionRange(blocks,sectionId);if(!range||range.start>=range.end)return false;
 const source=blocks.slice(range.start,range.end),used=new Set(selected.map(f=>String(f.key||''))),keyMap=new Map(),pairs=[];
 const reserveKey=base=>{const stem=String(base||'field').replace(/[^a-zA-Z0-9_]+/g,'_')||'field';let n=2,k=`${stem}_${n}`;while(used.has(k)){n++;k=`${stem}_${n}`;}used.add(k);return k;};
 source.forEach(block=>block.fields.forEach(f=>{const cf=clone(f),oldKey=String(f.key||'');cf.key=reserveKey(oldKey);if(oldKey)keyMap.set(oldKey,cf.key);pairs.push({original:f,copy:cf});}));
 pairs.forEach(({copy})=>{const keepKey=copy.key;remapSectionCloneRefs(copy,keyMap);copy.key=keepKey;defaultFieldConfig(copy);});
 let pi=0,newSectionKey='';
 const clones=source.map(block=>{const fields=block.fields.map(()=>pairs[pi++].copy),marker=fields.find(isLayoutSectionField),meta=block.meta?clone(block.meta):{title:'',description:''};meta.id=newRowId();if(marker&&!newSectionKey){marker.label=`${String(marker.label||structureUi.section).trim()||structureUi.section} copia`;newSectionKey=marker.key;}return{rowNo:0,rowId:meta.id,fields,meta,sectionKey:marker?.key||null,openState:block.openState};});
 blocks.splice(range.end,0,...clones);structureApplyBlocks(blocks);normalizeLayoutRows();sortSelectedByLayout();activeStructureSelection=null;activeFieldKey=newSectionKey||clones.flatMap(b=>b.fields)[0]?.key||null;if(newSectionKey)layoutSectionState.set('section:'+newSectionKey,true);sync();renderSelected();renderLayoutCanvas();renderColumns();renderTokens();renderUserEmailFields();clearTimeout(historyTimer);pushHistory();return true;
}
function structureMoveSection(sourceId,targetId,position){
 if(!sourceId||sourceId==='general'||sourceId===targetId)return false;let blocks=structureRowBlocks(),src=structureSectionRange(blocks,sourceId);if(!src||src.start>=src.end)return false;const moved=blocks.splice(src.start,src.end-src.start);let target=structureSectionRange(blocks,targetId);let at;
 if(targetId==='general'){target=structureSectionRange(blocks,'general');at=position==='before'?0:(target?.end??0);}else if(target){at=position==='before'?target.start:target.end;}else at=blocks.length;
 blocks.splice(Math.max(0,Math.min(blocks.length,at)),0,...moved);structureApplyBlocks(blocks);const key=String(sourceId).replace(/^section:/,'');activeStructureSelection=null;activeFieldKey=key;layoutSectionState.set('section:'+key,true);return true;
}
function structureMoveRow(sourceId,spec){
 sourceId=String(sourceId||'');let blocks=structureRowBlocks(),si=blocks.findIndex(b=>String(b.rowId||'')===sourceId);if(si<0||blocks[si].sectionKey)return false;const moved=blocks.splice(si,1)[0],movedId=String(moved.rowId||moved.meta?.id||sourceId),anchorKey=moved.fields[0]?.key||'';let at=blocks.length;
 if(spec.kind==='row'){const ti=blocks.findIndex(b=>spec.targetRowId?String(b.rowId||'')===String(spec.targetRowId):Number(b.rowNo)===Number(spec.targetRow));if(ti<0)return false;at=ti+(spec.position==='after'?1:0);}else if(spec.kind==='section'){const range=structureSectionRange(blocks,spec.sectionId);if(spec.sectionId==='general')at=range?.end??0;else at=range?range.start+1:blocks.length;}else return false;
 blocks.splice(Math.max(0,Math.min(blocks.length,at)),0,moved);structureApplyBlocks(blocks);const field=anchorKey?selected.find(f=>f.key===anchorKey):null,newRow=rowNoForId(movedId)||Number(field?.config?.layout?.row||1);activeFieldKey=field?.key||activeFieldKey;activeStructureSelection={type:'row',id:movedId,row:newRow};return true;
}
function structureOverlayRect(rect,label,kind,position=''){if(!rect||!rect.width||!rect.height)return null;const el=document.createElement('div');el.className=`df-structure-drop-overlay is-${kind}${position?` is-${position}`:''}`;el.style.left=`${Math.round(rect.left)}px`;el.style.top=`${Math.round(rect.top)}px`;el.style.width=`${Math.round(rect.width)}px`;el.style.height=`${Math.round(rect.height)}px`;el.innerHTML=`<span>${esc(label)}</span>`;document.body.appendChild(el);return el;}
function structureVerticalHalf(rect,position){const h=rect.height/2;return{left:rect.left,top:position==='before'?rect.top:rect.top+h,width:rect.width,height:h};}
function structureVerticalPosition(prev,kind,targetId,y,rect){const mid=rect.top+rect.height/2,band=Math.min(22,Math.max(10,rect.height*.16));if(prev?.kind===kind&&String(prev.targetRowId||prev.targetId||'')===String(targetId||'')&&Math.abs(y-mid)<=band)return prev.position==='after'?'after':'before';return y<mid?'before':'after';}
function structureClearTargets(){document.querySelectorAll('.df-structure-drop-overlay').forEach(el=>el.remove());layoutCanvas?.querySelectorAll('.is-structure-before,.is-structure-after,.is-structure-inside,.is-section-drop-before,.is-section-drop-after,.is-row-drop-before,.is-row-drop-after').forEach(el=>el.classList.remove('is-structure-before','is-structure-after','is-structure-inside','is-section-drop-before','is-section-drop-after','is-row-drop-before','is-row-drop-after'));layoutCanvas?.querySelectorAll('[data-structure-drop-label]').forEach(el=>el.removeAttribute('data-structure-drop-label'));}
function structureSpecKey(spec){return spec?JSON.stringify(spec):'';}
function structureRenderTarget(spec){if(structureSpecKey(spec)===structureSpecKey(structureDrag.spec))return;structureClearTargets();structureDrag.spec=spec;if(!spec)return;
 if(spec.kind==='sectionMove'){
  const group=layoutCanvas?.querySelector(`.df-layout-section-group[data-section-id="${CSS.escape(spec.targetId)}"]`),head=group?.querySelector(':scope > .df-layout-section-head');if(head){const half=structureVerticalHalf(head.getBoundingClientRect(),spec.position);structureOverlayRect(half,spec.position==='before'?'SOPRA':'SOTTO','section',spec.position);}
 }else if(spec.kind==='row'){
  const group=spec.targetRowId?layoutCanvas?.querySelector(`.df-layout-row-group[data-row-id="${CSS.escape(String(spec.targetRowId))}"]`):layoutCanvas?.querySelector(`.df-layout-row-group[data-row-no="${Number(spec.targetRow)}"]`);if(group){const half=structureVerticalHalf(group.getBoundingClientRect(),spec.position);structureOverlayRect(half,spec.position==='before'?'SOPRA':'SOTTO','row',spec.position);}
 }else if(spec.kind==='section'){
  const head=layoutCanvas?.querySelector(`.df-layout-section-group[data-section-id="${CSS.escape(spec.sectionId)}"] > .df-layout-section-head`);if(head)structureOverlayRect(head.getBoundingClientRect(),'NELLA SEZIONE','inside');
 }
}

function structureGhost(label,type,x,y){const g=document.createElement('div');g.className='df-structure-drag-ghost';g.style.left='0px';g.style.top='0px';g.innerHTML=`<span class="df-layout-structure-handle">${modernUiIcon('grip')}</span><strong>${esc(label)}</strong><span>${type==='section'?'Sezione':'Riga'}</span>`;document.body.appendChild(g);structureDrag.ghost=g;const r=g.getBoundingClientRect();structureDrag.ghostWidth=Math.max(1,r.width);structureDrag.ghostHeight=Math.max(1,r.height);structurePositionGhost(x,y);}
function structurePositionGhost(x,y){const g=structureDrag.ghost;if(!g)return;const w=Math.max(1,Number(structureDrag.ghostWidth)||g.offsetWidth),h=Math.max(1,Number(structureDrag.ghostHeight)||g.offsetHeight),left=Math.min(Math.max(8,window.innerWidth-w-8),Math.max(8,x+14)),top=Math.min(Math.max(8,window.innerHeight-h-8),Math.max(8,y+14));g.style.transform=`translate3d(${Math.round(left)}px,${Math.round(top)}px,0)`;}
function structureRowDropSpec(group,y){if(!group)return null;const targetRow=Number(group.dataset.rowNo||0),targetRowId=String(group.dataset.rowId||'');if(!targetRow||!targetRowId||targetRowId===String(structureDrag.id||''))return null;const r=group.getBoundingClientRect(),position=structureVerticalPosition(structureDrag.spec,'row',targetRowId,y,r);return{kind:'row',targetRow,targetRowId,position};}
function structureFindTarget(x,y){
 if(structureDrag.type==='section'){
  let best=null,score=Infinity;
  for(const group of [...(layoutCanvas?.querySelectorAll('.df-layout-section-group')||[])]){
   const targetId=String(group.dataset.sectionId||'');if(!targetId||targetId===String(structureDrag.id||''))continue;const head=group.querySelector(':scope > .df-layout-section-head');if(!head)continue;const r=head.getBoundingClientRect();if(x<r.left-90||x>r.right+90)continue;const dy=y<r.top?r.top-y:y>r.bottom?y-r.bottom:0;if(dy>48)continue;const position=structureVerticalPosition(structureDrag.spec,'sectionMove',targetId,y,r),scoreNow=dy*dy;if(scoreNow<score){score=scoreNow;best={kind:'sectionMove',targetId,position};}
  }
  return best;
 }
 if(structureDrag.type==='row'){
  let best=null,score=Infinity;
  for(const group of [...(layoutCanvas?.querySelectorAll('.df-layout-row-group')||[])]){
   const targetRowId=String(group.dataset.rowId||'');if(!targetRowId||targetRowId===String(structureDrag.id||''))continue;const r=group.getBoundingClientRect();if(x<r.left-90||x>r.right+90)continue;const dy=y<r.top?r.top-y:y>r.bottom?y-r.bottom:0;if(dy>48)continue;const spec=structureRowDropSpec(group,y);if(!spec)continue;const scoreNow=dy*dy;if(scoreNow<score){score=scoreNow;best=spec;}
  }
  if(best)return best;
  let secBest=null,secScore=Infinity;
  for(const group of [...(layoutCanvas?.querySelectorAll('.df-layout-section-group')||[])]){
   const sectionId=String(group.dataset.sectionId||'');if(!sectionId)continue;const head=group.querySelector(':scope > .df-layout-section-head');if(!head)continue;const r=head.getBoundingClientRect();if(x<r.left-90||x>r.right+90)continue;const dy=y<r.top?r.top-y:y>r.bottom?y-r.bottom:0;if(dy>34)continue;const scoreNow=dy*dy;if(scoreNow<secScore){secScore=scoreNow;secBest={kind:'section',sectionId};}
  }
  return secBest;
 }
 return null;
}
function structureBegin(){const q=structureDrag.pending;if(editorLocked){clearTimeout(structureDrag.pressTimer);structureDrag.pressTimer=null;structureDrag.pending=null;return;}if(!q||structureDrag.active||!q.handle?.isConnected)return;structureDrag.active=true;structureDrag.pointerId=q.pointerId;structureDrag.type=q.type;structureDrag.id=q.id;structureDrag.handle=q.handle;structureDrag.lastX=q.x;structureDrag.lastY=q.y;structureDrag.queuedX=q.x;structureDrag.queuedY=q.y;structureDrag.pending=null;clearTimeout(structureDrag.pressTimer);structureDrag.pressTimer=null;structureGhost(q.label,q.type,q.x,q.y);document.body.classList.add('df-structure-drag-active');const source=q.handle.closest(q.type==='section'?'.df-layout-section-group':'.df-layout-row-group');source?.classList.add('is-structure-source');if(source)source.dataset.structureSourceType=q.type;if(q.pointerType!=='mouse'&&navigator.vibrate)try{navigator.vibrate(10);}catch{}}
function structureQueue(e,handle,type,id,label){if(editorLocked)return;if(e.button!=null&&e.button!==0)return;e.stopPropagation();const q={pointerId:e.pointerId,pointerType:e.pointerType||'mouse',type,id,handle,label,x:e.clientX,y:e.clientY};structureDrag.pending=q;structureDrag.lastX=e.clientX;structureDrag.lastY=e.clientY;clearTimeout(structureDrag.pressTimer);if(q.pointerType!=='mouse')structureDrag.pressTimer=setTimeout(()=>{if(structureDrag.pending===q&&!editorLocked)structureBegin();},300);}
function structureRunPointerFrame(){structureDrag.raf=0;if(!structureDrag.active)return;const x=structureDrag.queuedX,y=structureDrag.queuedY;structurePositionGhost(x,y);structureRenderTarget(structureFindTarget(x,y));}
function structureSchedulePointerFrame(x,y){structureDrag.queuedX=x;structureDrag.queuedY=y;if(!structureDrag.raf)structureDrag.raf=requestAnimationFrame(structureRunPointerFrame);}
function structureFlushPointerFrame(){if(!structureDrag.active)return;if(structureDrag.raf){cancelAnimationFrame(structureDrag.raf);structureDrag.raf=0;}structureRunPointerFrame();}
function structurePointerMove(e){const q=structureDrag.pending;if(q&&q.pointerId===e.pointerId&&!structureDrag.active){const d=Math.hypot(e.clientX-q.x,e.clientY-q.y);if(q.pointerType==='mouse'&&d>=4)structureBegin();else if(q.pointerType!=='mouse'&&d>12){clearTimeout(structureDrag.pressTimer);structureDrag.pressTimer=null;structureDrag.pending=null;}return;}if(!structureDrag.active||e.pointerId!==structureDrag.pointerId)return;e.preventDefault();structureDrag.lastX=e.clientX;structureDrag.lastY=e.clientY;structureSchedulePointerFrame(e.clientX,e.clientY);}
function structureFinish(e,cancel=false){if(structureDrag.pending&&e.pointerId===structureDrag.pending.pointerId){clearTimeout(structureDrag.pressTimer);structureDrag.pending=null;}if(!structureDrag.active||e.pointerId!==structureDrag.pointerId)return;if(e){structureDrag.lastX=e.clientX;structureDrag.lastY=e.clientY;structureDrag.queuedX=e.clientX;structureDrag.queuedY=e.clientY;}structureFlushPointerFrame();const type=structureDrag.type,id=structureDrag.id,spec=structureDrag.spec;structureDrag.ghost?.remove();structureDrag.ghost=null;structureClearTargets();layoutCanvas?.querySelectorAll('.is-structure-source').forEach(el=>{el.classList.remove('is-structure-source');el.removeAttribute('data-structure-source-type');});document.body.classList.remove('df-structure-drag-active');if(structureDrag.raf){cancelAnimationFrame(structureDrag.raf);structureDrag.raf=0;}structureDrag.active=false;structureDrag.pointerId=null;structureDrag.type='';structureDrag.id=null;structureDrag.spec=null;structureDrag.ghostWidth=0;structureDrag.ghostHeight=0;structureSuppressClickUntil=Date.now()+260;if(cancel||editorLocked||!spec)return;let changed=false;if(type==='section'&&spec.kind==='sectionMove')changed=structureMoveSection(id,spec.targetId,spec.position);if(type==='row'&&(spec.kind==='row'||spec.kind==='section'))changed=structureMoveRow(id,spec);if(changed){sync();renderSelected();renderLayoutCanvas();clearTimeout(historyTimer);pushHistory();}}
document.addEventListener('pointermove',structurePointerMove,{passive:false});document.addEventListener('pointerup',e=>structureFinish(e,false));document.addEventListener('pointercancel',e=>structureFinish(e,true));
/* End Forms 1.3.67 structure drag. */

function layoutGroups(){
 const rows=logicalRowNumbers().map(rowNo=>({rowNo,items:fieldsInRow(rowNo)}));
 const groups=[];let current={id:'general',sectionField:null,title:structureUi.general,rows:[]};
 rows.forEach(model=>{const marker=model.items.find(([f])=>isLayoutSectionField(f));if(marker){if(current.id==='general'||current.rows.length||current.sectionField)groups.push(current);const [sf,si]=marker;current={id:'section:'+sf.key,sectionField:marker,title:layoutSectionTitle(sf),rows:[]};const rest=model.items.filter(x=>x!==marker);if(rest.length)current.rows.push({rowNo:model.rowNo,items:rest});}else current.rows.push(model);});
 if(current.rows.length||current.sectionField||current.id==='general'||!groups.length)groups.push(current);
 if(!groups.some(g=>g.id==='general'))groups.unshift({id:'general',sectionField:null,title:structureUi.general,rows:[]});
 return groups;
}

function renderLayoutCanvas(){
 if(!layoutCanvas)return;normalizeLayoutRows();layoutCanvas.innerHTML='';
 const groups=layoutGroups();
 const toolbar=document.createElement('div');toolbar.className='df-layout-accordion-toolbar';toolbar.innerHTML=`<button type="button" class="df-btn df-small" data-layout-expand>${esc(structureUi.expandAll)}</button><button type="button" class="df-btn df-small" data-layout-collapse>${esc(structureUi.collapseAll)}</button>`;layoutCanvas.appendChild(toolbar);
 toolbar.querySelector('[data-layout-expand]').onclick=()=>{groups.forEach(g=>{layoutSectionState.set(g.id,true);g.rows.forEach(r=>layoutRowState.set(rowIdForRow(r.rowNo),true));});renderLayoutCanvas();};
 toolbar.querySelector('[data-layout-collapse]').onclick=()=>{groups.forEach(g=>{layoutSectionState.set(g.id,false);g.rows.forEach(r=>layoutRowState.set(rowIdForRow(r.rowNo),false));});renderLayoutCanvas();};
 groups.forEach((group,gi)=>{
  const activeInGroup=(group.sectionField?.[0]?.key===activeFieldKey)||group.rows.some(r=>r.items.some(([f])=>f.key===activeFieldKey)||activeStructureSelection?.type==='row'&&(activeStructureSelection.id?String(activeStructureSelection.id)===rowIdForRow(r.rowNo):Number(activeStructureSelection.row)===Number(r.rowNo)));const sectionOpen=layoutSectionState.has(group.id)?layoutSectionState.get(group.id):(activeInGroup||groups.length===1||(gi===0&&!activeFieldKey));
  const sectionSelected=!activeStructureSelection&&group.id!=='general'&&group.sectionField?.[0]?.key===activeFieldKey;const wrap=document.createElement('div');wrap.className='df-layout-section-group'+(group.id==='general'?' is-general':' is-section')+(sectionOpen?' is-open':'')+(sectionSelected?' is-selected':'');wrap.dataset.sectionId=group.id;
  const head=document.createElement('div');head.className='df-layout-section-head';head.setAttribute('role','button');head.tabIndex=0;const count=layoutFieldCount(group.rows),rowCount=group.rows.length;const sectionActions=group.sectionField?`<span class="df-layout-section-actions"><button type="button" data-section-edit class="df-icon-only" title="Modifica sezione" aria-label="Modifica sezione">${modernUiIcon('edit')}</button><button type="button" data-section-copy class="df-icon-only" title="Duplica sezione" aria-label="Duplica sezione">${modernUiIcon('copy')}</button><button type="button" data-section-remove class="df-icon-only" title="Elimina sezione" aria-label="Elimina sezione">${modernUiIcon('trash')}</button></span>`:'';
  const sectionDescription=group.sectionField?.[0]?.config?.content||'',sectionHandle=group.sectionField?`<span class="df-layout-structure-handle df-section-drag-handle" role="button" tabindex="0" title="Trascina sezione" aria-label="Trascina sezione">${modernUiIcon('grip')}</span>`:'',sectionLeading=group.id==='general'?'<span class="df-layout-general-grip-spacer" aria-hidden="true"></span><span class="df-layout-section-chevron">›</span>':`${sectionHandle}<span class="df-layout-section-chevron">›</span>`;head.innerHTML=`${sectionLeading}<span class="df-layout-section-title"><strong>${esc(group.title)}</strong>${sectionDescription?`<span class="df-layout-structure-description">${esc(sectionDescription)}</span>`:''}<span class="df-layout-section-summary">${count} ${esc(structureUi.fields)} · ${rowCount} ${esc(structureUi.rows)}</span></span>${sectionActions}`;if(group.sectionField){const handle=head.querySelector('.df-section-drag-handle');handle?.addEventListener('pointerdown',e=>structureQueue(e,handle,'section',group.id,group.title));handle?.addEventListener('click',e=>{e.stopPropagation();});head.addEventListener('pointerdown',e=>{if(e.target.closest('button,a,input,select,textarea,label,.df-layout-section-chevron,.df-layout-structure-handle'))return;structureQueue(e,head,'section',group.id,group.title);});}
  const toggleSection=()=>{layoutSectionState.set(group.id,!wrap.classList.contains('is-open'));renderLayoutCanvas();};head.addEventListener('click',e=>{if(Date.now()<structureSuppressClickUntil||e.target.closest('.df-layout-structure-handle'))return;if(e.target.closest('button'))return;if(group.sectionField){const [,si]=group.sectionField;selectField(si);}toggleSection();});head.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&!e.target.closest('button')){e.preventDefault();if(group.sectionField){const [,si]=group.sectionField;selectField(si);}toggleSection();}});
  if(group.sectionField){const [sf,si]=group.sectionField;head.querySelector('[data-section-edit]').onclick=e=>{e.stopPropagation();selectField(si);layoutSectionState.set(group.id,true);renderLayoutCanvas();};head.querySelector('[data-section-copy]').onclick=e=>{e.stopPropagation();duplicateLayoutSection(group.id);};head.querySelector('[data-section-remove]').onclick=e=>{e.stopPropagation();confirmDelete(`la sezione “${sf.label||structureUi.section}”`,()=>removeCanvasField(si));};}
  const targetRow=group.rows[0]?.rowNo||(group.sectionField?Number(group.sectionField[0].config.layout.row||1)+1:1);head.addEventListener('dragover',e=>{if(draggedFieldIndex==null)return;e.preventDefault();head.classList.add('is-over');});head.addEventListener('dragleave',()=>head.classList.remove('is-over'));head.addEventListener('drop',e=>{if(draggedFieldIndex==null)return;e.preventDefault();head.classList.remove('is-over');moveFieldToRow(draggedFieldIndex,targetRow);});
  const body=document.createElement('div');body.className='df-layout-section-body';
  if(!group.rows.length){const empty=document.createElement('div');empty.className='df-layout-section-empty';empty.textContent=group.id==='general'?'Nessun campo generale':'Sezione vuota';body.appendChild(empty);}
  group.rows.forEach((model,ri)=>{
   const rowId=rowIdForRow(model.rowNo),rowSelected=activeStructureSelection?.type==='row'&&(activeStructureSelection.id?String(activeStructureSelection.id)===rowId:Number(activeStructureSelection.row)===Number(model.rowNo)),rowActive=rowSelected||model.items.some(([f])=>f.key===activeFieldKey),rowOpen=layoutRowState.has(rowId)?layoutRowState.get(rowId):(rowActive||(sectionOpen&&group.rows.length===1));
   const rowGroup=document.createElement('div');rowGroup.className='df-layout-row-group'+(rowOpen?' is-open':'')+(rowSelected?' is-selected':'');rowGroup.dataset.rowNo=String(model.rowNo);rowGroup.dataset.rowId=rowId;
   const rowHead=document.createElement('div');rowHead.className='df-layout-row-head';rowHead.setAttribute('role','button');rowHead.tabIndex=0;
   const visualLines=visualLinesForItems(model.items),widths=visualLines.map(line=>line.map(([f])=>Number(f.config.layout.width||100)+'%').join(' + ')).join(' / '),meta=rowMeta(model.rowNo),rowTitle=rowDisplayTitle(model.rowNo),rowHasSection=fieldsInRow(model.rowNo).some(([f])=>isLayoutSectionField(f)),rowHandle=rowHasSection?'':`<span class="df-layout-structure-handle df-row-drag-handle" role="button" tabindex="0" title="Trascina riga" aria-label="Trascina riga">${modernUiIcon('grip')}</span>`,rowActions=rowHasSection?'':`<span class="df-layout-row-actions"><button type="button" data-row-edit class="df-icon-only" title="Modifica riga" aria-label="Modifica riga">${modernUiIcon('edit')}</button><button type="button" data-row-copy class="df-icon-only" title="Duplica riga" aria-label="Duplica riga">${modernUiIcon('copy')}</button><button type="button" data-row-remove class="df-icon-only df-row-remove" title="Elimina riga" aria-label="Elimina riga">${modernUiIcon('trash')}</button></span>`;
   const rowChevron=`<span class="df-layout-row-chevron">›</span>`;rowHead.innerHTML=`${rowHandle}${rowChevron}<span class="df-layout-row-label">${esc(rowTitle)}</span>${meta.description?`<span class="df-layout-structure-description">${esc(meta.description)}</span>`:''}<span class="df-layout-row-summary">${model.items.length} ${esc(structureUi.fields)} · ${esc(widths)}</span>${rowActions}`;
   const rowDragHandle=rowHead.querySelector('.df-row-drag-handle');rowDragHandle?.addEventListener('pointerdown',e=>structureQueue(e,rowDragHandle,'row',rowId,rowTitle));rowDragHandle?.addEventListener('click',e=>e.stopPropagation());rowHead.addEventListener('pointerdown',e=>{if(e.target.closest('button,a,input,select,textarea,label,.df-layout-row-chevron,.df-layout-structure-handle'))return;structureQueue(e,rowHead,'row',rowId,rowTitle);});rowHead.querySelector('[data-row-edit]')?.addEventListener('click',e=>{e.stopPropagation();selectRowSettings(model.rowNo);});rowHead.querySelector('[data-row-copy]')?.addEventListener('click',e=>{e.stopPropagation();duplicateLayoutRow(model.rowNo);});rowHead.querySelector('[data-row-remove]')?.addEventListener('click',e=>{e.stopPropagation();requestRemoveLayoutRow(model.rowNo);});
   const activateRowAndToggle=()=>{const open=!rowGroup.classList.contains('is-open');activeFieldKey=null;activeStructureSelection={type:'row',id:rowId,row:model.rowNo};layoutRowState.set(rowId,open);renderSelected();renderLayoutCanvas();};rowHead.onclick=e=>{if(Date.now()<structureSuppressClickUntil||e.target.closest('.df-layout-structure-handle')||e.target.closest('button'))return;activateRowAndToggle();};rowHead.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activateRowAndToggle();}};
   rowHead.addEventListener('dragover',e=>{if(draggedFieldIndex==null)return;e.preventDefault();rowHead.classList.add('is-over');});rowHead.addEventListener('dragleave',()=>rowHead.classList.remove('is-over'));rowHead.addEventListener('drop',e=>{if(draggedFieldIndex==null)return;e.preventDefault();rowHead.classList.remove('is-over');moveFieldToRow(draggedFieldIndex,model.rowNo);});
   const rowBody=document.createElement('div');rowBody.className='df-layout-row-body';
   visualLines.forEach((line,lineIndex)=>{const row=document.createElement('div');row.className='df-layout-row';row.dataset.row=String(model.rowNo);row.dataset.line=String(lineIndex+1);const parts=[];line.forEach(([f,i])=>{const before=smartOffsetBefore(f),after=smartOffsetAfter(f);if(before>0)parts.push({slot:true,width:before,side:'before',targetKey:f.key});parts.push({slot:false,width:Math.max(1,Number(f.config.layout.width||100)),f,i});if(after>0)parts.push({slot:true,width:after,side:'after',targetKey:f.key});});row.style.gridTemplateColumns=parts.map(part=>Math.max(1,Number(part.width||1))+'fr').join(' ');parts.forEach(part=>{if(part.slot){const slot=document.createElement('div');slot.className='df-layout-empty-slot';slot.dataset.slotTargetKey=part.targetKey||'';slot.dataset.slotSide=part.side||'before';slot.setAttribute('role','button');slot.tabIndex=0;slot.setAttribute('aria-label','Spazio vuoto '+Math.round(part.width)+'%. Trascina qui un campo.');slot.innerHTML='<span>VUOTO '+Math.round(part.width)+'%</span>';row.appendChild(slot);}else renderLayoutFieldCard(part.f,part.i,model.rowNo,row);});row.addEventListener('dragover',e=>{if(e.target.closest('.df-layout-card'))return;e.preventDefault();row.classList.add('is-over');});row.addEventListener('dragleave',e=>{if(!row.contains(e.relatedTarget))row.classList.remove('is-over');});row.addEventListener('drop',e=>{if(e.target.closest('.df-layout-card'))return;e.preventDefault();row.classList.remove('is-over');moveFieldToRow(draggedFieldIndex,model.rowNo);});rowBody.appendChild(row);});
   rowGroup.append(rowHead,rowBody);body.appendChild(rowGroup);
  });
  wrap.append(head,body);layoutCanvas.appendChild(wrap);
 });sync();
}
function ensureInitialFieldWorkspace(){
  if(!selected.length)return;
  renderSelected();
  renderLayoutCanvas();
  const verify=()=>{
    if(selected.length&&layoutCanvas&&!layoutCanvas.querySelector('.df-layout-card')){
      renderSelected();
      renderLayoutCanvas();
    }
  };
  requestAnimationFrame(()=>{verify();setTimeout(verify,60);});
}
window.dfBuilderEnsureRender=ensureInitialFieldWorkspace;
ensureInitialFieldWorkspace();
layoutNewRow?.addEventListener('dragover',e=>{e.preventDefault();layoutNewRow.classList.add('is-over');});layoutNewRow?.addEventListener('dragleave',()=>layoutNewRow.classList.remove('is-over'));layoutNewRow?.addEventListener('drop',e=>{e.preventDefault();layoutNewRow.classList.remove('is-over');const max=Math.max(0,...logicalRowNumbers());moveFieldToRow(draggedFieldIndex,max+1);});
document.getElementById('df-open-library')?.addEventListener('click',()=>openBuilderSection(3,true));
function renderLayout(){builderConfig=builderConfig&&typeof builderConfig==='object'?builderConfig:{};builderConfig.layout={columns:1,widths:[100],mobile_stack:true,...(builderConfig.layout||{})};let n=Math.max(1,Math.min(4,Number(builderConfig.layout.columns||1)));builderConfig.layout.columns=n;layoutColumns.value=String(n);mobileStack.checked=builderConfig.layout.mobile_stack!==false;let widths=Array.isArray(builderConfig.layout.widths)?builderConfig.layout.widths.slice(0,n).map(Number):[];while(widths.length<n)widths.push(Math.floor(100/n));if(n===1)widths=[100];builderConfig.layout.widths=widths;layoutWidths.innerHTML='';for(let i=0;i<4;i++){const w=document.createElement('div');w.className='df-field';if(i>=n)w.hidden=true;w.innerHTML=`<label>Colonna ${i+1}</label><input type="number" min="0" max="100" data-width="${i}" value="${esc(widths[i]??0)}">`;w.querySelector('input').addEventListener('input',e=>{builderConfig.layout.widths[i]=Number(e.target.value||0);renderLayoutTotal();sync();});layoutWidths.appendChild(w);}renderLayoutTotal();renderLayoutCanvas();sync();}
function renderLayoutTotal(){const total=(builderConfig.layout.widths||[]).slice(0,builderConfig.layout.columns).reduce((a,b)=>a+Number(b||0),0);layoutTotal.textContent=`Totale: ${total}%`;layoutTotal.classList.toggle('is-ok',total===100);layoutTotal.classList.toggle('is-error',total!==100);}
layoutColumns.addEventListener('change',()=>{builderConfig.layout.columns=Number(layoutColumns.value);builderConfig.layout.widths=Array.from({length:builderConfig.layout.columns},(_,i)=>builderConfig.layout.widths?.[i]??Math.floor(100/builderConfig.layout.columns));if(builderConfig.layout.columns===1)builderConfig.layout.widths=[100];renderLayout();});mobileStack.addEventListener('change',()=>{builderConfig.layout.mobile_stack=mobileStack.checked;sync();});document.querySelectorAll('[data-layout-preset]').forEach(b=>b.addEventListener('click',()=>{const w=b.dataset.layoutPreset.split(',').map(Number);builderConfig.layout.columns=w.length;builderConfig.layout.widths=w;renderLayout();}));document.getElementById('df-layout-apply').addEventListener('click',e=>{const widths=builderConfig.layout.widths.slice(0,builderConfig.layout.columns);selected.forEach((f,i)=>{defaultFieldConfig(f);const col=(i%builderConfig.layout.columns)+1,row=Math.floor(i/builderConfig.layout.columns)+1;f.config.layout={row,col,width:widths[col-1]||100};});renderSelected();renderLayoutCanvas();sync();const btn=e.currentTarget,old=btn.textContent;btn.textContent=selected.length?`✓ Applicato a ${selected.length} camp${selected.length===1?'o':'i'}`:'Nessun campo selezionato';setTimeout(()=>btn.textContent=old,1600);});

// Statuses and columns.
function slugStatus(v){return String(v||'status').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,30)||'status';}const statusPalette=['#0d6efd','#f59e0b','#198754','#6c757d','#dc3545','#7c3aed','#0891b2'];
function normalizedStatusLabel(v){return String(v||'').trim().toLocaleLowerCase();}
function statusConflicts(){const seen=new Set(),dupes=new Set();statuses.forEach(st=>{const n=normalizedStatusLabel(st.label);if(!n)return;if(seen.has(n))dupes.add(n);seen.add(n);});return dupes;}
function renderStatuses(){statusEditor.innerHTML='';const dupes=statusConflicts();if(dupes.size){const warning=document.createElement('div');warning.className='df-status-warning';warning.textContent='Esistono stati con lo stesso nome. Rinominali prima di salvare.';statusEditor.appendChild(warning);}statuses.forEach((st,i)=>{st.color=/^#[0-9a-fA-F]{6}$/.test(st.color||'')?st.color:statusPalette[i%statusPalette.length];const r=document.createElement('div');r.className='df-status-row'+(dupes.has(normalizedStatusLabel(st.label))?' is-conflict':'');r.innerHTML=`<input data-status-label value="${esc(st.label||'')}" placeholder="Nome stato"><div class="df-status-color-wrap"><input class="df-status-color" data-status-color type="color" value="${esc(st.color)}"><span class="df-status-color-value">${esc(st.color)}</span></div><button type="button" class="df-status-remove df-icon-only" title="Elimina stato" aria-label="Elimina stato">${modernUiIcon('trash')}</button>`;const li=r.querySelector('[data-status-label]'),ci=r.querySelector('[data-status-color]');li.oninput=()=>{st.label=li.value;if(st._new)st.key=slugStatus(li.value);sync();};li.onblur=renderStatuses;ci.oninput=()=>{st.color=ci.value.toLowerCase();r.querySelector('.df-status-color-value').textContent=st.color;sync();};r.querySelector('button').onclick=()=>{if(statuses.length>1)confirmDelete(`lo stato “${st.label||'Stato'}”`,()=>{statuses.splice(i,1);renderStatuses();});};statusEditor.appendChild(r);});sync();}
document.getElementById('df-add-status').onclick=()=>{statuses.push({key:'',label:'',color:statusPalette[statuses.length%statusPalette.length],_new:true});renderStatuses();statusEditor.querySelector('.df-status-row:last-child [data-status-label]')?.focus();};renderStatuses();
function columnItems(){return [['_reference','<?php echo addslashes(Text::_('COM_DECAROFORMS_REFERENCE')); ?>'],['_email','<?php echo addslashes(Text::_('COM_DECAROFORMS_EMAIL')); ?>'],['_status','<?php echo addslashes(Text::_('COM_DECAROFORMS_STATUS')); ?>'],['_created_at','<?php echo addslashes(Text::_('COM_DECAROFORMS_DATE')); ?>'],['_payment','<?php echo addslashes(Text::_('COM_DECAROFORMS_PAYMENT')); ?>'],...selected.filter(x=>!['separator','pagebreak','page','heading','info','fieldset'].includes(x.type)).map(x=>[x.key,x.label])];}
function renderColumns(){const items=columnItems();columns=columns.filter(k=>items.some(i=>i[0]===k));if(!columns.length)columns=['_reference','_email','_status','_created_at'];columnList.innerHTML='';items.forEach(([key,label])=>{const d=document.createElement('label');d.className='df-column-item';d.innerHTML=`<input type="checkbox" ${columns.includes(key)?'checked':''}><span>${esc(label)}</span>`;d.querySelector('input').onchange=e=>{if(e.target.checked){if(!columns.includes(key))columns.push(key);}else columns=columns.filter(x=>x!==key);sync();};columnList.appendChild(d);});sync();}
document.getElementById('df-columns-all').onclick=()=>{columns=columnItems().map(i=>i[0]);renderColumns();};document.getElementById('df-columns-reset').onclick=()=>{columns=['_reference','_email','_status','_created_at'];renderColumns();};renderColumns();



document.addEventListener('click',e=>{const link=e.target.closest('[data-confirm-delete-link]');if(!link)return;e.preventDefault();e.stopPropagation();const href=link.href;confirmDelete('questo modulo',()=>{window.dfAllowDraftReload=true;location.assign(href);});});
document.addEventListener('click',e=>{const btn=e.target.closest('.df-info');if(btn){e.preventDefault();e.stopPropagation();const wrap=btn.closest('.df-info-wrap');document.querySelectorAll('.df-info-wrap.is-open').forEach(x=>{if(x!==wrap)x.classList.remove('is-open');});wrap?.classList.toggle('is-open');return;}if(!e.target.closest('.df-info-wrap'))document.querySelectorAll('.df-info-wrap.is-open').forEach(x=>x.classList.remove('is-open'));});document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.df-info-wrap.is-open').forEach(x=>x.classList.remove('is-open'));});

// Email configuration and previews.
let lastTokenTarget=null,lastTokenEditorId=null;document.querySelectorAll('[data-email]').forEach(el=>{const path=el.dataset.email;el.addEventListener('focus',()=>{lastTokenTarget=el;lastTokenEditorId=null;});const ev=el.tagName==='SELECT'?'change':'input';el.addEventListener(ev,()=>{setDeep(emailConfig,path,el.value);sync();});});document.querySelectorAll('[data-email-check]').forEach(el=>el.addEventListener('change',()=>{setDeep(emailConfig,el.dataset.emailCheck,el.checked);sync();}));
const userConfirmation=document.getElementById('df-user-confirmation');userConfirmation.addEventListener('change',()=>{emailConfig.user.enabled=userConfirmation.checked;document.getElementById('df-user-email-settings').hidden=!userConfirmation.checked;sync();});
function renderUserEmailFields(){const s=document.getElementById('df-user-email-field'),emails=selected.filter(x=>x.type==='email'||x.key==='email');const current=emailConfig.user.to_field||emails[0]?.key||'email';s.innerHTML=emails.map(x=>`<option value="${esc(x.key)}" ${x.key===current?'selected':''}>${esc(x.label)}</option>`).join('')||'<option value="email">Email</option>';emailConfig.user.to_field=s.value||current;s.onchange=()=>{emailConfig.user.to_field=s.value;sync();};document.getElementById('df-user-email-settings').hidden=!userConfirmation.checked;sync();}
function renderTokens(){const p=document.getElementById('df-token-picker');const base=[['{form_title}','Titolo modulo'],['{form_id}','ID modulo'],['{reference}','Riferimento invio'],['{riferimento}','Riferimento pagamento'],['{data}','Data'],['{anno}','Anno'],['{all_fields}','Tutti i campi']];p.innerHTML=[...base,...selected.map(x=>[`{${x.key}}`,x.label])].map(([v,l])=>`<option value="${esc(v)}">${esc(l)} — ${esc(v)}</option>`).join('');}
document.getElementById('df-token-insert').onclick=()=>{const token=document.getElementById('df-token-picker').value;if(lastTokenEditorId){const instance=window.Joomla?.editors?.instances?.[lastTokenEditorId];if(instance&&typeof instance.replaceSelection==='function'){instance.replaceSelection(token);document.getElementById(lastTokenEditorId)?.dispatchEvent(new Event('change',{bubbles:true}));return;}}if(!lastTokenTarget)return;const start=lastTokenTarget.selectionStart??lastTokenTarget.value.length,end=lastTokenTarget.selectionEnd??start;lastTokenTarget.value=lastTokenTarget.value.slice(0,start)+token+lastTokenTarget.value.slice(end);lastTokenTarget.dispatchEvent(new Event('input',{bubbles:true}));lastTokenTarget.focus();};
function sanitizeEmailPreviewHtml(html){
  const doc=new DOMParser().parseFromString(String(html||''),'text/html');
  doc.querySelectorAll('script,object,embed').forEach(el=>el.remove());
  doc.querySelectorAll('*').forEach(el=>{
    [...el.attributes].forEach(attr=>{
      const name=String(attr.name||'').toLowerCase(),value=String(attr.value||'').trim();
      if(name.startsWith('on')){el.removeAttribute(attr.name);return;}
      if(['href','src','xlink:href','formaction'].includes(name)&&/^javascript:/i.test(value))el.removeAttribute(attr.name);
    });
  });
  return '<!doctype html><html>'+doc.documentElement.innerHTML+'</html>';
}
function renderEmailPickers(loadFrames=emailPickersRendered){document.querySelectorAll('[data-email-picker]').forEach(box=>{const audience=box.dataset.emailPicker,config=emailConfig[audience];box.innerHTML='';templateDefs.forEach(([key,label])=>{const card=document.createElement('div'),special=['custom','html','chatgpt'].includes(key);card.className='df-email-choice'+((config.template||'standard')===key?' is-active':'');card.dataset.special=special?'1':'0';card.dataset.template=key;card.innerHTML=`<button type="button" class="df-email-thumb" title="Apri anteprima" aria-label="Apri anteprima: ${esc(label)}"><iframe class="df-email-thumb-frame" title="" tabindex="-1" sandbox="allow-scripts"></iframe><span class="df-email-preview-label" aria-hidden="true">◉ Anteprima</span></button><div class="df-email-choice-foot"><label class="df-email-radio"><input type="radio" name="df-email-template-${audience}" value="${key}" ${(config.template||'standard')===key?'checked':''}><span>${esc(label)}</span></label><button type="button" class="df-email-preview-btn">◉ Anteprima</button></div>`;const openPreview=e=>{e.preventDefault();e.stopPropagation();showEmailPreview(audience,key);};card.querySelector('.df-email-thumb').onclick=openPreview;card.querySelector('.df-email-preview-btn').onclick=openPreview;card.querySelector('input').onchange=()=>{config.template=key;renderEmailPickers(emailPickersRendered);renderEmailSpecial(audience);sync();};box.appendChild(card);const frame=card.querySelector('iframe');if(loadFrames)requestAnimationFrame(()=>{try{frame.srcdoc=sanitizeEmailPreviewHtml(emailPreviewHtml(audience,key));}catch{frame.srcdoc='<div style="font-family:Arial;padding:20px">Anteprima non disponibile</div>';}});else frame.srcdoc='<div style="font-family:Arial;padding:18px;color:#667085">Anteprima</div>';});renderEmailSpecial(audience);});}
function emailEditorPool(){return document.querySelector('[data-email-editor-pool]');}
function detachEmailEditorHost(audience){const pool=emailEditorPool(),host=document.querySelector(`[data-email-editor-host="${audience}"]`);if(!host)return null;const source=host.querySelector('textarea[id]');if(lastTokenEditorId&&source?.id===lastTokenEditorId){lastTokenEditorId=null;lastTokenTarget=null;}if(pool&&host.parentElement!==pool)pool.appendChild(host);host.hidden=true;return host;}
function bindEmailEditorHost(audience,host){if(!host)return null;window.Joomla?.XdecaroEditor?.scan?.(host);const source=host.querySelector('textarea[id]');if(!source)return null;if(source.dataset.dfFormsEmailEditorBound!=='1'){source.dataset.dfFormsEmailEditorBound='1';source.addEventListener('change',()=>{if(emailConfig[audience])emailConfig[audience].html=source.value;sync();});host.addEventListener('focusin',()=>{lastTokenTarget=source;lastTokenEditorId=source.id;});}return source;}
function showEmailEditorHost(audience,box,cfg){const host=detachEmailEditorHost(audience);if(!host)return false;box.innerHTML=`<label class="df-label">HTML libero</label><div class="df-note"><?php echo addslashes(Text::_('COM_DECAROFORMS_HTML_VARIABLE_NOTE')); ?></div>`;box.appendChild(host);host.hidden=false;const source=bindEmailEditorHost(audience,host);if(!source){detachEmailEditorHost(audience);return false;}const value=String(cfg.html||'');const instance=window.Joomla?.editors?.instances?.[source.id];if(instance&&typeof instance.setValue==='function')instance.setValue(value);else source.value=value;return true;}
window.dfFormsFlushEmailEditors=()=>{document.querySelectorAll('[data-email-editor-host] textarea[id]').forEach(source=>{const instance=window.Joomla?.editors?.instances?.[source.id];if(instance&&typeof instance.onSave==='function')instance.onSave();const host=source.closest('[data-email-editor-host]'),audience=host?.dataset.emailEditorHost;if(audience&&emailConfig[audience])emailConfig[audience].html=source.value;});if(typeof window.dfBuilderSync==='function')window.dfBuilderSync();};
function renderEmailSpecial(audience){const box=document.querySelector(`[data-email-special="${audience}"]`),cfg=emailConfig[audience],t=cfg.template||'standard';detachEmailEditorHost(audience);box.hidden=!['custom','html','chatgpt'].includes(t);if(box.hidden){box.innerHTML='';return;}if(t==='custom'){const c=cfg.custom||{};box.innerHTML=`<div class="df-grid"><div class="df-field"><label><?php echo addslashes(Text::_('COM_DECAROFORMS_BASE_TEMPLATE')); ?></label><select data-special="base">${templateDefs.slice(0,7).map(([k,l])=>`<option value="${k}" ${(c.base||'standard')===k?'selected':''}>${esc(l)}</option>`).join('')}</select></div><div class="df-field"><label><?php echo addslashes(Text::_('COM_DECAROFORMS_RADIUS')); ?> px</label><input type="number" min="0" max="40" data-special="radius" value="${esc(c.radius??8)}"></div>${[['primary','<?php echo addslashes(Text::_('COM_DECAROFORMS_PRIMARY_COLOR')); ?>'],['secondary','<?php echo addslashes(Text::_('COM_DECAROFORMS_SECONDARY_COLOR')); ?>'],['background','<?php echo addslashes(Text::_('COM_DECAROFORMS_BACKGROUND_COLOR')); ?>'],['text','<?php echo addslashes(Text::_('COM_DECAROFORMS_TEXT_COLOR')); ?>'],['button','<?php echo addslashes(Text::_('COM_DECAROFORMS_BUTTON_COLOR')); ?>'],['border','<?php echo addslashes(Text::_('COM_DECAROFORMS_BORDER_COLOR')); ?>']].map(([k,l])=>`<div class="df-field"><label>${l}</label><input type="color" data-special="${k}" value="${esc(c[k]||'#e60046')}"></div>`).join('')}</div><button class="df-btn df-small" type="button" data-reset-colors><?php echo addslashes(Text::_('COM_DECAROFORMS_RESET_COLORS')); ?></button>`;box.querySelectorAll('[data-special]').forEach(el=>el.oninput=()=>{cfg.custom=cfg.custom||{};cfg.custom[el.dataset.special]=el.type==='number'?Number(el.value):el.value;sync();});box.querySelector('[data-reset-colors]').onclick=()=>{cfg.custom={base:'standard',primary:'#e60046',secondary:'#26364a',background:'#ffffff',text:'#20262d',button:'#e60046',border:'#dfe3e7',radius:8};renderEmailSpecial(audience);sync();};}
if(t==='html'){if(!showEmailEditorHost(audience,box,cfg)){box.innerHTML=`<label class="df-label">HTML libero</label><textarea class="df-codearea" data-email-html placeholder="<div>...</div>">${esc(cfg.html||'')}</textarea><div class="df-note"><?php echo addslashes(Text::_('COM_DECAROFORMS_HTML_VARIABLE_NOTE')); ?></div>`;box.querySelector('[data-email-html]').oninput=e=>{cfg.html=e.target.value;lastTokenTarget=e.target;lastTokenEditorId=null;sync();};box.querySelector('[data-email-html]').onfocus=e=>{lastTokenTarget=e.target;lastTokenEditorId=null;};}}
if(t==='chatgpt'){box.innerHTML=`<div class="df-field"><label><?php echo addslashes(Text::_('COM_DECAROFORMS_CHATGPT_INSTRUCTIONS')); ?></label><textarea data-chatgpt-instructions placeholder="<?php echo addslashes(Text::_('COM_DECAROFORMS_CHATGPT_PLACEHOLDER')); ?>">${esc(cfg.chatgpt_instructions||'')}</textarea></div><div class="df-inline"><button class="df-btn df-small" type="button" data-copy-chatgpt>${esc(tr.copyPrompt)}</button><span class="df-note" data-copy-status></span></div><div class="df-field" style="margin-top:10px"><label><?php echo addslashes(Text::_('COM_DECAROFORMS_CHATGPT_HTML_RESULT')); ?></label><textarea class="df-codearea" data-chatgpt-html placeholder="<?php echo addslashes(Text::_('COM_DECAROFORMS_CHATGPT_PASTE_HTML')); ?>">${esc(cfg.html||'')}</textarea></div>`;box.querySelector('[data-chatgpt-instructions]').oninput=e=>{cfg.chatgpt_instructions=e.target.value;sync();};box.querySelector('[data-chatgpt-html]').oninput=e=>{cfg.html=e.target.value;lastTokenTarget=e.target;lastTokenEditorId=null;sync();};box.querySelector('[data-chatgpt-html]').onfocus=e=>{lastTokenTarget=e.target;lastTokenEditorId=null;};box.querySelector('[data-copy-chatgpt]').onclick=async()=>{const prompt=buildChatGptPrompt(audience);try{await navigator.clipboard.writeText(prompt);box.querySelector('[data-copy-status]').textContent=tr.copied;}catch{box.querySelector('[data-copy-status]').textContent=prompt;}};}}
function buildChatGptPrompt(audience){const title=document.querySelector('[name="title"]')?.value||'Modulo';const cfg=emailConfig[audience];return `Crea un template HTML email responsive per il modulo "${title}".\nDestinatario: ${audience==='admin'?'amministrazione':'utente'}.\nIstruzioni: ${cfg.chatgpt_instructions||'Stile professionale, accessibile e compatibile con client email.'}\n\nCampi del modulo:\n${selected.map(x=>`- ${x.label}: {${x.key}} (${x.type})`).join('\n')}\n\nVariabili di sistema: {form_title}, {form_id}, {reference}, {riferimento}, {data}, {anno}, {all_fields}.\nRestituisci solo HTML inline-CSS, senza script e senza dati personali reali.`;}
function exampleValue(f){const map={first_name:'Mario',last_name:'Rossi',full_name:'Mario Rossi',email:'mario.rossi@example.com',phone:'+39 333 123 4567',mobile:'+39 333 123 4567',city:'Roma',region:'Lazio',postcode:'00100',nationality:'Italiana',member_number:'001234',role:'Consigliere'};return map[f.key]||f.options?.[0]||(['file','upload'].includes(f.type)?'documento.pdf':f.type==='date'?'04/09/2026':f.type==='number'?'1':'Esempio');}
function previewRows(){return selected.filter(f=>!['separator','pagebreak','page','heading','info','fieldset'].includes(f.type)).map(f=>`<tr><td style="padding:7px 9px;border-bottom:1px solid #e8ebef;font-weight:700;vertical-align:top">${esc(f.label)}</td><td style="padding:7px 9px;border-bottom:1px solid #e8ebef">${esc(exampleValue(f))}</td></tr>`).join('');}
function emailPreviewHtml(audience,template){const cfg=emailConfig[audience],title=document.querySelector('[name="title"]')?.value||'Modulo',subject=(cfg.subject|| (audience==='user'?'Abbiamo ricevuto il tuo invio – {form_title}':'Nuovo invio – {form_title}')).replaceAll('{form_title}',title),rows=`<table role="presentation" style="width:100%;border-collapse:collapse">${previewRows()}</table>`,intro=audience==='user'?`<p>Abbiamo ricevuto correttamente il tuo invio.</p>`:`<p>È stato ricevuto un nuovo invio.</p>`,content=`<h2 style="margin:0 0 6px">${esc(title)}</h2><p style="margin:0 0 14px;color:#667085">Riferimento: <strong>FRM-20260904-DEMO</strong></p>${intro}${rows}`,accent='#e60046';if(template==='html'||template==='chatgpt'){return cfg.html||`<div style="background:#fff;padding:22px;font-family:Arial">${content}</div>`;}if(template==='custom'){const c=cfg.custom||{},base=c.base||'standard';const inner=emailPreviewHtml(audience,base);return `<div style="background:${esc(c.background||'#fff')};color:${esc(c.text||'#20262d')};border:1px solid ${esc(c.border||'#dfe3e7')};border-radius:${Number(c.radius||8)}px;overflow:hidden"><div style="height:8px;background:${esc(c.primary||accent)}"></div>${inner}</div>`;}if(template==='minimal')return `<div style="font-family:Arial;background:#fff;padding:24px;color:#20262d">${content}</div>`;if(template==='institutional')return `<div style="font-family:Arial;background:#fff"><div style="background:#26364a;color:#fff;padding:15px 20px;font-weight:800">${esc(subject)}</div><div style="padding:22px">${content}</div></div>`;if(template==='card')return `<div style="font-family:Arial;padding:24px;background:#f2f4f7"><div style="background:#fff;border-radius:10px;padding:22px;box-shadow:0 4px 18px rgba(0,0,0,.1)">${content}</div></div>`;if(template==='compact')return `<div style="font-family:Arial;background:#fff;border-left:5px solid ${accent};padding:18px 20px">${content}</div>`;if(template==='modern')return `<div style="font-family:Arial;background:linear-gradient(135deg,#f7f8fa,#fff);padding:24px"><div style="background:#fff;border-radius:14px;padding:24px"><div style="width:54px;height:5px;background:${accent};border-radius:999px;margin-bottom:17px"></div>${content}</div></div>`;if(template==='elegant')return `<div style="font-family:Georgia,serif;background:#fbfaf7;border:1px solid #d8ccb0;padding:28px;color:#2d2922"><div style="text-align:center;letter-spacing:.08em;margin-bottom:18px">${esc(subject)}</div>${content}</div>`;if(template==='professional')return `<div style="font-family:Arial;background:#eef2f7;padding:24px"><div style="background:#fff;border-top:7px solid #26364a;padding:24px;box-shadow:0 3px 12px rgba(15,23,42,.08)"><div style="color:#26364a;font-size:12px;text-transform:uppercase;letter-spacing:.08em;margin-bottom:14px">${esc(subject)}</div>${content}</div></div>`;if(template==='receipt')return `<div style="font-family:ui-monospace,monospace;background:#fff;padding:22px;border:1px dashed #aab2bc"><strong>${esc(subject)}</strong><hr style="border:0;border-top:1px dashed #aab2bc;margin:14px 0">${content}</div>`;return `<div style="font-family:Arial;background:#f4f5f7;padding:22px"><div style="background:#fff"><div style="background:${accent};color:#fff;padding:16px 20px;font-weight:800">${esc(subject)}</div><div style="padding:22px">${content}</div></div></div>`;}
let previewModal=null;function closeEmailPreview(){if(!previewModal)return;previewModal.remove();previewModal=null;document.body.style.overflow='';}function showEmailPreview(audience,template){closeEmailPreview();let html='';try{html=emailPreviewHtml(audience,template);}catch(err){console.error('Forms email preview error',err);html='<div style="background:#fff;color:#1f2937;padding:24px;font-family:Arial,sans-serif"><h2 style="margin-top:0">Anteprima email</h2><p>Impossibile generare i dati di esempio.</p></div>';}const label=templateDefs.find(x=>x[0]===template)?.[1]||template;previewModal=document.createElement('div');previewModal.className='df-live-preview-modal';previewModal.innerHTML=`<div class="df-live-preview-backdrop"></div><div class="df-live-preview-dialog" role="dialog" aria-modal="true" aria-label="Anteprima ${esc(label)}"><div class="df-live-preview-head"><div><strong>${esc(label)}</strong><div class="df-note">${audience==='admin'?'Email amministrazione':'Email utente'}</div></div><button type="button" class="df-live-preview-close" aria-label="Chiudi">×</button></div><div class="df-live-preview-body">${html}</div><div class="df-live-preview-foot"><button type="button" class="df-btn df-live-preview-close">Chiudi</button></div></div>`;document.body.appendChild(previewModal);document.body.style.overflow='hidden';previewModal.querySelectorAll('.df-live-preview-close,.df-live-preview-backdrop').forEach(el=>el.addEventListener('click',closeEmailPreview));requestAnimationFrame(()=>previewModal.querySelector('.df-live-preview-close')?.focus());}document.addEventListener('keydown',e=>{if(e.key==='Escape'&&previewModal)closeEmailPreview();});

// Additional emails.
function newAdditional(){return {name:'',enabled:true,to:'',reply_to:'',reply_name:'',cc:'',bcc:'',subject:'Nuovo invio – {form_title}',template:'standard',html:'',auto_message:true,attach_uploads:false,condition:{field:'',operator:'eq',value:''}};}
function renderAdditional(){const box=document.getElementById('df-additional-list');box.innerHTML='';if(!additionalEmails.length){box.innerHTML=`<div class="df-note">${esc(tr.noAdditional)}</div>`;sync();return;}additionalEmails.forEach((m,i)=>{m.condition=m.condition||{field:'',operator:'eq',value:''};const d=document.createElement('div');d.className='df-additional-card';d.innerHTML=`<div class="df-additional-head"><strong>${esc(m.name||`${tr.newEmail} #${i+1}`)}</strong><div class="df-inline"><label class="df-check"><input type="checkbox" data-a-enabled ${m.enabled!==false?'checked':''}> Attiva</label><button class="df-btn df-small" type="button" data-a-remove>${esc(tr.remove)}</button></div></div><div class="df-additional-grid"><div class="df-field"><label>${esc(tr.emailName)}</label><input data-a="name" value="${esc(m.name||'')}"></div><div class="df-field"><label>To</label><input data-a="to" value="${esc(m.to||'')}"></div><div class="df-field"><label>Reply-To</label><input data-a="reply_to" value="${esc(m.reply_to||'')}"></div><div class="df-field"><label>CC / BCC</label><input data-a="cc" value="${esc(m.cc||'')}" placeholder="CC"><input data-a="bcc" value="${esc(m.bcc||'')}" placeholder="BCC" style="margin-top:5px"></div><div class="df-field full"><label><?php echo addslashes(Text::_('COM_DECAROFORMS_EMAIL_SUBJECT')); ?></label><input data-a="subject" value="${esc(m.subject||'')}"></div><div class="df-field"><label>${esc(tr.template)}</label><select data-a="template">${templateDefs.map(([k,l])=>`<option value="${k}" ${m.template===k?'selected':''}>${esc(l)}</option>`).join('')}</select></div><div class="df-field"><label class="df-check"><input type="checkbox" data-a-check="attach_uploads" ${m.attach_uploads?'checked':''}> <?php echo addslashes(Text::_('COM_DECAROFORMS_ATTACH_UPLOADS')); ?></label></div><div class="df-field full"><label>${esc(tr.condition)}</label><div class="df-condition-row"><select data-a-cond="field"><option value="">Sempre</option>${fieldSelectOptions(m.condition.field||'')}</select><select data-a-cond="operator"><option value="eq" ${m.condition.operator==='eq'?'selected':''}>=</option><option value="neq" ${m.condition.operator==='neq'?'selected':''}>≠</option><option value="contains" ${m.condition.operator==='contains'?'selected':''}>contiene</option><option value="not_empty" ${m.condition.operator==='not_empty'?'selected':''}>non vuoto</option></select><input data-a-cond="value" value="${esc(m.condition.value||'')}" placeholder="Valore"><span></span></div></div>${['html','chatgpt'].includes(m.template)?`<div class="df-field full"><label>HTML</label><textarea class="df-codearea" data-a="html">${esc(m.html||'')}</textarea></div>`:''}</div>`;d.querySelector('[data-a-enabled]').onchange=e=>{m.enabled=e.target.checked;sync();};d.querySelector('[data-a-remove]').onclick=()=>confirmDelete(`l’email aggiuntiva “${m.name||('Email #'+(i+1))}”`,()=>{additionalEmails.splice(i,1);renderAdditional();});d.querySelectorAll('[data-a]').forEach(el=>{const ev=el.tagName==='SELECT'?'change':'input';el.addEventListener(ev,()=>{m[el.dataset.a]=el.value;if(el.dataset.a==='template')renderAdditional();sync();});});d.querySelectorAll('[data-a-check]').forEach(el=>el.onchange=()=>{m[el.dataset.aCheck]=el.checked;sync();});d.querySelectorAll('[data-a-cond]').forEach(el=>{const ev=el.tagName==='SELECT'?'change':'input';el.addEventListener(ev,()=>{m.condition[el.dataset.aCond]=el.value;sync();});});box.appendChild(d);});sync();}
document.getElementById('df-additional-add').onclick=()=>{additionalEmails.push(newAdditional());renderAdditional();};

// Builder configuration controls.
const controls={ajax:'df-validation-ajax',scroll_error:'df-validation-scroll',required_marker:'df-required-marker',error_message:'df-error-message'};document.getElementById(controls.ajax).checked=builderConfig.validation.ajax!==false;document.getElementById(controls.scroll_error).checked=builderConfig.validation.scroll_error!==false;document.getElementById(controls.required_marker).value=builderConfig.validation.required_marker||'*';document.getElementById(controls.error_message).value=builderConfig.validation.error_message||'';document.getElementById(controls.ajax).onchange=e=>{builderConfig.validation.ajax=e.target.checked;sync();};document.getElementById(controls.scroll_error).onchange=e=>{builderConfig.validation.scroll_error=e.target.checked;sync();};document.getElementById(controls.required_marker).oninput=e=>{builderConfig.validation.required_marker=e.target.value;sync();};document.getElementById(controls.error_message).oninput=e=>{builderConfig.validation.error_message=e.target.value;sync();};
const conf={enabled:document.getElementById('df-confirm-enabled'),position:document.getElementById('df-confirm-position'),scroll:document.getElementById('df-confirm-scroll'),cont:document.getElementById('df-confirm-continue'),label:document.getElementById('df-confirm-continue-label'),url:document.getElementById('df-confirm-continue-url')};const successFormat=document.getElementById('df-success-format'),successModal=document.getElementById('df-success-modal');conf.enabled.checked=builderConfig.confirmation.enabled!==false;conf.position.value=builderConfig.confirmation.position||'below';successFormat.value=builderConfig.confirmation.format==='html'?'html':'text';successModal.checked=conf.position.value==='modal';conf.scroll.checked=!!builderConfig.confirmation.scroll;conf.cont.checked=!!builderConfig.confirmation.continue;conf.label.value=builderConfig.confirmation.continue_label||'Continua';conf.url.value=builderConfig.confirmation.continue_url||'';conf.enabled.onchange=e=>{builderConfig.confirmation.enabled=e.target.checked;sync();};conf.position.onchange=e=>{builderConfig.confirmation.position=e.target.value;successModal.checked=e.target.value==='modal';sync();};successFormat.onchange=e=>{builderConfig.confirmation.format=e.target.value==='html'?'html':'text';sync();};successModal.onchange=e=>{builderConfig.confirmation.position=e.target.checked?'modal':(builderConfig.confirmation.position==='modal'?'below':builderConfig.confirmation.position);conf.position.value=builderConfig.confirmation.position;sync();};conf.scroll.onchange=e=>{builderConfig.confirmation.scroll=e.target.checked;sync();};conf.cont.onchange=e=>{builderConfig.confirmation.continue=e.target.checked;sync();};conf.label.oninput=e=>{builderConfig.confirmation.continue_label=e.target.value;sync();};conf.url.oninput=e=>{builderConfig.confirmation.continue_url=e.target.value;sync();};
const enabledToggle=document.querySelector('[name="enabled"]'),closedBox=document.querySelector('.df-closed-box');function syncClosedBox(){if(closedBox)closedBox.hidden=!!enabledToggle?.checked;}enabledToggle?.addEventListener('change',syncClosedBox);syncClosedBox();
const minSeconds=document.getElementById('df-min-seconds'),rateSeconds=document.getElementById('df-rate-seconds');minSeconds.value=builderConfig.security.min_seconds??2;rateSeconds.value=builderConfig.security.rate_seconds??8;minSeconds.oninput=e=>{builderConfig.security.min_seconds=Math.max(0,Number(e.target.value||0));sync();};rateSeconds.oninput=e=>{builderConfig.security.rate_seconds=Math.max(0,Number(e.target.value||0));sync();};
const sheetsEnabled=document.getElementById('df-sheets-enabled'),sheetsWebhook=document.getElementById('df-sheets-webhook'),sheetsSecret=document.getElementById('df-sheets-secret'),sheetsFiles=document.getElementById('df-sheets-files');
if(sheetsEnabled&&sheetsWebhook&&sheetsSecret&&sheetsFiles){
  sheetsEnabled.checked=!!integrations.google_sheets.enabled;sheetsWebhook.value=integrations.google_sheets.webhook_url||'';sheetsSecret.value=integrations.google_sheets.secret||'';sheetsFiles.checked=!!integrations.google_sheets.include_files;
  sheetsEnabled.onchange=e=>{integrations.google_sheets.enabled=e.target.checked;sync();};sheetsWebhook.oninput=e=>{integrations.google_sheets.webhook_url=e.target.value;sync();};sheetsSecret.oninput=e=>{integrations.google_sheets.secret=e.target.value;sync();};sheetsFiles.onchange=e=>{integrations.google_sheets.include_files=e.target.checked;sync();};
}
document.getElementById('df-add-calculation')?.addEventListener('click',()=>add({key:'calculation',type:'calculated',category:'values',label:'<?php echo addslashes(Text::_('COM_DECAROFORMS_FIELD_CALCULATION')); ?>',placeholder:'',help:'',default:'',options:[],required:false,config:{formula:'',decimals:2,prefix:'',suffix:'',visible:true}}));

// Quick templates.
const libByKey=()=>Object.fromEntries(library.map(x=>[x.key,x]));

function openBuilderSection(index,scroll=false){const sections=[...document.querySelectorAll('[data-accordion]')],section=sections[index];if(!section)return;section.classList.add('is-open');section.querySelector('.df-section-toggle')?.setAttribute('aria-expanded','true');if(scroll)setTimeout(()=>section.scrollIntoView({behavior:'smooth',block:'start'}),80);}


// Draft recovery and robust AJAX save.
const draftStorageKey='decaroforms_builder_draft_v2_<?php echo (int) $id; ?>';let draftReady=false,draftTimer=null,emailPickersRendered=false;
function readDraft(){try{const d=JSON.parse(localStorage.getItem(draftStorageKey)||'null');return d&&d.state?d:null;}catch{return null;}}
function clearDraft(){try{localStorage.removeItem(draftStorageKey);}catch{}document.getElementById('df-draft-banner')?.setAttribute('hidden','');}
function saveDraftNow(){if(!draftReady)return;try{localStorage.setItem(draftStorageKey,JSON.stringify({savedAt:Date.now(),state:captureHistoryState()}));}catch(e){console.warn('Forms draft save failed',e);}}
function scheduleDraft(){if(!draftReady)return;clearTimeout(draftTimer);draftTimer=setTimeout(saveDraftNow,350);}
function applyDraftState(s){historyApplying=true;selected=clone(s.selected||[]);statuses=clone(s.statuses||[]);columns=clone(s.columns||[]);builderConfig=clone(s.builderConfig||{});emailConfig=clone(s.emailConfig||{});additionalEmails=clone(s.additionalEmails||[]);integrations=clone(s.integrations||{});activeFieldKey=s.activeFieldKey||selected[0]?.key||null;renderSelected();renderLayout();renderStatuses();renderColumns();renderTokens();renderUserEmailFields();if(emailPickersRendered)renderEmailPickers();renderAdditional();const controls=simpleFormControls();(s.form||[]).forEach((v,i)=>{const el=controls[i];if(el&&el.name===v.name){if(el.type==='checkbox'||el.type==='radio')el.checked=!!v.value;else el.value=v.value;}});syncClosedBox();successFormat.value=builderConfig.confirmation?.format==='html'?'html':'text';conf.position.value=builderConfig.confirmation?.position||'below';successModal.checked=conf.position.value==='modal';historyApplying=false;historyStates=[captureHistoryState()];historyIndex=0;sync();applyLockState();updateHistoryButtons();}
function showDraftBanner(){const d=readDraft(),bar=document.getElementById('df-draft-banner');if(!d||!bar)return false;if(Date.now()-Number(d.savedAt||0)>1000*60*60*24*14){clearDraft();return false;}if(historySignature(d.state)===historySignature(captureHistoryState())){clearDraft();return false;}bar.hidden=false;const tm=document.getElementById('df-draft-time');if(tm)tm.textContent=' · '+new Date(d.savedAt).toLocaleString();document.getElementById('df-draft-restore').onclick=()=>{applyDraftState(d.state);bar.hidden=true;draftReady=true;saveDraftNow();};document.getElementById('df-draft-discard').onclick=()=>{clearDraft();draftReady=true;};return true;}
function setSaveNotice(message,type='info',reload=false){const box=document.getElementById('df-save-notice');if(!box)return;box.className='df-save-notice is-'+type;box.hidden=false;box.innerHTML=`<span>${esc(message)}</span>${reload?'<button type="button" class="df-btn df-small" data-save-reload>Ricarica pagina</button>':''}`;box.querySelector('[data-save-reload]')?.addEventListener('click',()=>{saveDraftNow();window.dfAllowDraftReload=true;location.reload();});}
function clearSaveNotice(){const box=document.getElementById('df-save-notice');if(box)box.hidden=true;}
window.dfSetSaveNotice=setSaveNotice;
window.dfBuilderSaveDraft=saveDraftNow;
window.dfBuilderClearDraft=clearDraft;
window.dfBuilderSync=sync;
window.dfBuilderRuntime={version:'1.3.69',draft:true,ensureRender:typeof window.dfBuilderEnsureRender==='function',emailPreviewSandbox:true};

const builderRoot=document.querySelector('.df-builder'),builderForm=document.getElementById('df-builder-form');let editorLocked=<?php echo $id ? 'true' : 'false'; ?>;
function applyLockState(){if(!builderRoot)return;builderRoot.classList.toggle('is-locked',editorLocked);builderRoot.dataset.editorMode=editorLocked?'locked':'edit';document.querySelectorAll('.df-lock-toggle').forEach(b=>{const active=(b.dataset.lock==='1')===editorLocked;b.classList.toggle('is-active',active);b.setAttribute('aria-pressed',active?'true':'false');});document.querySelectorAll('.df-save-top').forEach(b=>b.disabled=editorLocked);builderForm.querySelectorAll('input:not([type="hidden"]),select,textarea,button:not(.df-section-toggle):not(.df-info)').forEach(el=>{if(!el.dataset.lockOriginal)el.dataset.lockOriginal=el.disabled?'1':'0';el.disabled=editorLocked||el.dataset.lockOriginal==='1';});updateHistoryButtons();}
function hasUnsavedChanges(){return historyReady&&historyIndex>=0&&historySignature(historyStates[historyIndex])!==initialHistorySignature;}
function setEditorLocked(locked,ask=true){if(locked===editorLocked)return;if(locked&&ask&&hasUnsavedChanges()&&!confirm('Ci sono modifiche non salvate. Vuoi bloccare comunque la modifica?'))return;editorLocked=locked;applyLockState();}
document.querySelectorAll('.df-lock-toggle').forEach(b=>b.onclick=()=>setEditorLocked(b.dataset.lock==='1'));
document.getElementById('df-undo').onclick=()=>restoreHistory(historyIndex-1);document.getElementById('df-redo').onclick=()=>restoreHistory(historyIndex+1);
document.addEventListener('keydown',e=>{if(editorLocked)return;const mod=e.ctrlKey||e.metaKey;if(!mod)return;if(e.key.toLowerCase()==='z'){e.preventDefault();restoreHistory(historyIndex+(e.shiftKey?1:-1));}else if(e.key.toLowerCase()==='y'){e.preventDefault();restoreHistory(historyIndex+1);}});
builderForm.addEventListener('input',scheduleHistory,true);builderForm.addEventListener('change',scheduleHistory,true);window.addEventListener('beforeunload',e=>{if(hasUnsavedChanges()&&!window.dfAllowDraftReload){e.preventDefault();e.returnValue='';}});
document.getElementById('df-add-section')?.addEventListener('click',addBuilderSection);document.getElementById('df-add-row')?.addEventListener('click',addBuilderRow);ensureInitialFieldWorkspace();renderLayout();renderTokens();renderUserEmailFields();renderAdditional();renderEmailPickers(false);sync();historyReady=true;historyStates=[captureHistoryState()];historyIndex=0;initialHistorySignature=historySignature(historyStates[0]);applyLockState();updateHistoryButtons();const emailSection=[...document.querySelectorAll('[data-accordion]')][5];const ensureEmailPickers=()=>{if(emailPickersRendered)return;emailPickersRendered=true;renderEmailPickers(true);};emailSection?.querySelector('.df-section-toggle')?.addEventListener('click',()=>setTimeout(()=>{if(emailSection.classList.contains('is-open'))ensureEmailPickers();},0));const pendingDraft=showDraftBanner();draftReady=!pendingDraft;builderForm.addEventListener('input',scheduleDraft,true);builderForm.addEventListener('change',scheduleDraft,true);document.addEventListener('dragend',scheduleDraft,true);document.addEventListener('click',e=>{if(e.target.closest('.df-builder'))scheduleDraft();},true);
})();
</script>
