<?php

defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use DeCaro\Plugin\EditorsXtd\Forms\Extension\Forms;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(PluginInterface::class, function (Container $container) {
            $plugin = new Forms((array) PluginHelper::getPlugin('editors-xtd', 'decaroforms'));
            $plugin->setApplication(Factory::getApplication());
            return $plugin;
        });
    }
};
