<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

$app = Factory::getApplication();
$editor = $app->getInput()->getCmd('editor', '');
?>
<style>
.df-editor-picker{--df:#e60046;--df-dark:#b40038;--df-border:var(--bs-border-color,#dfe3e7);--df-bg:var(--bs-body-bg,#fff);padding:18px;color:var(--bs-body-color,#1f2937)}
.df-editor-picker *{box-sizing:border-box}.df-editor-picker h2{margin:0 0 5px;font-size:24px}.df-editor-picker .df-note{margin:0 0 16px;color:var(--bs-secondary-color,#667085)}
.df-editor-search{width:100%;min-height:44px;padding:0 13px;border:1px solid var(--df-border);border-radius:7px;background:var(--df-bg);color:inherit;margin-bottom:14px}
.df-editor-list{display:grid;gap:9px}.df-editor-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:14px;align-items:center;padding:13px 14px;border:1px solid var(--df-border);border-radius:8px;background:var(--df-bg)}.df-editor-row[hidden]{display:none}
.df-editor-title{font-weight:800;font-size:16px}.df-editor-desc{font-size:12px;color:var(--bs-secondary-color,#667085);margin-top:3px}.df-editor-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:7px}.df-editor-code{font:700 12px/1.2 ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--df)}
.df-editor-badge{display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;font-size:11px;font-weight:800}.df-editor-badge.is-on{background:#e8f7ee;color:#176b3a}.df-editor-badge.is-off{background:#fff0e5;color:#9f3b00}
.df-editor-insert{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:40px;padding:0 14px;border:1px solid var(--df);border-radius:6px;background:var(--df);color:#fff;font-weight:800;cursor:pointer}.df-editor-insert:hover,.df-editor-insert:focus-visible{background:var(--df-dark);border-color:var(--df-dark)}.df-editor-insert svg{width:17px;height:17px}
.df-editor-empty{padding:28px 14px;text-align:center;border:1px dashed var(--df-border);border-radius:8px;color:var(--bs-secondary-color,#667085)}.df-editor-error{margin-bottom:12px;padding:10px 12px;border:1px solid #f2a7b8;border-radius:7px;background:#fff1f4;color:#7a1631}
@media(max-width:620px){.df-editor-picker{padding:12px}.df-editor-row{grid-template-columns:1fr}.df-editor-insert{width:100%}}
</style>
<div class="df-editor-picker">
  <h2><?php echo Text::_('COM_DECAROFORMS_EDITOR_PICKER_TITLE'); ?></h2>
  <p class="df-note"><?php echo Text::_('COM_DECAROFORMS_EDITOR_PICKER_DESC'); ?></p>
  <div class="df-editor-error" id="df-editor-error" hidden></div>
  <input class="df-editor-search" id="df-editor-search" type="search" autocomplete="off" placeholder="<?php echo htmlspecialchars(Text::_('COM_DECAROFORMS_EDITOR_PICKER_SEARCH'), ENT_QUOTES, 'UTF-8'); ?>">
  <div class="df-editor-list" id="df-editor-list">
  <?php if (!$this->forms): ?><div class="df-editor-empty"><?php echo Text::_('COM_DECAROFORMS_EDITOR_PICKER_EMPTY'); ?></div><?php endif; ?>
  <?php foreach ($this->forms as $form):
      $id=(int)$form['id'];
      $enabled=(int)$form['enabled']===1;
      $search=mb_strtolower((string)$form['title'].' '.(string)$form['description'].' '.$id.' {form id="'.$id.'"}', 'UTF-8');
  ?>
    <article class="df-editor-row" data-editor-form data-search="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>">
      <div>
        <div class="df-editor-title"><?php echo htmlspecialchars((string)$form['title'], ENT_QUOTES, 'UTF-8'); ?></div>
        <?php if(trim((string)$form['description'])!==''): ?><div class="df-editor-desc"><?php echo htmlspecialchars((string)$form['description'], ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
        <div class="df-editor-meta"><span class="df-editor-code">{form id="<?php echo $id; ?>"}</span><span class="df-editor-badge <?php echo $enabled?'is-on':'is-off'; ?>"><?php echo $enabled?Text::_('COM_DECAROFORMS_IN_PROGRESS'):Text::_('COM_DECAROFORMS_DISABLED'); ?></span></div>
      </div>
      <button class="df-editor-insert" type="button" data-insert-form="<?php echo $id; ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5Z" fill="currentColor"/></svg><span><?php echo Text::_('COM_DECAROFORMS_EDITOR_PICKER_INSERT'); ?></span></button>
    </article>
  <?php endforeach; ?>
  <?php if ($this->forms): ?><div class="df-editor-empty" id="df-editor-no-results" hidden><?php echo Text::_('COM_DECAROFORMS_EDITOR_PICKER_NO_RESULTS'); ?></div><?php endif; ?>
  </div>
</div>
<script>
(()=>{
 const editor=<?php echo json_encode($editor, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
 const q=document.getElementById('df-editor-search'),rows=[...document.querySelectorAll('[data-editor-form]')],empty=document.getElementById('df-editor-no-results'),err=document.getElementById('df-editor-error');
 const showError=msg=>{if(!err)return;err.textContent=msg;err.hidden=false;};
 const closeModal=()=>{try{if(window.parent.Joomla?.Modal?.getCurrent())window.parent.Joomla.Modal.getCurrent().close();}catch(e){}};
 const insert=id=>{const shortcode=`{form id="${id}"}`;try{const instance=window.parent.Joomla?.editors?.instances?.[editor];if(!instance||typeof instance.replaceSelection!=='function')throw new Error('editor unavailable');instance.replaceSelection(shortcode);closeModal();}catch(e){showError(<?php echo json_encode(Text::_('COM_DECAROFORMS_EDITOR_PICKER_ERROR')); ?>);}};
 document.querySelectorAll('[data-insert-form]').forEach(btn=>btn.addEventListener('click',()=>insert(btn.dataset.insertForm)));
 q?.addEventListener('input',()=>{const term=(q.value||'').toLocaleLowerCase().trim();let shown=0;rows.forEach(row=>{const ok=!term||row.dataset.search.includes(term);row.hidden=!ok;if(ok)shown++;});if(empty)empty.hidden=shown!==0;});
 q?.focus();
})();
</script>
