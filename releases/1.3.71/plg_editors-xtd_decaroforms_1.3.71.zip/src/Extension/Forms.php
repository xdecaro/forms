<?php

namespace DeCaro\Plugin\EditorsXtd\Forms\Extension;

use Joomla\CMS\Editor\Button\Button;
use Joomla\CMS\Event\Editor\EditorButtonsSetupEvent;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;

defined('_JEXEC') or die;

final class Forms extends CMSPlugin implements SubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return ['onEditorButtonsSetup' => 'onEditorButtonsSetup'];
    }

    public function onEditorButtonsSetup(EditorButtonsSetupEvent $event): void
    {
        if (in_array($this->_name, $event->getDisabledButtons(), true)) {
            return;
        }
        $user = $this->getApplication()->getIdentity();
        if (!$user || $user->guest || !$user->authorise('core.manage', 'com_decaroforms')) {
            return;
        }
        $this->loadLanguage();
        $editor = $event->getEditorId();
        $link = 'index.php?option=com_decaroforms&view=forms&layout=modal&tmpl=component&editor=' . rawurlencode($editor);
        $button = new Button($this->_name, [
            'action' => 'modal',
            'link' => $link,
            'text' => Text::_('PLG_EDITORSXTD_DECAROFORMS_BUTTON'),
            'icon' => 'list',
            'iconSVG' => '<svg viewBox="0 0 32 32" width="24" height="24"><path d="M5 4h22v24H5V4zm4 5h14v2H9V9zm0 6h14v2H9v-2zm0 6h9v2H9v-2z"></path></svg>',
            'name' => $this->_type . '_' . $this->_name,
        ]);
        $event->getButtonsRegistry()->add($button);
    }
}
