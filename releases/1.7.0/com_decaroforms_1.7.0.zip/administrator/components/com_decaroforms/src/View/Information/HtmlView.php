<?php

namespace DeCaro\Component\Forms\Administrator\View\Information;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

final class HtmlView extends BaseHtmlView
{
    private const MINIMUM_CORE_UI_VERSION = '1.3.0';

    public array $info = [];
    public bool $canManageInstaller = false;
    public bool $coreUiEnabled = false;

    public function display($tpl = null): void
    {
        $app = Factory::getApplication();
        $user = $app->getIdentity();

        if (!$user->authorise('core.manage', 'com_decaroforms')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        $document = $app->getDocument();
        $wa = $document->getWebAssetManager();

        $coreVersion = class_exists(\xdecaro\Core\Version::class)
            ? trim((string) \xdecaro\Core\Version::VERSION)
            : '';

        if (
            $coreVersion !== ''
            && version_compare($coreVersion, self::MINIMUM_CORE_UI_VERSION, '>=')
            && class_exists(\xdecaro\Core\Asset\AssetService::class)
        ) {
            try {
                $coreAssets = new \xdecaro\Core\Asset\AssetService();
                $this->coreUiEnabled = $coreAssets->useComponents($wa);
            } catch (\Throwable) {
                $this->coreUiEnabled = false;
            }
        }

        if ($this->coreUiEnabled) {
            if (!$wa->assetExists('style', 'com_decaroforms.core-bridge')) {
                $wa->registerStyle(
                    'com_decaroforms.core-bridge',
                    'com_decaroforms/core-bridge.css',
                    ['version' => '1.7.0']
                );
            }
            $wa->useStyle('com_decaroforms.core-bridge');
            $this->setLayout('core');
        }

        // Joomla WebAssetManager automatically inserts /css or /js for extension assets.
        // The URI must therefore omit the physical css/js subdirectory.
        if (!$wa->assetExists('style', 'com_decaroforms.information')) {
            $wa->registerStyle(
                'com_decaroforms.information',
                'com_decaroforms/information.css',
                ['version' => '1.7.0']
            );
        }

        if (!$wa->assetExists('script', 'com_decaroforms.information')) {
            $wa->registerScript(
                'com_decaroforms.information',
                'com_decaroforms/information.js',
                ['version' => '1.7.0'],
                ['defer' => true]
            );
        }

        foreach ([
            'COM_DECAROFORMS_INFO_DIAGNOSTICS_COPIED',
            'COM_DECAROFORMS_INFO_DIAGNOSTICS_COPY_FAILED',
            'COM_DECAROFORMS_INFO_DIAGNOSTICS_DOWNLOADED',
        ] as $key) {
            Text::script($key);
        }

        $wa->useStyle('com_decaroforms.information');
        $wa->useScript('com_decaroforms.information');

        $this->info = (array) $this->get('Info');
        $this->canManageInstaller = $user->authorise('core.manage', 'com_installer');

        if (count($errors = $this->get('Errors'))) {
            throw new \RuntimeException(implode("\n", $errors));
        }

        ToolbarHelper::title(Text::_('COM_DECAROFORMS_INFORMATION'), 'info-circle');
        $document->setTitle(Text::_('COM_DECAROFORMS_INFO_TITLE'));

        parent::display($tpl);
    }
}
